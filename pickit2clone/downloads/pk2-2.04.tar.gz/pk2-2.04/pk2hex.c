//
// Intel MDS .hex file read and writer.
//
// Maintained by Jeff Post, j_post@pacbell.net
// Last update: 2006/10/12
//
//-----------------------------------------------------------------------------
//
//	This program is free software; you can redistribute it and/or
//	modify it under the terms of the GNU General Public License
//	as published by the Free Software Foundation; either version 2
//	of the License, or (at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program; if not, write to the Free Software
//	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//-----------------------------------------------------------------------------
//
#if HAVE_CONFIG_H
#include	"config.h"
#endif

#include <ctype.h>

#if STDC_HEADERS
#include	<stdlib.h>
#else
#if HAVE_MALLOC_H
#include	<malloc.h>
#endif
#endif

#include	"pk2.h"
#include "pk2hex.h"

#define	false	0
#define	true	1

#define	RECORD_CHAR		':'
#define	COMMENT_CHAR	';'
#define	SPACE_CHAR		' '
#define	NEWLINE_CHAR	'\n'
#define	NULL_CHAR		0

#define	DATARECORD	0				// data record
#define	ENDRECORD	1				// end record
#define	SEGADDRESS	2				// segment address record (INHX32)
#define	EXTADDRESS	4				// extended linear address record (INHX32)

#define	REC_LENGTH	16

#define MAX_LINE_LEN	256

static char	lineBuffer[MAX_LINE_LEN];	// place to read records from the input file

static int	byteCount;				// number of bytes read in and ready to be returned
static int	byteIdx;					// index to the next byte to be read
static int	recordType;

static int	byteAddress;			// address of the next byte to be read
static int	extendedAddress;		// bits 31-16 are bits 31-16 of the address for intel hex records, bits 15-0 are 0

char	errmsg[128];

// convert two ascii hex characters to an 8-bit unsigned int
//  return zero if out of range (not ascii hex)

unsigned char atoh(char high, char low)
{
	char	hi, lo;
	int	value;

	hi = toupper(high);
	lo = toupper(low);
	value = 0;

	if (hi >= '0' && hi <= '9')
		value += ((hi - '0') << 4);
	else if (hi >= 'A' && hi <= 'F')
		value += ((hi - 'A' + 0x0a) << 4);

	if (lo >= '0' && lo <= '9')
		value += (lo - '0');
	else if (lo >= 'A' && lo <= 'F')
		value += (lo - 'A' + 0x0a);

	return(value);
}

// read a line from the given file into the array line
// if there is a read error, return false
// lineLength is considered to be the maximum number of characters
// to read into the line (including the 0 terminator)
// if the line fills before a CR is hit, overFlow will be set true, and the rest of the
// line will be read, but not stored
// if the EOF is hit, atEOF is set true

bool getLine(FILE *fp, char *line, int lineLength, bool *atEOF, bool *overFlow)
{
	int	i, numRead;
	byte	c;
	bool	stopReading, hadError;

	i = 0;											// index into output line
	stopReading = hadError = (*atEOF) = (*overFlow)= false;

	while (!stopReading)
	{
		numRead = fread(&c, 1, 1, fp);		// get character from input

		if (numRead)									// if something was read, check it, and add to output line
		{
			if (c == '\n' || c== '\0')				// found termination?
				stopReading = true;					// yes, output line is complete
			else
			{
				if (c != '\n' && c != '\r')		// see if the character should be added to the line
				{
					if (i < lineLength - 1)			// make sure there is room to store it
						line[i++] = c;					// store it if there is room
					else
						(*overFlow) = true;			// complain of overflow, but continue to the end
				}
			}
		}
		else
		{
			stopReading = true;

			if (feof(fp))
				(*atEOF) = true;						// tell caller that EOF was encountered
			else
				hadError = true;
		}
	}

	if (lineLength)
		line[i] = '\0';								// terminate the line if possible

	return(!hadError);								// return error status
}

// set up to interpret the line as an intel hex record

bool getIntelRecord(void)
{
	bool	done;
	int	i, len, type, chksum;

	done = false;

	type = atoh(lineBuffer[7], lineBuffer[8]);
	recordType = type;

	switch (type)
	{
		case DATARECORD:				// don't know how to cope with anything but 16-bit addresses for now
			byteIdx = 9;				// the ninth character is the high nibble of the first data byte
			byteCount = atoh(lineBuffer[1], lineBuffer[2]);
			byteAddress =
				atoh(lineBuffer[3], lineBuffer[4]) * 256 +
				atoh(lineBuffer[5], lineBuffer[6]) + extendedAddress;
			break;

		case ENDRECORD:
			byteCount = 0;
			done = true;
			break;

		case SEGADDRESS:
			extendedAddress =
				(atoh(lineBuffer[9], lineBuffer[10]) * 256 +
				atoh(lineBuffer[11], lineBuffer[12])) << 4;
			break;

		case EXTADDRESS:
			extendedAddress =
				(atoh(lineBuffer[9], lineBuffer[10]) * 256 +
				atoh(lineBuffer[11], lineBuffer[12])) << 16;
			break;

		default:
			fprintf(stderr, "GetIntelRecord: Unknown code %d: %s\n", type, lineBuffer);
			byteCount = 0;
			done = true;
			break;
	}

	len = atoh(lineBuffer[1], lineBuffer[2]) * 2;
	len += 8;		// add count, address, and type overhead
	chksum = 0;

	for (i=0; i<len; i += 2)
		chksum += atoh(lineBuffer[i + 1], lineBuffer[i + 2]);

	chksum = ~chksum;
	chksum++;
	chksum &= 0xff;

	if (chksum != atoh(lineBuffer[len + 1], lineBuffer[len + 2]))
	{
		fprintf(stderr, "GetIntelRecord: Checksum error 0x%02x: %s\n", chksum, lineBuffer);
		done = true;
	}

	return(!done);
}

// read the next record, return true if read, false if end of file (or end record)

bool getRecord(FILE *fp)
{
	bool	done, overflow, redo;
		
	done = false;
	overflow = false;		// set true when oversized line is read
	redo = true;			// for skipping comment lines

	while (redo && !done)
	{
		if (getLine(fp, lineBuffer, MAX_LINE_LEN, &done, &overflow))
		{
			if (overflow)
				fprintf(stderr, "Line too long, truncation occurred\n");

			if (!done)
			{
				if (lineBuffer[0] == RECORD_CHAR)
				{
					done = !getIntelRecord();
					redo = false;
				}
				else if (lineBuffer[0] == COMMENT_CHAR || lineBuffer[0] == SPACE_CHAR
					|| lineBuffer[0] == NEWLINE_CHAR || lineBuffer[0] == NULL_CHAR)
				{
					byteCount = 0;
					redo = true;
				}
				else
				{
					fprintf(stderr, "Unrecognized record format: '%c' 0x%02x\n", lineBuffer[0], lineBuffer[0]);
					done = true;
					redo = false;
				}
			}
		}
	}

	return(!done);					// return true if okay
}

// read the next byte, report its address and value
// read next record as needed
// return true if read okay, false if end of file or error

bool getNextByte(FILE *fp, int *address, byte *data)
{
	bool	fail;

	fail = false;

	while (!byteCount && !fail)		// do as often as necessary to skip comment records
		fail = !getRecord(fp);			// read in another record, if possible

	if (recordType == ENDRECORD)
		fail = true;

	if (!fail)
	{
		*data = atoh(lineBuffer[byteIdx], lineBuffer[byteIdx + 1]);
		*address = byteAddress;
		byteIdx += 2;
		byteCount--;
		byteAddress++;
	}

	return(!fail);
}

// get ready to parse records

void initParse(void)
{
	byteCount = 0;
	byteIdx = 0;
	byteAddress = 0;
	extendedAddress = 0;
}

// Begin writing a hex file

void hexWriteBegin(FILE *fp)
{
	fprintf(fp, ":020000040000FA\n");
}

// Finish writing a hex file

void hexWriteEnd(FILE *fp)
{
	fprintf(fp, ":00000001FF\n");
}

// write an extended address record to the file

void writeIntelHexExtendedAddressRecord(FILE *fp, int address)
{
	int	checksum = 2 + EXTADDRESS + address + (address >> 8);

	fprintf(fp, ":%02X%04X%02X%04X%02X\n",
		2, 0, EXTADDRESS, address, (-checksum) & 0xff);
}

// Write an Intel hex record
// For big endian machines (MAC),
//  dataptr must be on a word boundary and numBytes must be even.

void writeIntelHexLine(FILE *fp, int address, byte *dataptr, int numBytes, picdev_word blankData)
{
	int			i, checkSum;
	picdev_word	data;
	bool			skip = true;

	if (blankData)		// writing program data, not eeprom data
	{
		for (i=0; i<numBytes; i += 2)		// check for valid data in program space
		{
			if (endian == littleEndian)
				data = (dataptr[i + 1] << 8) | (dataptr[i] & 0xff);
			else
				data = (dataptr[i + 1] & 0xff) | (dataptr[i] << 8);

			if (data != blankData)			// non-blank data found, do not skip this record
			{
				skip = false;
				break;
			}
		}
	}
	else
		skip = false;		// always output lines for eeprom data

// If this line of program memory contains only blank values, do not write it.

	if (!skip)
	{
		fprintf(fp, ":%02X%04X%02X", numBytes, address, DATARECORD);	// write the stub (colon, length of record, address, record type)
		checkSum = 0;

		for (i=0; i<numBytes; i++)
		{
			if (endian == littleEndian)
			{
				checkSum += dataptr[i];
				fprintf(fp, "%02X", dataptr[i]);		// write a data byte as ASCII
			}
			else		// dataptr must be on a word boundary
			{
				if (i & 1)
				{
					checkSum += dataptr[i - 1];
					fprintf(fp, "%02X", dataptr[i - 1]);
				}
				else
				{
					checkSum += dataptr[i + 1];
					fprintf(fp, "%02X", dataptr[i + 1]);
				}
			}
		}

		checkSum += (address & 0xFF) + (address >> 8) + numBytes + DATARECORD;
		fprintf(fp, "%02X\n", (-checkSum) & 0xFF);		// add the checksum and a line terminator
	}
}

// Write a block of data to hex file

void writeHexBlock(FILE *fp, byte *bfr, int address, int size, picdev_word blankData)
{
	int	bytesLeft, numBytes;
	int	extAdrs;

	bytesLeft = size;
	extAdrs = address & 0xffff0000;

	while (bytesLeft > 0)
	{
		numBytes = bytesLeft > REC_LENGTH ? REC_LENGTH : bytesLeft;
		writeIntelHexLine(fp, address & 0xffff, &bfr[size - bytesLeft], numBytes, blankData);
		address += numBytes;
		bytesLeft -= numBytes;

		if (bytesLeft && ((address & 0xffff0000) != extAdrs))
		{
			extAdrs = address & 0xffff0000;
			writeIntelHexExtendedAddressRecord(fp, extAdrs >> 16);
		}
	}
}

// Write a block of 18F eeprom data to hex file

void writeHexBlock18Fdata(FILE *fp, byte *bfr, int address, int size, picdev_word blankData)
{
	int	i, offset, bytesLeft, numBytes;
	int	extAdrs;
	byte	data[REC_LENGTH];

	bytesLeft = size;
	extAdrs = address & 0xffff0000;

	while (bytesLeft)
	{
		numBytes = bytesLeft > REC_LENGTH ? REC_LENGTH : bytesLeft;
		offset = (size - bytesLeft) * 2;

		for (i=0; i<numBytes; i++)
			data[i] = (byte) bfr[offset + i * 2];

		writeIntelHexLine(fp, address & 0xffff, data, numBytes, blankData);
		address += numBytes;
		bytesLeft -= numBytes;

		if (bytesLeft && ((address & 0xffff0000) != extAdrs))
		{
			extAdrs = address & 0xffff0000;
			writeIntelHexExtendedAddressRecord(fp, extAdrs >> 16);
		}
	}
}

char *readBaselineFile(FILE *fp)
{
	int	adrs, maxprog, maxee;
	byte	data1, data2;
	picdev_word	dword;
	bool	done = false;

	maxprog = currentDevice->instlen - 1;
	maxee = currentDevice->eelen;

	while (!done)
	{
		if (!getNextByte(fp, &adrs, &data1))
			done = true;

		if (!getNextByte(fp, &adrs, &data2))
			done = true;

		if (!done)
		{
			adrs /= 2;			// convert to word address
			dword = data2 << 8 | data1;

			if ((adrs >= 0x2100) && (adrs < (0x2100 + maxee)))		// if eeprom data
			{
				adrs -= 0x2100;
				currentDevice->feeprom[adrs] = dword;
			}
			else if (adrs < maxprog)							// program data
			{
				currentDevice->fprogram[adrs] = dword;
			}
			else if (adrs == 0xfff)								// config word
			{
				currentDevice->fconfig[0] = dword;
			}
		}
	}

	return NULL;
}

char *readMidrangeFile(FILE *fp)
{
	int	adrs, maxprog, maxee;
	byte	data1, data2;
	picdev_word	dword;
	bool	done = false;

	maxprog = currentDevice->instlen;
	maxee = currentDevice->eelen;

	while (!done)
	{
		if (!getNextByte(fp, &adrs, &data1))
			done = true;

		if (!getNextByte(fp, &adrs, &data2))
			done = true;

		if (!done)
		{
			adrs /= 2;			// convert to word address
			dword = data2 << 8 | data1;

			if (adrs < maxprog)										// program data
			{
				currentDevice->fprogram[adrs] = dword;
			}
			else if ((adrs >= 0x2100) && (adrs < 0x2200))	// eeprom data
			{
				adrs -= 0x2100;

				if (adrs < maxee)
					currentDevice->feeprom[adrs] = dword;
			}
			else if ((adrs >= 0x2000) && (adrs < 0x2004))	// user ID
			{
				adrs -= 0x2000;
				currentDevice->fID[adrs] = dword;
			}
			else if ((adrs == 0x2007) || (adrs == 0x2008))	// config word
			{
				adrs -= 0x2007;
				currentDevice->fconfig[adrs] = dword;
			}
		}
	}

	return NULL;
}

char *readPIC18FFile(FILE *fp)
{
	int	adrs, maxprog, maxee;
	byte	data1, data2;
	picdev_word	dword;
	bool	done = false;

	maxprog = currentDevice->instlen;
	maxee = currentDevice->eelen - 1;

	while (!done)
	{
		if (!getNextByte(fp, &adrs, &data1))
			done = true;

		if (!getNextByte(fp, &adrs, &data2))
			done = true;

		if (!done)
		{
			adrs /= 2;			// convert to word address
			dword = data2 << 8 | data1;

			if (adrs < maxprog)
			{
				currentDevice->fprogram[adrs] = dword;
			}
			else if (adrs >= 0x780000)		// if eeprom data
			{
				adrs *= 2;						// make byte address
				adrs -= 0xf00000;

				if (adrs < maxee)
				{
					currentDevice->feeprom[adrs] = data1;
					adrs++;
					currentDevice->feeprom[adrs] = data2;
				}
			}
			else if ((adrs >= 0x100000) && (adrs < 0x100004))	// user ID
			{
				adrs -= 0x100000;
				currentDevice->fID[adrs] = dword;
			}
			else if ((adrs >= 0x180000) && (adrs <= 0x18000d))	// config word
			{
				adrs -= 0x180000;
				currentDevice->fconfig[adrs] = dword;
			}
		}
	}

	return NULL;
}

char *readPIC18JFile(FILE *fp)
{
	int	adrs, maxprog;
	byte	data1, data2;
	picdev_word	dword;
	bool	done = false;

	maxprog = currentDevice->instlen;

	while (!done)
	{
		if (!getNextByte(fp, &adrs, &data1))
			done = true;

		if (!getNextByte(fp, &adrs, &data2))
			done = true;

		if (!done)
		{
			adrs /= 2;			// convert to word address
			dword = data2 << 8 | data1;

			if (adrs < maxprog)
			{
				currentDevice->fprogram[adrs] = dword;

				if (adrs >= currentDevice->instlen - 4)	// last 4 words of pgm are also config words
					currentDevice->fconfig[adrs - currentDevice->instlen - 4] = dword;
			}
		}
	}

	return NULL;
}

// Read entire hex file into currentDevice

char *readHexFile(FILE *fp)
{
	int	i;
	picdev_word	data;
	char	*err = NULL;

	initParse();

	if (!currentDevice->fprogram)
		currentDevice->fprogram = malloc(currentDevice->instlen * sizeof(picdev_word));

	if (!currentDevice->feeprom)
		currentDevice->feeprom = malloc(currentDevice->eelen * sizeof(picdev_word));

	data = currentDevice->instwidth;		// clear file data areas
	currentDevice->fosccal = data;

	for (i=0; i<7; i++)
		currentDevice->fconfig[i] = data;

	for (i=0; i<4; i++)
		currentDevice->fID[i] = data;

	for (i=0; i<currentDevice->instlen; i++)
		currentDevice->fprogram[i] = data;

	for (i=0; i<currentDevice->eelen; i++)
		currentDevice->feeprom[i] = data;

	switch (currentDevice->family)
	{
		case BASELINE:
			err = readBaselineFile(fp);
			break;

		case MIDRANGE:
			err = readMidrangeFile(fp);
			break;

		case PIC18F:
			err = readPIC18FFile(fp);
			break;

		case PIC18J:
			err = readPIC18JFile(fp);
			break;

		default:
			sprintf(errmsg, "Invalid PIC family: %d", currentDevice->family);
			fatalError(errmsg);
			break;
	}

	return err;
}

char *writeBaselineFile(FILE *fp)
{
	hexWriteBegin(fp);

	// write program data
	writeHexBlock(fp, (byte *) currentDevice->program, 0, currentDevice->instlen * 2, currentDevice->instwidth);

	if (currentDevice->eelen)	// write eeprom data
		writeHexBlock(fp, (byte *) currentDevice->eeprom, 0x4200, currentDevice->eelen * 2, 0xff);

	// write user ID
	writeHexBlock(fp, (byte *) currentDevice->ID, currentDevice->instlen, 8, 0);
	// write config word
	writeHexBlock(fp, (byte *) currentDevice->config, 0x1ffe, 4, 0);

	hexWriteEnd(fp);
	return NULL;
}

char *writeMidrangeFile(FILE *fp)
{
	hexWriteBegin(fp);

	// write program data
	writeHexBlock(fp, (byte *) currentDevice->program, 0, currentDevice->instlen * 2, currentDevice->instwidth);

	if (currentDevice->eelen)	// write eeprom data
		writeHexBlock(fp, (byte *) currentDevice->eeprom, 0x4200, currentDevice->eelen * 2, 0xff);

	// write user ID
	writeHexBlock(fp, (byte *) currentDevice->ID, 0x4000, 8, 0);

	// write config words
	if (currentDevice->configMask[1])
		writeHexBlock(fp, (byte *) currentDevice->config, 0x400e, 4, 0);
	else
		writeHexBlock(fp, (byte *) currentDevice->config, 0x400e, 2, 0);

	hexWriteEnd(fp);
	return NULL;
}

char *writePIC18FFile(FILE *fp)
{
	hexWriteBegin(fp);

	// write program data
	writeHexBlock(fp, (byte *) currentDevice->program, 0, currentDevice->instlen * 2, currentDevice->instwidth);

	if (currentDevice->eelen)	// write eeprom data
	{
		writeIntelHexExtendedAddressRecord(fp, 0xf0);
		writeHexBlock18Fdata(fp, (byte *) currentDevice->eeprom, 0, currentDevice->eelen, 0xffff);
	}

	// write user ID
	writeIntelHexExtendedAddressRecord(fp, 0x20);
	writeHexBlock(fp, (byte *) currentDevice->ID, 0x200000, 8, 0);
	// write config words
	writeIntelHexExtendedAddressRecord(fp, 0x30);
	writeHexBlock(fp, (byte *) currentDevice->config, 0x300000, 14, 0);

	hexWriteEnd(fp);
	return NULL;
}

char *writePIC18JFile(FILE *fp)
{
	hexWriteBegin(fp);

	// write program data
	writeHexBlock(fp, (byte *) currentDevice->program, 0, currentDevice->instlen * 2, currentDevice->instwidth);
	hexWriteEnd(fp);
	return NULL;
}

// Write all data from currentDevice to file

char *writeHexFile(FILE *fp)
{
	char	*err = NULL;

	switch (currentDevice->family)
	{
		case BASELINE:
			err = writeBaselineFile(fp);
			break;

		case MIDRANGE:
			err = writeMidrangeFile(fp);
			break;

		case PIC18F:
			err = writePIC18FFile(fp);
			break;

		case PIC18J:
			err = writePIC18JFile(fp);
			break;

		default:
			sprintf(errmsg, "Invalid PIC family: %d", currentDevice->family);
			fatalError(errmsg);
			break;
	}

	return err;
}

// Read only program memory from hex file

char *readBaselinePFile(FILE *fp)
{
	int	adrs;
	byte	data1, data2;
	picdev_word	dword;
	bool	done = false;

	while (!done)
	{
		if (!getNextByte(fp, &adrs, &data1))
			done = true;

		if (!getNextByte(fp, &adrs, &data2))
			done = true;

		if (!done);
		{
			adrs /= 2;			// convert to word address
			dword = data2 << 8 | data1;

			if (adrs < currentDevice->instlen)
				currentDevice->fprogram[adrs] = dword;
		}
	}

	return NULL;
}

char *readMidrangePFile(FILE *fp)
{
	int	adrs;
	byte	data1, data2;
	picdev_word	dword;
	bool	done = false;

	while (!done)
	{
		if (!getNextByte(fp, &adrs, &data1))
			done = true;

		if (!getNextByte(fp, &adrs, &data2))
			done = true;

		if (!done);
		{
			adrs /= 2;			// convert to word address
			dword = data2 << 8 | data1;

			if (adrs < currentDevice->instlen)
				currentDevice->fprogram[adrs] = dword;
		}
	}

	return NULL;
}

char *readPIC18FPFile(FILE *fp)
{
	int	adrs;
	byte	data1, data2;
	picdev_word	dword;
	bool	done = false;

	while (!done)
	{
		if (!getNextByte(fp, &adrs, &data1))
			done = true;

		if (!getNextByte(fp, &adrs, &data2))
			done = true;

		if (!done);
		{
			adrs += extendedAddress;
			adrs /= 2;			// convert to word address
			dword = data2 << 8 | data1;

			if (adrs < currentDevice->instlen)
				currentDevice->fprogram[adrs] = dword;
		}
	}

	return NULL;
}

char *readPIC18JPFile(FILE *fp)
{
	readPIC18JFile(fp);
	return NULL;
}

// Read only program data from hex file into currentDevice

char *readProgramFile(FILE *fp)
{
	int	i;
	picdev_word	data;
	char	*err = NULL;

	initParse();

	if (!currentDevice->fprogram)
		currentDevice->fprogram = malloc(currentDevice->instlen * sizeof(picdev_word));

	data = currentDevice->instwidth;		// clear file data areas

	for (i=0; i<currentDevice->instlen; i++)
		currentDevice->fprogram[i] = data;

	switch (currentDevice->family)
	{
		case BASELINE:
			err = readBaselinePFile(fp);
			break;

		case MIDRANGE:
			err = readMidrangePFile(fp);
			break;

		case PIC18F:
			err = readPIC18FPFile(fp);
			break;

		case PIC18J:
			err = readPIC18JPFile(fp);
			break;

		default:
			sprintf(errmsg, "Invalid PIC family: %d", currentDevice->family);
			fatalError(errmsg);
			break;
	}

	return err;
}

char *writeBaselinePFile(FILE *fp)
{
	hexWriteBegin(fp);
	// write program data
	writeHexBlock(fp, (byte *) currentDevice->program, 0, currentDevice->instlen * 2, currentDevice->instwidth);
	hexWriteEnd(fp);
	return NULL;
}

char *writeMidrangePFile(FILE *fp)
{
	hexWriteBegin(fp);
	// write program data
	writeHexBlock(fp, (byte *) currentDevice->program, 0, currentDevice->instlen * 2, currentDevice->instwidth);
	hexWriteEnd(fp);
	return NULL;
}

char *writePIC18FPFile(FILE *fp)
{
	hexWriteBegin(fp);

	// write program data
	writeHexBlock(fp, (byte *) currentDevice->program, 0, currentDevice->instlen * 2, currentDevice->instwidth);
	hexWriteEnd(fp);
	return NULL;
}

char *writePIC18JPFile(FILE *fp)
{
	writePIC18JFile(fp);
	return NULL;
}

// Write only program data from currentDevice to file

char *writeProgramFile(FILE *fp)
{
	char	*err = NULL;

	switch (currentDevice->family)
	{
		case BASELINE:
			err = writeBaselinePFile(fp);
			break;

		case MIDRANGE:
			err = writeMidrangePFile(fp);
			break;

		case PIC18F:
			err = writePIC18FPFile(fp);
			break;

		case PIC18J:
			err = writePIC18JPFile(fp);
			break;

		default:
			sprintf(errmsg, "Invalid PIC family: %d", currentDevice->family);
			fatalError(errmsg);
			break;
	}

	return err;
}

char *readBaselineDFile(FILE *fp)
{
	int	adrs;
	byte	data1, data2;
	picdev_word	dword;
	bool	done = false;

	while (!done)
	{
		if (!getNextByte(fp, &adrs, &data1))
			done = true;

		if (!getNextByte(fp, &adrs, &data2))
			done = true;

		if (!done);
		{
			adrs /= 2;			// convert to word address
			dword = data2 << 8 | data1;

			if ((adrs >= 0x2100) && (adrs < 0x2200))		// if eeprom data
			{
				adrs -= 0x2100;

				if (adrs < currentDevice->eelen)
					currentDevice->feeprom[adrs] = dword;
			}
		}
	}

	return NULL;
}

char *readMidrangeDFile(FILE *fp)
{
	int	adrs;
	byte	data1, data2;
	picdev_word	dword;
	bool	done = false;

	while (!done)
	{
		if (!getNextByte(fp, &adrs, &data1))
			done = true;

		if (!getNextByte(fp, &adrs, &data2))
			done = true;

		if (!done);
		{
			adrs /= 2;			// convert to word address
			dword = data2 << 8 | data1;

			if ((adrs >= 0x2100) && (adrs < 0x2200))	// eeprom data
			{
				adrs -= 0x2100;

				if (adrs < currentDevice->eelen)
					currentDevice->feeprom[adrs] = dword;
			}
		}
	}

	return NULL;
}

char *readPIC18FDFile(FILE *fp)
{
	int	adrs;
	byte	data1, data2;
	picdev_word	dword;
	bool	done = false;

	while (!done)
	{
		if (!getNextByte(fp, &adrs, &data1))
			done = true;

		if (!getNextByte(fp, &adrs, &data2))
			done = true;

		if (!done);
		{
			adrs += extendedAddress;
			adrs /= 2;			// convert to word address
			dword = data2 << 8 | data1;

			if (adrs >= 0x780000)		// if eeprom data
			{
				adrs *= 2;					// make byte address
				adrs -= 0xf00000;

				if (adrs < currentDevice->eelen)
					currentDevice->feeprom[adrs] = dword;
			}
		}
	}

	return NULL;
}

// Read only EEPROM data from hex file to currentDevice

char *readDataFile(FILE *fp)
{
	int	i;
	picdev_word	data;
	char	*err = NULL;

	initParse();

	if (!currentDevice->fprogram)
		currentDevice->feeprom = malloc(currentDevice->eelen * sizeof(picdev_word));

	data = currentDevice->instwidth;		// clear file data areas

	for (i=0; i<currentDevice->instlen; i++)
		currentDevice->fprogram[i] = data;

	switch (currentDevice->family)
	{
		case BASELINE:
			err = readBaselineDFile(fp);
			break;

		case MIDRANGE:
			err = readMidrangeDFile(fp);
			break;

		case PIC18F:
			err = readPIC18FDFile(fp);
			break;

		case PIC18J:
			fatalError("PIC18J devices have no eeprom");
			break;

		default:
			sprintf(errmsg, "Invalid PIC family: %d", currentDevice->family);
			fatalError(errmsg);
			break;
	}

	return err;
}

char *writeBaselineDFile(FILE *fp)
{
	hexWriteBegin(fp);

	if (currentDevice->eelen)	// write eeprom data
		writeHexBlock(fp, (byte *) currentDevice->eeprom, 0x4200, currentDevice->eelen * 2, 0);

	hexWriteEnd(fp);
	return NULL;
}

char *writeMidrangeDFile(FILE *fp)
{
	hexWriteBegin(fp);

	if (currentDevice->eelen)	// write eeprom data
		writeHexBlock(fp, (byte *) currentDevice->eeprom, 0x4200, currentDevice->eelen * 2, 0);

	hexWriteEnd(fp);
	return NULL;
}

char *writePIC18FDFile(FILE *fp)
{
	hexWriteBegin(fp);

	if (currentDevice->eelen)	// write eeprom data
	{
		writeIntelHexExtendedAddressRecord(fp, 0xf0);
		writeHexBlock18Fdata(fp, (byte *) currentDevice->eeprom, 0, currentDevice->eelen, 0xff);
	}

	hexWriteEnd(fp);
	return NULL;
}

// Write only EEPROM data from currentDevice to file

char *writeDataFile(FILE *fp)
{
	char	*err = NULL;

	switch (currentDevice->family)
	{
		case BASELINE:
			err = writeBaselineDFile(fp);
			break;

		case MIDRANGE:
			err = writeMidrangeDFile(fp);
			break;

		case PIC18F:
			err = writePIC18FDFile(fp);
			break;

		case PIC18J:
			fatalError("PIC18J devices have no eeprom");
			break;

		default:
			sprintf(errmsg, "Invalid PIC family: %d", currentDevice->family);
			fatalError(errmsg);
			break;
	}

	return err;
}

// end


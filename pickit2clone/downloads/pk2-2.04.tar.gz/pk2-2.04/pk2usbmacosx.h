/* HID Report public interafaces
 *
 * Modified and added to pk2 on 6/11/2006 */

#ifndef HIDREPORT_H
#define HIDREPORT_H

#include <CoreFoundation/CoreFoundation.h>

typedef struct hidreport *hidreport_t;
typedef struct hidreport pickit_dev;

extern pickit_dev *deviceHandle;
extern int	usbdebug;

#define REPORT_SIZE 64

/* 
	hidreport_open :  Open HID device for reports.
	returns NULL if error.
*/

hidreport_t hidreport_open(int vendor_id, int product_id, int buffer_size);

void hidreport_close(hidreport_t hid);

/* 
	hidreport_send : send report
	returns non-zero if error.
*/
 
int hidreport_send(hidreport_t rep, void *buf, int size);

/* 
	hidreport_receive : receive report,
	sets *size to the number of bytes received.
	returns non-zero if error.
*/
int hidreport_receive(hidreport_t rep, void *buf, UInt32 *size);

/* 
	hidreport_sendrec : send and receive report,
	returns non-zero if error.
*/
int hidreport_sendrec(hidreport_t rep, void *buf, int size);

/* hooks for pk2 */

void sendUSB(pickit_dev *d, const char *src, int len);

void recvUSB(pickit_dev *d, int len, unsigned char *dest);

pickit_dev *usbPickitOpen(void);

void usb_release_interface(pickit_dev *deviceHandle, int pickit_interface);

#endif
/* EOF */


//
// A USB interface to the Microchip (tm) PICkit 2 (tm) FLASH Starter Kit
// device programmer and breadboard.
// PIC, PICkit2 are registered trademarks of Microchip, Inc.
//
// Maintained by Jeff Post, j_post@pacbell.net
// Last update: 2006/12/02
//
//-----------------------------------------------------------------------------
//
//	This program is free software; you can redistribute it and/or
//	modify it under the terms of the GNU General Public License
//	as published by the Free Software Foundation; either version 2
//	of the License, or (at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program; if not, write to the Free Software
//	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//-----------------------------------------------------------------------------
//
//#define USB_DEBUG
// Comment out the following line if you do not use usb hotplug
#define	USB_HOTPLUG

#include	<stdio.h>
#include <usb.h>			// libusb header
#include <unistd.h>		// for geteuid
#include	<ctype.h>
#include	<string.h>

#include "pk2.h"
#include	"pk2usb.h"
#include	"pk2progress.h"

/* Stupidity:
  In an excellent example of sacrificing backward compatability
for conformance to some proported "standard", the latest Linux 
kernel USB drivers (uhci-alternate in 2.4.24+, and uhci in 2.6.x)
no longer support low speed bulk mode transfers-- they give
"invalid argument", errno=-22, on any attempt to do a low speed 
bulk write.  Thus, we need interrupt mode transfers, which are 
only available via the CVS version of libusb.

(Thanks to Steven Michalske for diagnosing the true problem here.)
*/

#if HAVE_LIBUSB_INTERRUPT_MODE
// latest libusb: interrupt mode, works with all kernels
#  define PICKIT_USB(direction) usb_interrupt_##direction
#else 
// older libusb: bulk mode, will only work with older kernels
#  define PICKIT_USB(direction) usb_bulk_##direction
#endif

// Prototypes

// Data

usb_dev_handle	*deviceHandle = NULL;

int	pickit2mode = 0;

// PICkit USB values

const static int pickit_vendorID = 0x04d8;	// Microchip, Inc
const static int pickit_productID = 0x0033;	// PICkit 2 FLASH starter kit

int	pickit_interface = 0;
int	usbdebug = 0;

const static int pickit_endpoint_out = 1;		// endpoint 1 address for OUT
const static int pickit_endpoint_in = 0x81;	// endpoint 0x81 address for IN
const static int pickit_timeout = 10000;		// timeout in ms

// Send 64 byte block to PICkit2

void sendUSB(pickit_dev *d, const char *src, int len)
{
	int	r, i;

	if (usbdebug)
	{
		printf("USB>");

		for (r=0, i=0; r<len; r++)
		{
			printf(" %02x", src[r] & 0xff);
			i++;

			if ((i > 15) && (i < (len - 1)))
			{
				i = 0;
				printf("\n    ");
			}
		}

		printf("\n");
	}

	r = PICKIT_USB(write)(d, pickit_endpoint_out, (char *) src, reqLen, pickit_timeout);

	if (r != reqLen)
	{
		perror("sendUSB() PICkit write ");
		fatalError("sendUSB() PICkit USB write failed");
	}
}

int readBlock(pickit_dev *d, int len, byte *dest)
{
	int	i, j, r;
	byte	bfr[reqLen + 1];

	r = PICKIT_USB(read)(d, pickit_endpoint_in, (char *) bfr, reqLen, pickit_timeout);

	if (r != reqLen)
		fatalError("USB read did not return 64 bytes");

	if (usbdebug == 2)
		printf("USB<");

	for (i=0, j=0; i<len; i++)
	{
		if (usbdebug == 2)
		{
			printf(" %02x", bfr[i] & 0xff);
			j++;

			if ((j > 15) && (i < (len - 1)))
			{
				j = 0;
				printf("\n    ");
			}
		}

		dest[i] = bfr[i];
	}

	if (usbdebug == 2)
		printf("\n");

	return len;
}

// Read this many bytes from this device

void recvUSB(pickit_dev *d, int len, byte *dest)
{
	int r = readBlock(d, len, dest);

	if (r != len)
	{
		perror("recvUSB() PICkit read");
		fatalError("recvUSB() PICkit USB read failed");
	}
}

// debugging: enable debugging error messages in libusb
#ifndef WIN32
extern int usb_debug;
#endif

// Find the first USB device with this vendor and product.
// Exits on errors, like if the device couldn't be found.

pickit_dev *usbPickitOpen(void)
{
	int	result;
	struct usb_device	*device;
	struct usb_bus		*bus;
#ifdef LINUX
#ifndef USE_DETACH
	char	syscmd[64];
#endif
#endif

// remove call to geteuid() for Windows
#ifndef WIN32
#ifndef USB_HOTPLUG
	if (geteuid() != 0)
		fatalError("This program must be run as root, or made setuid root");
#endif
#endif

#ifndef WIN32
#ifdef USB_DEBUG
	usb_debug = 4; 
	usb_set_debug(255);
//	printf("setting USB debug on by adding usb_set_debug(255) \n");
#endif
#endif

	printf("\nLocating USB Microchip PICkit2 (vendor 0x%04x/product 0x%04x)\n",
		pickit_vendorID, pickit_productID);
  // (libusb setup code stolen from John Fremlin's cool "usb-robot")

	usb_init();
	result = usb_find_busses();

	if (result < 0)
		printf("Error finding USB busses: %d\n", result);

	result = usb_find_devices();

	if (result < 0)
		printf("Error finding USB devices: %d\n", result);

//  printf("**** RW -End usb_find_devices().\n");
  
	for (bus = usb_get_busses(); bus != NULL; bus = bus->next)
	{
		struct usb_device* usb_devices = bus->devices;

		for (device = usb_devices; device != NULL; device = device->next)
		{
			if (device->descriptor.idVendor == pickit_vendorID
				&&device->descriptor.idProduct == pickit_productID)
			{
				usb_dev_handle *d;

				printf( "Found USB PICkit as device '%s' on USB bus %s\n",
					device->filename,
					device->bus->dirname);

				d = usb_open(device);
				deviceHandle = d;

				if (d)
				{			// This is our device
					byte retData[reqLen + 1];
#ifdef LINUX
					{
						int retval;
						char dname[32] = {0};

						retval = usb_get_driver_np(d, 0, dname, 31);
#ifndef USE_DETACH
						if (!retval)
						{
							strcpy(syscmd, "rmmod ");
							strcat(syscmd, dname);
//			printf("removing driver module: %s\n", syscmd);
							system(syscmd);
						}
#else
						if (!retval)
							usb_detach_kernel_driver_np(d, 0);
#endif
					}
#endif

#ifdef CLAIM_USB

					if (usb_set_configuration(d, CONFIG_VENDOR))	// if config fails with CONFIG_VENDOR,
					{
						if (usb_set_configuration(d, CONFIG_HID))	// it may be in bootloader, try CONFIG_HID
							fatalError("Error setting USB configuration.\n");
					}

					if (usb_claim_interface(d, pickit_interface))
					{
						fatalError("Claim failed-- the USB PICkit2 is in use by another driver.\n"
							"Do a `dmesg` to see which kernel driver has claimed it--\n"
							"You may need to `rmmod hid` or patch your kernel's hid driver.\n");
					}
#endif

					cmd[0] = GETVERSION;
					sendPickitCmd(d, cmd, 1);
					recvUSB(d, 8, retData);

					if (retData[5] == 'B')
					{
						printf("Communication established. PICkit2 bootloader firmware version is %d.%d\n",
							(int) retData[6], (int) retData[7]);
						pickit2mode = BOOTLOAD_MODE;
						pickit2firmware = (((int) retData[6]) << 8) | (((int) retData[7]) & 0xff);
					}
					else
					{
						printf("Communication established. PICkit2 firmware version is %d.%d.%d\n",
							(int) retData[0], (int) retData[1], (int) retData[2]);
						pickit2mode = NORMAL_MODE;
						pickit2firmware = (((int) retData[0]) << 16) | ((((int) retData[1]) << 8) & 0xff00) | (((int) retData[2]) & 0xff);

						if (pickit2firmware >= 0x20000)
							fatalError("This version of pk2 does not support firmware version 2");
					}

					if (pickit2mode == NORMAL_MODE)	// this upsets the bootloader
					{
//						Turn off power to the chip before doing anything.
//						This prevents weird random errors during programming.
//						( Thanks to Curtis Sell for this fix. )
//
//						printf("About to turn OFF the Pickit!\n");

						pickitOff(d);
					}

					return d;
				}
				else 
					fatalError("Open failed for USB device");
			}
			// else some other vendor's device-- keep looking...
		}
	}

	fatalError("Could not find PICkit2 programmer--\n"
		"you might try lsusb to see if it's actually there.");
	return NULL;
}

// end

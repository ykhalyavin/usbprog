
/* 
 * HID Report for MacOSX 
 * written by skimu@mac.com
 *
 * Modified and added to pk2 on 2006/06/11
 * Last update 2006/10/06
 */

#ifdef MACOSX_HID

#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOKitLib.h>
#include <IOKit/IOCFPlugIn.h>
#include <IOKit/IOMessage.h>
#include <IOKit/hid/IOHIDLib.h>
/*
#include <IOKit/hid/IOHIDKeys.h>
#include <IOKit/hidsystem/IOHIDLib.h>
#include <IOKit/hidsystem/IOHIDShared.h>
#include <IOKit/hidsystem/IOHIDParameter.h>
*/

#include	"pk2.h"
#include	"pk2usbmacosx.h"

struct hidreport {
 	IOHIDDeviceInterface122 **intf;
	char	*buffer;
 	int	size;
 	int	size_received;
 	int	timeout;
};

pickit_dev	*deviceHandle;
int	pickit_interface = 0;
int	pickit2mode = 0;
int	usbdebug = 0;

/*
 * 	  Private functions
 */

static void set_number_to_dictionary(CFMutableDictionaryRef dic, const void *key, SInt32 num)
{
	CFNumberRef	n;

	n = CFNumberCreate(kCFAllocatorDefault, kCFNumberSInt32Type, &num);
	CFDictionarySetValue(dic, key, n);
	CFRelease(n);
}			

static IOHIDDeviceInterface122 **find_device(SInt32 vendor, SInt32 product)
{
	IOReturn	r;
	SInt32	score;
	IOCFPlugInInterface		**pif;
	IOHIDDeviceInterface122	**devif;
	CFMutableDictionaryRef	dict;
	io_service_t	service;

	dict = IOServiceMatching(kIOHIDDeviceKey);
	set_number_to_dictionary(dict, CFSTR(kIOHIDVendorIDKey),  vendor);
	set_number_to_dictionary(dict, CFSTR(kIOHIDProductIDKey), product);
	service = IOServiceGetMatchingService(kIOMasterPortDefault, dict);

	if (!service)
		return NULL;

	r = IOCreatePlugInInterfaceForService(service,
		kIOHIDDeviceUserClientTypeID,
		kIOCFPlugInInterfaceID,
		&pif,
		&score);

	if (r != kIOReturnSuccess)
		return NULL;

	r = (*pif)->QueryInterface(pif,
		CFUUIDGetUUIDBytes(kIOHIDDeviceInterfaceID122),
		(LPVOID) &devif);

	(*pif)->Release(pif);

	if (r || !devif)
		return NULL;

	return devif;
}

static void interrupt_report_callback_func(void *target,
	IOReturn	result,
	void		*refcon,
	void		*sender,
	UInt32	size)
{
	hidreport_t rep = target;

	if (rep->size_received != 0)
		fprintf(stderr, "Warining: previous report has not been read.\n");

	rep->size_received = size;
	CFRunLoopStop(CFRunLoopGetCurrent());
}

static void setup_notification(hidreport_t rep)
{
	IOReturn		r;
	mach_port_t	port;
	CFRunLoopSourceRef	es;

	IOHIDDeviceInterface122 **devif;
	devif = rep->intf;
	rep->size_received = 0;
	r = (*devif)->open(devif, 0);
	r = (*devif)->createAsyncPort(devif, &port);
	r = (*devif)->createAsyncEventSource(devif, &es);
	r = (*devif)->setInterruptReportHandlerCallback(
		devif, 
		rep->buffer, rep->size, 
		interrupt_report_callback_func, 
		rep, NULL);
	CFRunLoopAddSource(CFRunLoopGetCurrent(), es, kCFRunLoopDefaultMode);
}

/*
 * 	 Public functions
 */

hidreport_t hidreport_open(int vendor_id, int product_id, int report_size)
{
	IOHIDDeviceInterface122 **intf;
	hidreport_t rep;

	intf = find_device(vendor_id, product_id);

	if (intf == NULL)
		return NULL;

	if ((rep = (hidreport_t) malloc(sizeof(struct hidreport))) == NULL)
		return NULL;

	rep->intf = intf;

	if ((rep->buffer = (char *) malloc(report_size)) == NULL)
		return NULL;

	rep->size = report_size;
	rep->size_received = 0;
	rep->timeout = 500;			// ms
	setup_notification(rep);
	return rep;
}

void hidreport_close(hidreport_t rep)
{
	(*rep->intf)->close(rep->intf);
	free(rep->buffer);
	free(rep);
	rep = NULL;
}

int hidreport_send(hidreport_t rep, void *buf, int size)
{
	IOReturn	r;

	rep->size_received = 0;
	r = (*rep->intf)->setReport(rep->intf, kIOHIDReportTypeOutput, 1, buf, size,
		rep->timeout, NULL, NULL, NULL);
	return r;
}

int hidreport_receive(hidreport_t rep, void *buf, UInt32 *size)
{
	while (rep->size_received == 0)
		CFRunLoopRun();

	memcpy(buf, rep->buffer, rep->size_received);
	*size = rep->size_received;
	rep->size_received = 0;
	return 0;
}

void sendUSB(pickit_dev *d, const char *src, int len)
{
	int	r, i;
	char	buf[REPORT_SIZE + 1];

	bzero(buf, REPORT_SIZE + 1);
	memcpy(buf, src, REPORT_SIZE);

	if (usbdebug)
	{
		printf("USB>");

		for (r=0, i=0; r<len; r++)
		{
			printf(" %02x", src[r] & 0xff);
			i++;

			if ((i > 15) && (i < (len - 1)))
			{
				i = 0;
				printf("\n    ");
			}
		}

		printf("\n");
	}

	hidreport_send((hidreport_t)d, buf, REPORT_SIZE);
}

void recvUSB(pickit_dev *d, int len, unsigned char *dest)
{
	UInt32	size, i, j;
	unsigned char	buf[REPORT_SIZE + 1];

	i = 0;

	while (i < len)
	{
		bzero(buf, REPORT_SIZE + 1);
		hidreport_receive((hidreport_t) d, buf, &size);

		for (j=0; j<size && i<len; j++)
			dest[i++] = buf[j];
	}

	if (usbdebug == 2)
	{
		printf("USB<");

		for (i=0, j=0; i<len; i++)
		{
			printf(" %02x", buf[i] & 0xff);
			j++;

			if ((j > 15) && (i < (len - 1)))
			{
				j = 0;
				printf("\n    ");
			}
		}

		printf("\n");
	}
}

pickit_dev *usbPickitOpen(void)
{
	pickit_dev	*pickit2;
	byte			retData[reqLen + 1];

	pickit2 = hidreport_open(1240, 51, REPORT_SIZE);		// 0x04d8, 0x0033 PICkit2

	if (pickit2 != NULL)
	{
		deviceHandle = pickit2;
		pickit_interface = 1;

		cmd[0] = GETVERSION;
		sendPickitCmd(pickit2, cmd, 1);
		recvUSB(pickit2, reqLen, retData);

		if (retData[5] == 'B')
		{
			printf("Communication established. PICkit2 bootloader firmware version is %d.%d\n",
				(int) retData[6], (int) retData[7]);
			pickit2mode = BOOTLOAD_MODE;
			pickit2firmware = (((int) retData[6]) << 8) | (((int) retData[7]) & 0xff);
		}
		else
		{
			printf("Communication established. PICkit2 firmware version is %d.%d.%d\n",
				(int) retData[0], (int) retData[1], (int) retData[2]);
			pickit2mode = NORMAL_MODE;
			pickit2firmware = (((int) retData[0]) << 16) | ((((int) retData[1]) << 8) & 0xff00) | (((int) retData[2]) & 0xff);

			if (pickit2firmware >= 0x20000)
				fatalError("This version of pk2 does not support firmware version 2");
		}

		if (pickit2mode == NORMAL_MODE) // this upsets the bootloader
		{
			// Turn off power to the chip before doing anything.
			// This prevents weird random errors during programming.
			// (Thanks to Curtis Sell for this fix.)

			pickitOff(pickit2);
		}
	}

	return(pickit2);
}

void usb_release_interface(pickit_dev *deviceHandle, int pickit_interface)
{
	if (deviceHandle != NULL)
		hidreport_close(deviceHandle);

	pickit_interface = 0;
}

#endif // MacOSX

// EOF


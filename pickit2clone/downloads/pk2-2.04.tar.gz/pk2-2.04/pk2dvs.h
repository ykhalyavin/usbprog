//
// Structure of data in binary PICkit2.dvs file
// Jeff Post, j_post@pacbell.net
// Last update: 2006/05/28
//
// Based on information provided by Microchip, Inc.
// PIC, PICkit2 are registered trademarks of Microchip, Inc.
//
//-----------------------------------------------------------------------------
//
//	This program is free software; you can redistribute it and/or
//	modify it under the terms of the GNU General Public License
//	as published by the Free Software Foundation; either version 2
//	of the License, or (at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program; if not, write to the Free Software
//	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//-----------------------------------------------------------------------------
//
#ifndef _PK2DVS_H
#define _PK2DVS_H

#define	bool	unsigned char

// Use 'entrySize' instead of sizeof(struct DeviceType)
// because the compiler will pad out the structure and
// the binary file does not.
#define	entrySize	75

struct DeviceType
{
	char				Name [13];
	char				Family;			// '2' - 12 bit family,
											// '6' - 14 bit,
											// '8' - PIC18F
											// 'J' - PIC18J
	unsigned char	ID[4];
	unsigned char	ProgMemSize[4];
	unsigned char	EEMemSize[4];
	unsigned char	TestMemSize[4];
	bool				SaveOscCal;		// boolean, Y or N
	bool				SaveBGBits;
	bool				IncludeUnusedBits;
	unsigned char	PgmModeEntry;	// Programming command sent to firmware
	char				PgmMode;			// '1' or '4' for Midrange,
											// n for Midrange and PIC18F
	unsigned char	nValue;			// Width of programming at a time
											// (used with n method above)
	char				PgmTiming;		// Program Write Timing: n - Write
											// by n, externally timed,
											// N - Write by n internally timed;
											// W - write by 1 externally timed,
											// w - write by 1 internally timed
	char				DataTiming;		// EE Data Write timing:
											// D - Internally timed,
											// d - Externally Timed
	char				EraseMode;		// '1' or '2' (PIC18F only so far)
	unsigned char	BandGapMask[4];	// 1's for BandGap bits
	unsigned char	ConfigMask[7][4];	// 1's for valid bits,
											// 0 for unused or reserved bits
	unsigned char	CPMask[4];		// 1's for the CP bits
};

// Firmware commands (for reference):

#define	ANALOG 'A'
#define	ENTERBOOTLOADER 'B'
#define	CMDTABLE 'c'
#define	WRITECONFIG 'C'
#define	WRITEDATA 'D'
#define	WRITEDATAEXT 'd'
#define	ERASEPGM 'E'
#define	ERASEDATA 'e'
#define	INCADDRESS 'I'
#define	WRITEBYnEXT 'n'
#define	WRITEBYnINT 'N'
#define	ENTERPGMVDD1ST 'O'
#define	ENTERPGM 'P'
#define	EXITPGM 'p'
#define	READDATA 'r'
#define	READPGM 'R'
#define	WRITEPGM 'W'
#define	WRITEPGMEXT 'w'
#define	CHKSUM 'S'
#define	SETVDDVPP 's'
#define	GETVERSION 'v'
#define	POWERCTRL 'V'
#define	NULLCMD 'Z'
#define	WRITEBYFOUR '4'
#define	PIC18FREAD  0x80
#define	PIC18FEEDATAREAD 0x81
#define	PIC18FWRITE_1 0x82
#define	PIC18FWRITE_2 0x83
#define	PIC18FWRITECONFIG 0x84
#define	PIC18FERASE 0x85
#define	PIC18FERASE1 0x86
#define	PIC18FEEDATAWRITE 0x87
#define	VDDVPPSTATUS		'M'

// Family Definitions
#define	BASELINE  = '2'	// 12 bit
#define	MIDRANGE  = '6'	// 14 bit
#define	PIC18F    = '8'	// 16 bit
#define	PIC18J    = 'J'	// PIC18J 16 bit

#endif

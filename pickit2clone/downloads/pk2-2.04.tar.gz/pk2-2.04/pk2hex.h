//
// Intel MDS .hex file read and writer.
//
// Maintained by Jeff Post, j_post@pacbell.net
// Last update: 2006/05/31
//
//-----------------------------------------------------------------------------
//
//	This program is free software; you can redistribute it and/or
//	modify it under the terms of the GNU General Public License
//	as published by the Free Software Foundation; either version 2
//	of the License, or (at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program; if not, write to the Free Software
//	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//-----------------------------------------------------------------------------
//
#ifndef _PK2HEX_H_
#define _PK2HEX_H_

#include <stdio.h>

char	*readHexFile(FILE *fp);			// read entire hex file
char	*writeHexFile(FILE *fp);		// write entire hex file
char	*readProgramFile(FILE *fp);	// read program data
char	*writeProgramFile(FILE *fp);	// write program data
char	*readDataFile(FILE *fp);		// read EEPROM data
char	*writeDataFile(FILE *fp);		// write EEPROM data
void	hexWriteBegin(FILE *f);
void	hexWriteEnd(FILE *f);
void	writeHexBlock(FILE *fp, byte *bfr, int address, int size, picdev_word blankData);
void	initParse(void);
bool	getNextByte(FILE *fp, int *address, byte *data);

#endif

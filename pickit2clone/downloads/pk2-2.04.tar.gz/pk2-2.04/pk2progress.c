/* -----------------------------------------------------
	Progress bar handling
	Alain Gibaud 2006
	alain.gibaud@free.fr
*/
//
//-----------------------------------------------------------------------------
//
//	This program is free software; you can redistribute it and/or
//	modify it under the terms of the GNU General Public License
//	as published by the Free Software Foundation; either version 2
//	of the License, or (at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program; if not, write to the Free Software
//	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//-----------------------------------------------------------------------------
//

static int	total_step;			// total step to be performed 
static int	current_step;		// current step
static int	progress_value;	// current percentage, computed from current_step
static void	(*progress_client)(int) = 0;	// display progress hook

int progress_init(int total_step_)
{
	total_step = total_step_;
	current_step = 0;
	progress_value = 0;

	if (progress_client)
		progress_client(progress_value);

	return total_step;
}

//
//	\brief Jump to specified step ( 0 <= step <= total_step )
//	\return The current progress percentage
//

int progress_jump(int step)
{
	int	progress = (int)(100.0 * ((double)step / total_step));

	current_step = step;

	if (progress > 100)
		progress = 100;

	if (progress != progress_value)
	{
		progress_value = progress;

		if (progress_client)
			progress_client(progress_value);
	}

	return progress_value;  	
}

//
//	\brief Move k steps
//	\return The current progress percentage
//

int progress_update(int k)
{
	return progress_jump(current_step + k);
}

void progress_connect(void(*p)(int))
{
	progress_client = p;
}	

// end

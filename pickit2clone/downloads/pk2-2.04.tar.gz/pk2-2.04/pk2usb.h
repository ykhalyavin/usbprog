//
// A USB interface to the Microchip(tm) PICkit(tm) 2 FLASH Starter Kit
// device programmer and breadboard.
// PIC, PICkit2 are registered trademarks of Microchip, Inc.
//
// Maintained by Jeff Post, j_post@pacbell.net
// Last update: 2006/06/14
//
//-----------------------------------------------------------------------------
//
//	This program is free software; you can redistribute it and/or
//	modify it under the terms of the GNU General Public License
//	as published by the Free Software Foundation; either version 2
//	of the License, or (at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program; if not, write to the Free Software
//	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//-----------------------------------------------------------------------------
//
#ifndef _PK2USB_H
#define _PK2USB_H

#include	<usb.h>

extern usb_dev_handle	*deviceHandle;

extern int	pickit_interface;
extern int	pickit2mode;
extern int	usbdebug;

/* Send data over usb */
void sendUSB(pickit_dev *d, const char *src, int len);

/* Read data from usb */
void recvUSB(pickit_dev *d, int len, byte *dest);

/** Open the pickit as a usb device.  Aborts on errors. */
pickit_dev *usbPickitOpen(void);

#endif

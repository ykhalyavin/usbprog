//
// A USB interface to the Microchip(tm) PICkit(tm) 2 FLASH Starter Kit
// device programmer and breadboard.
// PIC, PICkit2 are registered trademarks of Microchip, Inc.
//
// Maintained by Jeff Post, j_post@pacbell.net
// Last update: 2006/12/17
//
//-----------------------------------------------------------------------------
//
//	This program is free software; you can redistribute it and/or
//	modify it under the terms of the GNU General Public License
//	as published by the Free Software Foundation; either version 2
//	of the License, or (at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program; if not, write to the Free Software
//	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//-----------------------------------------------------------------------------
//
#ifndef _PK2_H
#define _PK2_H

// Last update
#define	YEAR		2006
#define	MONTH		12
#define	DAY		17

#define	VERSION		2
#define	REVISION		4

//#define	ALPHA	1	// comment out for release versions
//#define	BETA	1	// comment out for release versions

#ifndef MACOSX_HID
#include	<usb.h>
#else
#include	<stdlib.h>
#include	<unistd.h>
#include	"pk2usbmacosx.h"
#endif

#ifdef WIN32
#include	<windows.h>
#define	usleep(x)	Sleep(x/1000)
#endif

#ifndef	FALSE
#define	FALSE	0
#endif
#ifndef	TRUE
#define	TRUE	1
#endif

#define	reqLen	64			// PICkit 2 always uses 64-byte transfers

#ifndef __bool_true_false_are_defined
#define	bool	int
#endif
#define	byte	unsigned char
#define	littleEndian	0
#define	bigEndian		1

#define	CONFIG_HID		1	// Use HID for pickit configuration
#define	CONFIG_VENDOR	2	// Vendor specific configuration

#define	NORMAL_MODE		1
#define	BOOTLOAD_MODE	2

// Program Mode options (bit flags)
// If option is 0, then program entire hex file.
// PROG_PGM and PROG_DATA cannot both be true.

#define	PROG_DRY			1	// dry run, don't acutually program anything
#define	PROG_PGM			2	// write program memory only
#define	PROG_DATA		4	// write eeprom only
#define	PROG_NOVERIFY	8	// do not verify before writing config word

// Device types

#define	BASELINE	12
#define	MIDRANGE	14
#define	PIC18F	16
#define	PIC18J	20

// PICkit2 commands

#define	WRITEBYFOUR			'4'	// 0x34
#define	ANALOG				'A'	// 0x41
#define	ENTERBOOTLOADER	'B'	// 0x42
#define	WRITECONFIG			'C'	// 0x43
#define	WRITEDATA			'D'	// 0x44
#define	ERASEPGM				'E'	// 0x45
#define	INCADDRESS			'I'	// 0x49
#define	VDDVPPSTATUS		'M'	// 0x4d
#define	WRITEBYnINT			'N'	// 0x4e
#define	ENTERPGMVDD1ST		'O'	// 0x4f
#define	ENTERPGM				'P'	// 0x50
#define	READPGM				'R'	// 0x52
#define	CHKSUM				'S'	// 0x53
#define	POWERCTRL			'V'	// 0x56
#define	WRITEPGM				'W'	// 0x57
#define	NULLCMD				'Z'	// 0x5a
#define	CMDTABLE				'c'	// 0x63
#define	WRITEDATAEXT		'd'	// 0x64
#define	ERASEDATA			'e'	// 0x65
#define	WRITEBYnEXT			'n'	// 0x6e
#define	EXITPGM				'p'	// 0x70
#define	READDATA				'r'	// 0x72
#define	SETVDDVPP			's'	// 0x73
#define	GETVERSION			'v'	// 0x76
#define	WRITEPGMEXT			'w'	// 0x77
#define	PIC18FREAD			0x80
#define	PIC18FEEDATAREAD	0x81
#define	PIC18FWRITE_1		0x82
#define	PIC18FWRITE_2		0x83
#define	PIC18FWRITECONFIG	0x84
#define	PIC18FERASE			0x85
#define	PIC18FERASE1		0x86
#define	PIC18FEEDATAWRITE	0x87
#define	PIC18J_ENTERPROG	0x90
#define	PIC18J_EXITPROG	0x91
#define	PIC18J_ERASE		0x92
#define	PIC18J_BUFFER32	0x93
#define	PIC18J_WRITE64		0x94

// Bootloader commands

#define	READFWFLASH		1
#define	WRITEFWFLASH	2
#define	ERASEFWFLASH	3
#define	READFWEEDATA	4
#define	WRITEFWEEDATA	5
#define	RESETFWDEVICE	0xff

#define	picdev_id_len	4u			// max id length

#ifndef MACOSX_HID
typedef struct usb_dev_handle pickit_dev;
#endif

typedef unsigned short picdev_word;

typedef struct picdev {
	int	devid;
	int	family;
	int	cmdtbl;		// command table entry number
	char	*devname;
	int	instlen;		// size of program memory
	int	instwidth;	// width of program word (12/14/16 bits)
	int	writeBurst;	// words to write at a time
	int	pgmCommand;	// program command to PICkit2 firmware (pgmModeEntry)
	int	pgmMode;		// programming mode 1, 4, or n
	int	pgmTiming;	// write timing: n, N, w, W
	int	dataTiming;	// EE data write timing: d or D
	int	eraseMode;	// 1 or 2 (PIC18F)
	int	eelen;
	int	IDstart;
	int	IDlen;
	bool	saveOscCal;
	bool	saveBGBits;
	bool	incBits;
	picdev_word	osccal;			// oscillator calibration bits
	picdev_word	bosccal;			// backup osccal (baseline only)
	picdev_word	fosccal;			// file oscillator calibration bits
	picdev_word	CPMask;			// code protection bits
	picdev_word	BGMask[2];		// band gap mask
	picdev_word	bandGap[2];		// actual band gap
	picdev_word	configMask[7];	// valid config bits
	picdev_word	config[7];		// actual config bits
	picdev_word	fconfig[7];		// file config bits
	picdev_word	ID[4];			// ID words
	picdev_word	fID[4];			// file ID words
	picdev_word	*program;		// pointer to program space
	picdev_word	*eeprom;			// pointer to eeprom data
	picdev_word	*fprogram;		// pointer to program space from file
	picdev_word	*feeprom;		// pointer to eeprom data from file
	struct picdev	*next;
} picdevice;

extern char cmd[reqLen + 1];

#define	CMDTBLSIZE	16

struct cmdtblentry {
	const unsigned char entry[CMDTBLSIZE];
};

extern struct cmdtblentry CommandTable[];

extern int			endian;
extern picdevice	*currentDevice;
extern picdevice	*devList;
extern int			devCount;
extern char			*deviceName;
extern int			pickit_interface;
extern int			pickit2mode;
extern int			pickit2firmware;

// Prototypes for routines in pk2ctrl.c

void	sendPickitCmd(pickit_dev *d, const char *src, int len);
void	readDeviceData(void);
void	sortDeviceData(void);
void	removeDuplicateData(void);
picdevice	*findDeviceName(char *name);
int	ascii2hex(char *str);
void	fatalError(const char *why);
void	warning(const char *why);
void	pickitOn(pickit_dev *d);
void	pickitOff(pickit_dev *d);
const char	*pickitGetDevice(pickit_dev *d);
void	pickitReadProgram(pickit_dev *d);
void	pickitReadConfig(pickit_dev *d);
void	pickitReadEeprom(pickit_dev *d);
void	pickitRead(pickit_dev *d);
void	pickitWrite(pickit_dev *d, int options);
void	pickitErase(pickit_dev *d, int keepEeprom);
void	pickitWriteProgram(pickit_dev *d);
void	pickitWriteConfig(pickit_dev *d);
void	pickitWriteConfigWords(pickit_dev *d, int count, int cfg[]);
void	pickitWriteIDWords(pickit_dev *d, int count, int ID[]);
void	pickitWriteOsccal(pickit_dev *d, int osccal, int flag);
void	pickitPrintConfig(pickit_dev *d);
int	checkVoltageStatus(pickit_dev *d, int *vdd, int *vpp);

#endif

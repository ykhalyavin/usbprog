//
// Main program-- command-line argument handling and top-level control.
// PIC and PICkit2 are registered trademarks of Microchip, Inc.
//
// Copyright 2005-2006 by Jeff Post, j_post@pacbell.net
// Last update: 2006/12/15
//
//-----------------------------------------------------------------------------
//
//	This program is free software; you can redistribute it and/or
//	modify it under the terms of the GNU General Public License
//	as published by the Free Software Foundation; either version 2
//	of the License, or (at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program; if not, write to the Free Software
//	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//-----------------------------------------------------------------------------
//
#include <stdlib.h>
#include	<unistd.h>
#include <string.h>
#include	<ctype.h>

#include "pk2.h"
#ifndef MACOSX_HID
#include "pk2usb.h"
#endif
#include	"pk2hex.h"
#ifndef WIN32
#include	"pk2progress.h"
#endif

#define	FIRMWARE_START	0x2000	// start of PICkit2 firmware
#define	FIRMWARE_SIZE	0x6000	// max size of 18F2550 firmware (0x2000-0x7fff)
#define	BOOT_SIZE		0x2000	// max size of bootloader firmware
#define	READ_FW_FLAG	0
#define	READ_BOOT_FLAG	1

// These should be large enough for anyone
#define	MAX_OPTION		32			// maximum number of command options
#define	MAX_PARAMETER	16			// maximum number of parameters for each option

struct command {
	char	*funcName;		// function name
	int	option;			// command options
	int	openflag;		// open usb device
	void	(*func)(void);	// pointer to exec function
	char	*help;			// pointer to help text
};

struct commandList {
	int	id;				// index of cmdTable entry
	int	pcount;			// parameter count
	char	*cmd;				// actual command line argument
	char	*parms[MAX_PARAMETER];		// pointers to parameters
} cmdList[MAX_OPTION];

// Prototypes

const char	*programMode(pickit_dev *d);
const char	*readMode(pickit_dev *d);
const char	*verifyMode(pickit_dev *d);
const char	*eepromMode(pickit_dev *d);
const char	*blankCheck(pickit_dev *d);
const char	*eraseMode(pickit_dev *d);
const char	*configMode(pickit_dev *d);
const char	*resetMode(pickit_dev *d);
const char	*offMode(pickit_dev *d);
const char	*onMode(pickit_dev *d);
const char	*osccalCheck(void);
const char	*osccalMode(pickit_dev *d);
const char	*deviceMode(pickit_dev *d);
const char	*firmwareMode(pickit_dev *d);
const char	*bootLoadMode(pickit_dev *d);
const char	*readBootMode(pickit_dev *d);
const char	*readProgramMode(pickit_dev *d);
const char	*resetFW(pickit_dev *d);
const char	*exitBoot(pickit_dev *d);
const char	*helpMode(void);
const char	*licenseMode(void);
const char	*listMode(void);
const char	*usbDebugMode(void);
const char	*IDCheck(void);
const char	*idMode(pickit_dev *d);
#ifndef WIN32
const char	*progressMode(void);
void	progressHook(int state);
#endif
const char	*voltageMode(pickit_dev *d);

void	enterBootLoader(pickit_dev *d);
void	setFWbootFlag(pickit_dev *d);
int	findBestMatch(char *func);

// Global variables

pickit_dev *devicePtr = NULL;

/* All compilers may not define BIG_ENDIAN and LITTLE_ENDIAN, so we'll test
   to determine which type machine pk2 is running on */
int	endian = littleEndian;	// default to Intel

int	dryRun = 0;
int	currentCmd = 0;
struct commandList	*thisCommand = NULL;

char	blankHelpText[] = "\n  Verify target device is erased.";
char	configHelpText[] = "\n  Show configuration data.\n"
		"pk2 -config <hex hex ...>\n  Set configuration word(s) to <hex> data."
		"\n  <hex> is a hexadecimal number in the form 0x1234 or just 1234.";
char	deviceHelpText[] = "\n  Show target device.\n"
		"pk2 -device=picdev\n  Set target device type to \"picdev\" (must be before other options).\n"
		"pk2 -device=picdev?\n  Show parameters for target device type \"picdev\".";
char	dryrunHelpText[] = " <file>\n  Same as -write, but doesn't actually program anything."
		"\n  (outputs information about what would be written).";
char	eraseHelpText[] = "\n  Erase target device.";
char	eraseallHelpText[] = "\n  Erase target device including osccal.";
char	exitbootHelpText[] = "\n  Exit bootloader (use only if PICkit2 stuck in bootloader).";
char	firmwareHelpText[] = "\n  Show PICkit2 firmware version.\n"
		"pk2 -firmare <file>\n  Read PICkit2 firmware into hex file."
		"\n  <file> is an Intel MDS hex file.";
char	helpHelpText[] = " <command>\n  Show list of commands or details of a specific command."
		"\npk2 -help all"
		"\n  Show details for all commands.";
char	idmodeHelpText[] = "  <hex ...>\n  Set ID word(s) to <hex ...> data.";
char	IDCheckHelpText[] = "\n  Display supported chips with no ID or duplicated ID.";
char	licenseHelpText[] = "\n Display pk2 software licence.";
char	listHelpText[] = "\n  List supported devices."
		"\npk2 -list <family>"
		"\n  Display devices in a family (baseline, midrange, pic18f, pic18j).";
char	offHelpText[] = "\n  Turn target power off.";
char	onHelpText[] = "\n  Turn target power on.";
char	osccalHelpText[] = " <hex>\n  Set osccal to <hex> data."
		"\n  <hex> is a hexadecimal number in the form 0x1234 or just 1234."
		"\npk2 -osccal ?"
		"\n  Show devices with osccal.";
char	osccalbHelpText[] = " <hex>\n  Write only backup osccal for baseline device.";
char	osccalpHelpText[] = " <hex>\n  Write only primary osccal for baseline device.";
char	progressHelpText[] = "\n  Display progress information (pikdev support).";
char	readHelpText[] = " <file>\n  Read from target device into hex file."
		"\n  <file> is an Intel MDS hex file.";
char	readbootHelpText[] = " <file>\n  Read bootloader firmware into hex file."
		"\n  <file> is an Intel MDS hex file.";
char	readdataHelpText[] = " <file>\n  Read eeprom data from target device into hex file."
		"\n  <file> is an Intel MDS hex file.";
char	readprogHelpText[] = " <file>\n  Read program memory from target device into hex file."
		"\n  <file> is an Intel MDS hex file.";
char	resetHelpText[] = "\n  Power cycle the target.";
char	updatefwHelpText[] = " <file>\n  Update PICkit2 firmware from hex file."
		"\n  <file> is an Intel MDS hex file.";
char	usbDebugHelpText[] = "  Display data sent to the PICkit2 over USB (must be before other options)."
		"\n  -usb     displays only data sent."
		"\n  -usb r   displays data sent and received.";
char	verifyHelpText[] = " <file>\n  Verify target device data against hex file data."
		"\n  <file> is an Intel MDS hex file.";
char	voltageHelpText[] = "\n  Read PICkit2 Vdd and Vpp.";
char	writeHelpText[] = " <file>\n  Write entire hex file to target device."
		"\n  <file> is an Intel MDS hex file. Verifies before writing config word.";
char	writenvHelpText[] = " <file>\n  Write entire hex file to target device."
		"\n  <file> is an Intel MDS hex file. Does not verify after writing.";
char	writedataHelpText[] = " <file>\n  Write only eeprom data from hex file."
		"\n  <file> is an Intel MDS hex file.";
char	writeprogHelpText[] = " <file>\n  Write only program memory from hex file."
		"\n  <file> is an Intel MDS hex file.";

// Commands listed alphabetically so we can easily find best match.

struct command cmdTable[] = {
	{"blank", 0, 1, (void *) &blankCheck, blankHelpText},
	{"config", 0, 1, (void *) &configMode, configHelpText},
	{"device", 0, 0, (void *) &deviceMode, deviceHelpText},
	{"dryrun", PROG_DRY, 1, (void *) &programMode, dryrunHelpText},
	{"erase", 0, 1, (void *) &eraseMode, eraseHelpText},
	{"eraseall", 1, 1, (void *) &eraseMode, eraseallHelpText},
	{"exitboot", 0, 0, (void *) &exitBoot, exitbootHelpText},
	{"firmware", 0, 1, (void *) &firmwareMode, firmwareHelpText},
	{"help", 0, 0, (void *) &helpMode, helpHelpText},
	{"id", 0, 1, (void *) &idMode, idmodeHelpText},
	{"idcheck", 0, 0, (void *) &IDCheck, IDCheckHelpText},
	{"list", 0, 0, (void *) &listMode, listHelpText},
	{"license", 0, 0, (void *) &licenseMode, licenseHelpText},
	{"off", 0, 1, (void *) &offMode, offHelpText},
	{"on", 0, 1, (void *) &onMode, onHelpText},
	{"osccal",0, 1, (void *) &osccalMode, osccalHelpText},
	{"osccalb",2, 1, (void *) &osccalMode, osccalbHelpText},
	{"osccalp",1, 1, (void *) &osccalMode, osccalpHelpText},
#ifndef WIN32
	{"progress", 0, 0, (void *) &progressMode, progressHelpText},
#endif
	{"read", 0, 1, (void *) &readMode, readHelpText},
	{"readboot", 0, 1, (void *) &readBootMode, readbootHelpText},
	{"readdata", 0, 1, (void *) &eepromMode, readdataHelpText},
	{"readprog", 0, 1, (void *) &readProgramMode, readprogHelpText},
	{"reset", 0, 1, (void *) &resetMode, resetHelpText},
	{"updatefw", 0, 1, (void *) &bootLoadMode, updatefwHelpText},
	{"usb", 0, 0, (void *) &usbDebugMode, usbDebugHelpText},
	{"verify", 0, 1, (void *) &verifyMode, verifyHelpText},
	{"vstat", 0, 1, (void *) &voltageMode, voltageHelpText},
	{"write", 0, 1, (void *) &programMode, writeHelpText},
	{"writedata", PROG_DATA, 1, (void *) &programMode, writedataHelpText},
	{"writenv", PROG_NOVERIFY, 1, (void *) &programMode, writenvHelpText},
	{"writeprog", PROG_PGM, 1, (void *) &programMode, writeprogHelpText},
	{NULL}
};

/*
struct command {
	char	*funcName;		// function name
	int	option;			// command options
	int	openflag;		// open usb device
	void	(*func)(void);	// pointer to exec function
	char	*help;			// pointer to help text
};
*/

byte	fwbuffer[FIRMWARE_SIZE];		// buffer for firmware update
byte	vfwbuffer[FIRMWARE_SIZE];		// buffer for firmware verify

// Code

const char *usbDebugMode(void)
{
	if (thisCommand->pcount > 0)
	{
		if (thisCommand->parms[0][0] == 'r' || thisCommand->parms[0][0] == 'R')
			usbdebug = 2;
	}
	else
		usbdebug = 1;
	return NULL;
}

const char *IDCheck(void)
{
	int	noid = 0, dupid = 0;
	picdevice	*head, *list;

	if (!devList)				// read device list (pk2.cfg)
	{
		readDeviceData();
		sortDeviceData();
		removeDuplicateData();
	}

	head = devList;

	while (head && head->next)
	{
		if (head->devid == 0xffff)
		{
			printf("%s has no device ID\n", head->devname);
			noid++;
		}
		else
		{
			list = head->next;

			while (list)
			{
				if (head->devid == list->devid)
				{
					printf("%s matches %s ID = 0x%04x\n", head->devname, list->devname, list->devid);
					dupid++;
				}

				list = list->next;
			}
		}

		head = head->next;
	}

	printf("%d devices with no ID, %d (%d) devices with duplicate IDs\n", noid, dupid, dupid * 2);
	return NULL;
}

const char *voltageMode(pickit_dev *d)
{
	int	vdd, vpp, status;
	int	ver, rev, minor;

	if (pickit2firmware <  0x11400)
	{
		ver = (pickit2firmware & 0xf0000) >> 16;
		rev = (pickit2firmware & 0xff00) >> 8;
		minor = pickit2firmware & 0xff;
		printf("\nVdd/Vpp check not supported by firmware %d.%d.%d\n\n", ver, rev, minor);
	}
	else
	{
		cmd[0] = POWERCTRL;
		cmd[1] = 0;
		cmd[2] = EXITPGM;
		sendPickitCmd(d, cmd, 3);
		usleep(100000);
		checkVoltageStatus(d, &vdd, &vpp);		// wait for Vpp in range
		usleep(100000);
		status = checkVoltageStatus(d, &vdd, &vpp);	// read again
//printf("\n1) Raw values: vdd = %d (0x%x), vpp = %d, (0x%x)", vdd, vdd, vpp,vpp);
		vdd /= 131.07;
		vpp /= 47.8358;
		printf("\nUnpowered: status 0x%02x, Vdd = %d.%dv, Vpp = %d.%dv",
			status, vdd / 100, (vdd % 100) / 10, vpp / 100, (vpp % 100) / 10);

		if (vdd > 200)		// Target appears to be self-powered
		{
			printf("\nTarget device is self-powered\n");
			printf("Status byte:"
				"\n 0x01 Vdd N fet on"
				"\n 0x02 Vdd P fet on"
				"\n 0x04 Vpp bjt on"
				"\n 0x08 Vdd error"
				"\n 0x10 Vpp error"
				"\n 0x20 ADC enabled\n\n"
				);
		}
		else		// Target is not self-powered
		{
			cmd[0] = POWERCTRL;
			cmd[1] = 1;
			sendPickitCmd(d, cmd, 2);
			usleep(100000);
			checkVoltageStatus(d, &vdd, &vpp);		// wait for Vpp in range
			usleep(100000);
			status = checkVoltageStatus(d, &vdd, &vpp);	// read again
//printf("\n2) Raw values: vdd = %d (0x%x), vpp = %d, (0x%x)", vdd, vdd, vpp,vpp);
			vdd /= 131.07;
			vpp /= 47.8358;
			printf("\nPowered:   status 0x%02x, Vdd = %d.%dv, Vpp = %d.%dv\n",
				status, vdd / 100, (vdd % 100) / 10, vpp / 100, (vpp % 100) / 10);
			printf("Status byte:"
				"\n 0x01 Vdd N fet on"
				"\n 0x02 Vdd P fet on"
				"\n 0x04 Vpp bjt on"
				"\n 0x08 Vdd error"
				"\n 0x10 Vpp error"
				"\n 0x20 ADC enabled\n\n"
				);
			cmd[0] = POWERCTRL;
			cmd[1] = 0;
			sendPickitCmd(d, cmd, 2);
		}
	}

	return NULL;
}

// Write hex file data into a device.
// write, writedata, and writeprog all come here.

const char *programMode(pickit_dev *d)
{
	int	i, option;
	FILE *f;
	const char *err;

	if (thisCommand->pcount < 1)
		fatalError("No file specified");

	f = fopen(thisCommand->parms[0], "r");

	if (f == NULL)
		return "Could not open program file";

	dryRun = 0;
	err = pickitGetDevice(d);

	if (err != NULL)
		return err;

	err = readHexFile(f);

	if (err != NULL)
		return err;

	fclose(f);

	// Transfer file data to program buffers for writing

	for (i=0; i<currentDevice->instlen; i++)
		currentDevice->program[i] = currentDevice->fprogram[i];

	for (i=0; i<currentDevice->eelen; i++)
		currentDevice->eeprom[i] = currentDevice->feeprom[i];

	currentDevice->osccal = currentDevice->fosccal;

	for (i=0; i<7; i++)
		currentDevice->config[i] = currentDevice->fconfig[i];

	for (i=0; i<4; i++)
		currentDevice->ID[i] = currentDevice->fID[i];

	option = cmdTable[currentCmd].option;

	pickitWrite(d, option);
	printf("\nFile %s written to device\n", thisCommand->parms[0]);
	return NULL;
}

// Read device data into hex file

const char *readMode(pickit_dev *d)
{
	FILE *f;
	const char *err, *outFile = NULL;

	if (thisCommand->pcount < 1)
		f = stdout;
	else
	{
		outFile = thisCommand->parms[0];
		f = fopen(outFile, "w");

		if (f == NULL)
			return "Could not create output file";
	}

	err = pickitGetDevice(d);

	if (err != NULL)
		return err;

	pickitRead(d);
	writeHexFile(f);

	if (f != stdout)
	{
		fclose(f);
		printf("\nData written to file %s \n", outFile);
	}

	return NULL;
}

// Read only program memory into hex file

const char *readProgramMode(pickit_dev *d)
{
	FILE *f;
	const char *err, *outFile = NULL;

	if (thisCommand->pcount < 1)
		f = stdout;
	else
	{
		outFile = thisCommand->parms[0];
		f = fopen(outFile, "w");

		if (f == NULL)
			return "Could not create output file";
	}

	err = pickitGetDevice(d);

	if (err != NULL)
		return err;

	pickitRead(d);
	writeProgramFile(f);

	if (f != stdout)
	{
		fclose(f);
		printf("\nData written to file %s \n", outFile);
	}

	return NULL;
}

// Verify device data against hex file

const char *verifyMode(pickit_dev *d)
{
	int	i, pgmlen, cfgsize, idsize, pgmerrs = 0, eepromerrs = 0, cfgerrs = 0, iderrs = 0;
	FILE *f;
	const char *err, *inFile;

	if (thisCommand->pcount < 1)
		fatalError("No file specified");

	inFile = thisCommand->parms[0];
	f = fopen(inFile, "r");

	if (f == NULL)
		return "Could not find program file";

	err = pickitGetDevice(d);

	if (err != NULL)
		return err;

	pgmlen = currentDevice->instlen;

	if (!currentDevice->fprogram)
		currentDevice->fprogram = malloc(pgmlen * sizeof(picdev_word));

	if (!currentDevice->feeprom)
		currentDevice->feeprom = malloc(currentDevice->eelen * sizeof(picdev_word));

	for (i=0; i<pgmlen; i++)
	{
		currentDevice->program[i] = currentDevice->instwidth;
		currentDevice->fprogram[i] = currentDevice->instwidth;
	}

	for (i=0; i<currentDevice->eelen; i++)
	{
		currentDevice->eeprom[i] = 0xff;
		currentDevice->feeprom[i] = 0xff;
	}

	for (i=0; i<7; i++)
	{
		currentDevice->config[i] = 0xffff;
		currentDevice->fconfig[i] = 0xffff;
	}

	for (i=0; i<4; i++)
	{
		currentDevice->ID[i] = 0xffff;
		currentDevice->fID[i] = 0xffff;
	}

	err = readHexFile(f);
	fclose(f);

	if (err != NULL)
		return err;

	pickitRead(d);		// read from device

	if (currentDevice->saveOscCal)
		--pgmlen;		// don't compare osccal, if present

	// compare program data
	printf("\nComparing %d words program\n", currentDevice->instlen);

	for (i=0; i<pgmlen; i++)
	{
		if (currentDevice->program[i] != currentDevice->fprogram[i])
		{
			printf("address 0x%04x: file 0x%04x, device 0x%04x\n",
				i, currentDevice->fprogram[i], currentDevice->program[i]);
			pgmerrs++;
		}
	}

	// compare eeprom data
	if (currentDevice->eelen)
		printf("Comparing %d bytes eeprom\n", currentDevice->eelen);

	for (i=0; i<currentDevice->eelen; i++)
	{
		if ((currentDevice->eeprom[i] & 0xff) != (currentDevice->feeprom[i] & 0xff))
		{
			printf("address 0x%04x: file 0x%02x, device 0x%02x\n",
				i, currentDevice->feeprom[i] & 0xff, currentDevice->eeprom[i] & 0xff);
			eepromerrs++;
		}
	}

/* Not every device has an osccal
	if (currentDevice->osccal != currentDevice->fosccal)
	{
		printf("File osccal 0x%04x, device osccal 0x%04x\n",
			currentDevice->osccal, currentDevice->fosccal);
	}
	else
		printf("osccal ok: 0x%04x\n", currentDevice->osccal);
*/

	switch (currentDevice->family)
	{
		case BASELINE:
			cfgsize = 1;
			idsize = 4;
			break;

		case MIDRANGE:
			cfgsize = 2;
			idsize = 4;
			break;

		case PIC18F:
			cfgsize = 7;
			idsize = 4;
			break;

		case PIC18J:
			cfgsize = 4;
			idsize = 0;
			break;

		default:
			cfgsize = 0;
			idsize = 0;
			break;
	}

	printf("Comparing config words\n");

	for (i=0; i<cfgsize; i++)
	{
		if ((currentDevice->config[i] & currentDevice->configMask[i]) !=
			(currentDevice->fconfig[i] & currentDevice->configMask[i]))
		{
			printf("File config word %d 0x%04x, device config word 0x%04x, mask 0x%04x\n", i + 1,
				currentDevice->fconfig[i],
				currentDevice->config[i],
				currentDevice->configMask[i]);
			cfgerrs++;
		}
	}

	if (idsize)
		printf("Comparing ID words\n");

	for (i=0; i<idsize; i++)
	{
		if (currentDevice->ID[i] != currentDevice->fID[i])
		{
			printf("File ID word %d 0x%04x, device ID word 0x%04x\n",
				i, currentDevice->fID[i], currentDevice->ID[i]);
			iderrs++;
		}
	}

	if (currentDevice->eelen)
	{
		printf("\nProgram errors %d\nEEPROM errors %d\n", pgmerrs, eepromerrs);
		printf("ID errors %d\nConfig errors %d\n", iderrs, cfgerrs);
	}
	else
	{
		printf("\nProgram errors %d\n", pgmerrs);
		printf("ID errors %d\nConfig errors %d\n", iderrs, cfgerrs);
	}

	if (pgmerrs || eepromerrs || cfgerrs || iderrs)
		warning("Device verify failed");

	printf("\n");
	return NULL;
}

// Read device eeprom data into a hex file

const char *eepromMode(pickit_dev *d)
{
	FILE *f;
	const char *err, *outFile;

	if (thisCommand->pcount < 1)
		f = stdout;
	else
	{
		outFile = thisCommand->parms[0];
		f = fopen(outFile, "w");

		if (f == NULL)
			return "Could not create output file";
	}

	err = pickitGetDevice(d);

	if (err != NULL)
		return err;

	pickitReadEeprom(d);
	writeDataFile(f);

	if (f != stdout)
		fclose(f);

	return NULL;
}

// Verify device is blank

const char *blankCheck(pickit_dev *d)
{
	int	i, len, pgmerrs = 0, eepromerrs = 0;
	const char *err;
	picdev_word	width;

	err = pickitGetDevice(d);

	if (err != NULL)
		return err;

	width = currentDevice->instwidth;
	len = currentDevice->instlen;

	if (!currentDevice->fprogram)
		currentDevice->fprogram = malloc(len * sizeof(picdev_word));

	if (!currentDevice->feeprom)
		currentDevice->feeprom = malloc(currentDevice->eelen * sizeof(picdev_word));

	if (!currentDevice->fprogram || !currentDevice->feeprom)
		return("Can't get memory to do blank check");

	for (i=0; i<len; i++)
		currentDevice->fprogram[i] = width;

	for (i=0; i<currentDevice->eelen; i++)
		currentDevice->feeprom[i] = 0xff;

	printf("Blank checking %s\n", deviceName);

	pickitRead(d);		// read from device

	// check program, don't check last location (osccal)
	for (i=0; i < len - 1; i++)
	{
		if (currentDevice->program[i] != currentDevice->fprogram[i])
			pgmerrs++;
	}

	// check eeprom data
	if (currentDevice->eelen)
	{
		for (i=0; i<currentDevice->eelen; i++)
		{
			if ((currentDevice->eeprom[i] & 0xff) != (currentDevice->feeprom[i] & 0xff))
				eepromerrs++;
		}
	}

	if (currentDevice->eelen)
		printf("\nProgram errors %d\nEEPROM errors %d\n", pgmerrs, eepromerrs);
	else
		printf("\nProgram errors %d\n", pgmerrs);

	if (currentDevice->saveOscCal)
		printf("osccal 0x%04x\n", currentDevice->osccal);

	printf("config word 0x%04x\n\n", currentDevice->config[0]);

	if (pgmerrs || eepromerrs)
		warning("Device is not blank\n");
	else
		printf("Device is blank\n\n");

	return NULL;
}

// Erase the device. If eraseall is true, erase osccal also.

const char *eraseMode(pickit_dev *d)
{
	int	eraseall;
	const char *err;

	eraseall = cmdTable[currentCmd].option;
	err = pickitGetDevice(d);

	if (err != NULL)
		return err;

	pickitErase(d, eraseall);
	return NULL;
}

// Write config words or show current device config words

const char *configMode(pickit_dev *d)
{
	int	i, val[8];		// up to 8 config words
	const char	*err = NULL;
	char	*str;

	for (i=0; i<thisCommand->pcount; i++)
	{
		str = thisCommand->parms[i];
		val[i] = ascii2hex(str);
	}

	if (!i)
	{
		err = pickitGetDevice(d);

		if (!err)
			pickitPrintConfig(d);
	}
	else
	{
		err = pickitGetDevice(d);

		if (!err)
		{
			printf("Writing config words\n");
			pickitWriteConfigWords(d, i, val);
		}
	}

	return err;
}

// Write ID words

const char *idMode(pickit_dev *d)
{
	int	i, val[4];		// up to 4 ID words
	const char	*err = NULL;
	char	*str;

	for (i=0; (i < 4) && (i < thisCommand->pcount); i++)
	{
		str = thisCommand->parms[i];
		val[i] = ascii2hex(str);
	}

	if (!i)
	{
		err = pickitGetDevice(d);

		if (!err)
			pickitPrintConfig(d);
	}
	else
	{
		err = pickitGetDevice(d);

		if (!err)
		{
			printf("Writing ID words\n");
			pickitWriteIDWords(d, i, val);
		}
	}

	return err;
}

void showDeviceParameters(picdevice *list)
{
	int	i, entry;
	char	*str;

	if (!list)
	{
		printf("\nWarning: No entry for this device\n\n");
		return;
	}

	switch (list->family)
	{
		case BASELINE:
			str = "Baseline";
			break;

		case MIDRANGE:
			str = "Midrange";
			break;

		case PIC18F:
			str = "PIC18F";
			break;

		case PIC18J:
			str = "PIC18J";
			break;

		default:
			str = "UNKNOWN";
			break;
	}

	printf("  Family:         %s\n", str);
	printf("  Program size:   0x%x (%d) words, width 0x%x\n",
		list->instlen, list->instlen, list->instwidth);
	printf("  Eeprom size:    0x%x (%d) bytes\n", list->eelen, list->eelen);
	printf("  ID location:    0x%x\n", list->IDstart);
	printf("  ID size:        0x%x (%d) bytes\n", list->IDlen, list->IDlen);
	printf("  Device ID       0x%04x\n", list->devid);
	printf("  Write burst     %d\n", list->writeBurst);
	printf("  Program command %c\n", list->pgmCommand);

	if (list->pgmMode)
		printf("  Program mode    %c\n", list->pgmMode);
	else
		printf("  Program mode    0\n");

	if (list->pgmTiming)
		printf("  Program timing  %c\n", list->pgmTiming);
	else
		printf("  Program timing  0\n");

	if (list->dataTiming)
		printf("  Data timing     %c\n", list->dataTiming);
	else
		printf("  Data timing     0\n");

	if (list->eraseMode)
		printf("  Erase mode      %c\n", list->eraseMode);
	else
		printf("  Erase mode      0\n");

	printf("  CP mask         0x%04x\n", list->CPMask);
	printf("  Bandgap mask    0x%04x 0x%04x\n", list->BGMask[0], list->BGMask[1]);
	printf("  Config mask    ");
	i = 0;

	while ((i < 8) && list->configMask[i])
	{
		printf(" 0x%04x", list->configMask[i]);
		i++;
	}

	printf("\n");
	printf("  Save osccal     %d\n", list->saveOscCal);
	printf("  Save bandgap    %d\n", list->saveBGBits);

	printf("  Command table  ");
	entry = list->cmdtbl;

	for (i=0; i<CMDTBLSIZE; i++)
		printf(" %02x", CommandTable[entry].entry[i]);

	printf("\n\n");
}

const char *deviceMode(pickit_dev *d)
{
	int			len;
	char			*str, *err = NULL;
	picdevice	*list;

	str = strchr(thisCommand->cmd, '=');

	if (str)
	{
		str++;
		deviceName = str;
		len = strlen(str) - 1;

		if (str[len] == '?')
		{
			str[len] = '\0';
			readDeviceData();
			list = devList;

			while (list)
			{
				if (!strcasecmp(str, list->devname))
					break;

				list = list->next;
			}

			showDeviceParameters(list);
			return NULL;
		}

		if (!devicePtr)
			devicePtr = usbPickitOpen();

		fprintf(stderr, "Using PIC%s\n", deviceName);
		pickitGetDevice(devicePtr);
	}
	else
	{
		if (!devicePtr)
			devicePtr = usbPickitOpen();

		printf("\n");

		err = (char *) pickitGetDevice(devicePtr);

		if (err)
			return err;

		if (!currentDevice && deviceName)
			currentDevice = findDeviceName(deviceName);

		if (currentDevice)
		{
			list = currentDevice;

			if (list)
				showDeviceParameters(list);
			else
				printf("\nInvalid device\n\n");
		}
		else
			printf("\ncurrentDevice is NULL!\n\n");
	}

	return err;
}

const char *resetMode(pickit_dev *d)
{
	pickitOff(d);
	usleep(100000);
	pickitOn(d);
	return NULL;
}

const char *offMode(pickit_dev *d)
{
	pickitOff(d);
	return NULL;
}

const char *onMode(pickit_dev *d)
{
	pickitOn(d);
	return NULL;
}

const char *osccalCheck(void)
{
	picdevice	*list;

	if (!devList)				// read device list (pk2.cfg)
	{
		readDeviceData();
		sortDeviceData();
		removeDuplicateData();
	}

	list = devList;
	printf("\nDevices with osccal:\n");

	while (list)
	{
		if (list->saveOscCal)
		{
			printf("%s ", list->devname);

			switch (list->family)
			{
				case BASELINE:
					printf("baseline\n");
					break;

				case MIDRANGE:
					printf("midrange\n");
					break;

				case PIC18F:
					printf("pic18f\n");
					break;

				case PIC18J:
					printf("pic18j\n");
					break;

				default:
					printf("unknown family\n");
					break;
			}
		}

		list = list->next;
	}

	printf("\n");
	return NULL;
}

// Write OSCCAL data.

const char *osccalMode(pickit_dev *d)
{
	int	val, id, option;
	char	*str;
	const char	*err;

	str = thisCommand->cmd;

	if (strchr(str, '?'))
		return osccalCheck();

	if (thisCommand->pcount < 1)
		fatalError("No osccal value specified");

	str = thisCommand->parms[0];

	if (!str || strlen(str) < 1)
		return "No OSCCAL data provided";

	if (*str == '?')
		return osccalCheck();

	if (!isxdigit(*str))
		return "Invalid osccal value";

	err = pickitGetDevice(d);

	if (err != NULL)
		return err;

	if (!currentDevice->saveOscCal)
	{
		warning("Device has no osccal\n");
		return NULL;
	}

	id = thisCommand->id;
	option = cmdTable[id].option;

	if ((option == 2) && (currentDevice->family != BASELINE))
	{
		warning("Device has no backup osccal\n");
		return NULL;
	}

	pickitReadConfig(d);
	val = ascii2hex(str);

	if (currentDevice->family == BASELINE)
	{
		printf("Current osccal 0x%04x, backup 0x%04x\n",
			currentDevice->osccal, currentDevice->bosccal);
	}
	else
		printf("Current osccal 0x%04x\n", currentDevice->osccal);

	if ((option != 2) && (val & ~currentDevice->osccal))
	{
		printf("Warning! Can't set cleared bits of osccal to ones!\n"
				"Current osccal = 0x%04x\n",
			currentDevice->osccal);
	}

	if ((option != 1) && (val & ~currentDevice->bosccal))
	{
		printf("Warning! Can't set cleared bits of backup osccal to ones!\n"
				"Current backup osccal = 0x%04x\n",
			currentDevice->bosccal);
	}

	if ((currentDevice->family == BASELINE) && (option == 2))
	{
		val &= currentDevice->bosccal;
		printf("Set backup OSCCAL to 0x%x\n", val);
	}
	else
	{
		val &= currentDevice->osccal;
		printf("Set OSCCAL to 0x%x\n", val);
	}

	pickitWriteOsccal(d, val, option);
	return NULL;
}

int writeFWfile(pickit_dev *d, FILE *f, int which)
{
	int	i, j, adrs, size, validrec;
	char	cmd[reqLen + 1];
	unsigned char	resp[128];

	switch (which)
	{
		case READ_FW_FLAG:
			adrs = FIRMWARE_START;
			size = FIRMWARE_SIZE / 32;
			break;

		case READ_BOOT_FLAG:
			adrs = 0;
			size = BOOT_SIZE / 32;
			break;

		default:
			warning("Invalid flag to writeFWfile\n");
			return 1;
	}

	hexWriteBegin(f);

	for (i=0; i<size; i++)
	{
		printf("Reading block %d\r", i);
		fflush(stdout);
		cmd[0] = READFWFLASH;
		cmd[1] = 32;
		cmd[2] = adrs & 0xff;
		cmd[3] = (adrs >> 8) & 0xff;
		cmd[4] = 0;
		sendPickitCmd(d, cmd, 5);		// read block
		recvUSB(d, reqLen, resp);
		validrec = 0;

		if (adrs == (FIRMWARE_START + FIRMWARE_SIZE - 32))	// if last record, set boot flag
		{
			resp[5 + 30] = 0x55;
			resp[5 + 31] = 0x55;
		}

		for (j=0; j<32; j++)		// check if record is all blank
		{
			if (resp[j + 5] != 0xff)
				validrec = 1;
		}

		if (validrec)		// write non-blank records
			writeHexBlock(f, resp + 5, adrs, 32, 0);

		adrs += 32;
	}

	hexWriteEnd(f);
	printf("PICkit2 firmware read done\n");
	return 0;
}

// Display PICkit2 firmware version, or read firmware to file

const char *firmwareMode(pickit_dev *d)
{
	int	result = 0;
	FILE	*f;
	const char	*outFile;

	if (thisCommand->pcount < 1)
	{
		printf("\n");
		return NULL;
	}

	outFile = thisCommand->parms[0];
	f = fopen(outFile, "w");

	if (f == NULL)
		return "Could not create output file";

	enterBootLoader(d);
	d = devicePtr;
	result = writeFWfile(d, f, READ_FW_FLAG);
	fclose(f);
	setFWbootFlag(d);
	resetFW(d);

	if (result)
		return("Error reading firmware");

	printf("\n");
	return NULL;
}

// Read PICkit2 bootloader firmware into hex file

const char *readBootMode(pickit_dev *d)
{
	FILE	*f;
	const char	*outFile;

	if (thisCommand->pcount < 1)
		fatalError("No file specified");

	outFile = thisCommand->parms[0];

	if (strlen(outFile) > 1)
	{
		f = fopen(outFile, "w");

		if (f)
		{
			enterBootLoader(d);
			d = devicePtr;
			writeFWfile(d, f, READ_BOOT_FLAG);
			fclose(f);
			setFWbootFlag(d);
			resetFW(d);
		}
		else
			return("Can't open output file");
	}
	else
		warning("No file specified");

	printf("\n");
	return NULL;
}

// Enter bootload mode

void enterBootLoader(pickit_dev *d)
{
	char	cmd[reqLen + 1];

	if (!d)
	{
		warning("enterBootLoader: No pickit device\n");
		return;
	}

	if (pickit2mode == BOOTLOAD_MODE)
		return;

	printf("Attempting to enter bootloader\n");

	cmd[0] = 'B';
	sendPickitCmd(d, cmd, 1);	// enter boot load mode in firmware
	deviceHandle = NULL;

	usleep(2000000);		// delay here to allow PICkit2 to enter boot loader

	printf("Reopening pickit device\n");
	devicePtr = usbPickitOpen();	// reopen, since USB ID has changed
}

// Erase PICkit2 firmware

void eraseFirmware(pickit_dev *d)
{
	char	cmd[reqLen + 1];

	printf("\nErasing PICkit2 firmware\n");
	cmd[0] = ERASEFWFLASH;
	cmd[1] = 0xc0;
	cmd[2] = 0;
	cmd[3] = 0x20;		// erase 0x2000 - 0x4fff
	cmd[4] = 0;
	sendPickitCmd(d, cmd, 5);
	usleep(1000000);

	cmd[3] = 0x50;		// erase 0x5000 - 0x7fff
	sendPickitCmd(d, cmd, 5);
	usleep(1000000);

	printf("Firmware erase complete\n");
}

// Write firmware data to PICkit2

void writeFWdata(pickit_dev *d)
{
	int	i, adrs, offset;
	char	cmd[reqLen + 1];

	printf("\nWriting PICkit2 firmware\n");
	adrs = FIRMWARE_START;

	for (offset=0; offset < FIRMWARE_SIZE; offset += 32)
	{
		printf("Writing block %d\r", offset / 32);
		fflush(stdout);
		cmd[0] = WRITEFWFLASH;
		cmd[1] = 32;
		cmd[2] = adrs & 0xff;			// set low address
		cmd[3] = (adrs >> 8 ) & 0xff;	// set high address
		cmd[4] = 0;				// set segment address

		for (i=0; i<32; i++)		// load next block
			cmd[i + 5] = fwbuffer[offset + i];

		sendPickitCmd(d, cmd, 37);
		usleep(1000);
		adrs += 32;
	}

	printf("\n");
}

// Read new firmware back into vfwbuffer and check against fwbuffer data.
// Return 1 if ok or 0 if mismatch.

int verifyFWdata(pickit_dev *d)
{
	int	i, j, adrs = FIRMWARE_START, retval = 1;
	byte	resp[reqLen + 1];

	printf("\nVerifying firmware\n");

	for (i=0; i < FIRMWARE_SIZE; i++)
		vfwbuffer[i] = 0xff;

	for (i=0; i < (FIRMWARE_SIZE / 32); i++)
	{
		printf("Reading block %d\r", i);
		fflush(stdout);
		cmd[0] = READFWFLASH;
		cmd[1] = 32;
		cmd[2] = adrs & 0xff;
		cmd[3] = (adrs >> 8) & 0xff;
		cmd[4] = 0;
		sendPickitCmd(d, cmd, 5);		// read block
		recvUSB(d, reqLen, resp);

		for (j=0; j<32; j++)
		{
			vfwbuffer[adrs - FIRMWARE_START] = resp[j + 5];
			adrs++;
		}
	}

	for (i=0; i<FIRMWARE_SIZE; i++)
	{
		if (fwbuffer[i] != vfwbuffer[i])
		{
			retval = 0;
			printf("\nFirmware mismatch at address 0x%x\n", i + FIRMWARE_START);
			printf("fwbuffer 0x%x, vfwbuffer 0x%x\n", fwbuffer[i], vfwbuffer[i]);
			break;
		}
	}

	printf("\n");
	return retval;
}

void setFWbootFlag(pickit_dev *d)
{
	char	cmd[reqLen + 1];

	printf("Setting boot flag\n");

	cmd[0] = ERASEFWFLASH;
	cmd[1] = 1;
	cmd[2] = 0xc0;  // set adrs low
	cmd[3] = 0x7f;  // set adrs high
	cmd[4] = 0x00;  // set adrs segment
	sendPickitCmd(d, cmd, 5);
	usleep(100000);

	cmd[0] = WRITEFWFLASH;
	cmd[1] = 2;
	cmd[2] = 0xfe;  // set adrs low
	cmd[3] = 0x7f;  // set adrs high
	cmd[4] = 0x00;  // set adrs segment
	cmd[5] = 0x55;  // update firmware flag
	cmd[6] = 0x55;
	sendPickitCmd(d, cmd, 7);
	usleep(100000);
}

const char *exitBoot(pickit_dev *d)
{
	if (!d)
	{
		devicePtr = usbPickitOpen();
		d = devicePtr;
	}

	setFWbootFlag(d);
	resetFW(d);
	return NULL;
}

// Attempt to start the PICkit2 application firmware

const char *resetFW(pickit_dev *d)
{
	char	cmd[reqLen + 1];

	if (!devicePtr)
	{
		devicePtr = usbPickitOpen();
		d = devicePtr;
	}

	if (pickit2mode != BOOTLOAD_MODE)	// abort if not in bootloader mode
		return("PICkit2 is not in bootloader mode.");

	printf("Restarting PICkit2 firmware\n");

	cmd[0] = RESETFWDEVICE;
	sendPickitCmd(d, cmd, 1);

	if (deviceHandle && pickit_interface)
	{
		usb_release_interface(deviceHandle, pickit_interface);
		deviceHandle = NULL;
		pickit_interface = 0;
	}

	devicePtr = NULL;
	return NULL;
}

// Write hex firmware file into PICkit2

const char *bootLoadMode(pickit_dev *d)
{
	int	i, adrs, ok;
	FILE	*f;
	const char	*inFile;
	byte	data;

	if (thisCommand->pcount < 1)
		fatalError("No file specified");

	inFile = thisCommand->parms[0];

	if (!d)
	{
		printf("NO PICKIT DEVICE\n");
		return "No pickit device";
	}

	f = fopen(inFile, "r");

	if (f == NULL)
		return "Could not find program file";

	for (i=0; i<FIRMWARE_SIZE; i++)
		fwbuffer[i] = 0xff;

	initParse();

	while (getNextByte(f, &adrs, &data))
	{
		if ((adrs >= FIRMWARE_START) && (adrs < (FIRMWARE_START + FIRMWARE_SIZE)))
		{
			adrs -= FIRMWARE_START;
			fwbuffer[adrs] = data;
		}
	}

	fclose(f);

	enterBootLoader(d);
	d = devicePtr;

	eraseFirmware(d);		// erase firmware flash memory
	writeFWdata(d);		// write new firmware
	usleep(1000000);		// wait for flash update
	ok = verifyFWdata(d);

	if (ok)		// firmware matches, enable it
	{
		cmd[0] = WRITEFWFLASH;	// set up boot flag
		cmd[1] = 2;
		cmd[2] = 0xfe;
		cmd[3] = 0x7f;
		cmd[4] = 0;
		cmd[5] = 0x55;
		cmd[6] = 0x55;
		sendPickitCmd(d, cmd, 7);		// enable reboot into new firmware
		usleep(100000);

		resetFW(d);			// restart PICkit2 with new firmware
		usleep(1000000);

		usb_release_interface(deviceHandle, pickit_interface);
		deviceHandle = NULL;
		pickit_interface = 0;
		usleep(1000000);

		devicePtr = usbPickitOpen();
	}
	else
		warning("Firmware did not verify!");

	printf("\n");
	return NULL;
}

void showCommands(void)
{
	int	i, j, tab;

	printf("\nAvailable commands are:\n\n");

	for (i=0, j=0, tab=0; cmdTable[i].funcName; i++)
	{
		if (tab)
		{
			while ((tab % 15))
			{
				printf(" ");
				tab++;
			}
		}

		tab += printf("%s", cmdTable[i].funcName);
		j++;

		if (j > 5)
		{
			tab = 0;
			j = 0;
			printf("\n");
		}
	}
}

const char *helpMode(void)
{
	int	i, count;
	char	*cmd;

	if (!thisCommand)
	{
		showCommands();
		printf("\n\nFor details type 'pk2 -help <command>' for one of the above commands.\n"
				"Type 'pk2 -help all' for a long list of details for all commands.\n\n");
		return NULL;
	}

	cmd = thisCommand->parms[0];

	if (!cmd || !strlen(cmd))
	{
		showCommands();
		printf("\n\nFor details type 'pk2 -help <command>' for one of the above commands.\n"
				"Type 'pk2 -help all' for a long list of details for all commands.\n\n");
		return NULL;
	}
	else
	{
		while (*cmd == '-')
			cmd++;

		if (!strcasecmp(cmd, "all"))
		{
			i = 0;

			while (cmdTable[i].funcName)
			{
				printf("\npk2 -%s%s", cmdTable[i].funcName, cmdTable[i].help);
				i++;
			}

			printf("\n\n");
		}
		else
		{
			for (count=0; count<thisCommand->pcount; count++)
			{
				cmd = thisCommand->parms[count];

				while (*cmd == '-')
					cmd++;

				i = findBestMatch(cmd);

				if (i > -1)
				{
					printf("\npk2 -%s%s\n\n", cmdTable[i].funcName, cmdTable[i].help);
				}
				else
				{
					printf("\nInvalid or ambiguous command: %s\n", cmd);
					showCommands();
					printf("\n\n");
				}
			}
		}
	}

	return NULL;
}

const char *licenseMode(void)
{
	printf("\nPK2 is licensed under the GNU General Public License (GPL) version 2 or higher.\n"
		"\nAs Novell and Microsoft are in violation of the GPL, pk2 may NOT be distributed"
		"\nin SuSE Linux or any other distribution from Novell or Microsoft.\n\n");
	return NULL;
}

const char *listMode(void)
{
	int	sp = 0, type = 0;
	picdevice	*list;
	char	*str = NULL;

	readDeviceData();
	sortDeviceData();
	removeDuplicateData();

#ifdef ALPHA
	printf("\nPIC18J devices are NOT supported in alpha version");
#endif

	if (thisCommand->pcount > 0)
		str = thisCommand->parms[0];

	if (str && strlen(str) > 0)
	{
		switch (str[0])
		{
			case 'b':
			case 'B':
				type = BASELINE;
				break;

			case 'm':
			case 'M':
				type = MIDRANGE;
				break;

			case 'p':	// could be PIC18F or PIC18J
			case 'P':
			case '1':	// could be 18F or 18J
				if (strchr(str, 'f') || strchr(str, 'F'))
					type = PIC18F;
				else if (strchr(str, 'j') || strchr(str, 'J'))
					type = PIC18J;
				break;

			case 'f':
			case 'F':
				type = PIC18F;
				break;

			case 'j':
			case 'J':
				type = PIC18J;
				break;
		}

		if (type)
		{
			switch (type)
			{
				case BASELINE:
					printf("\nBaseline");
					break;

				case MIDRANGE:
					printf("\nMidrange");
					break;

				case PIC18F:
					printf("\nPIC18F");
					break;

				case PIC18J:
					printf("\nPIC18J");
					break;
			}

			printf(" devices:\n");
		}
	}

	if (!type)
		printf("\nSupported devices (%d):\n", devCount);

	list = devList;

	while (list)
	{
		if (type)
		{
			if (list->family == type)
				sp += printf("%s", list->devname);
		}
		else
			sp += printf("%s", list->devname);

		if (sp < 60)
		{
			while (sp % 12)
				sp += printf(" ");
		}
		else
		{
			sp = 0;
			printf("\n");
		}

		list = list->next;
	}

	printf("\n\n");
	return NULL;
}

//
// Progress hook
//
#ifndef WIN32

void progressHook(int state)
{
	printf("[%d%%]\n", state);
	fflush(stdout);
}

const char *progressMode()
{
	progress_connect(progressHook);
	return NULL;
}
#endif

#ifndef WIN32
int min(int a, int b)
{
	if (a < b)
		return a;
	return b;
}
#endif

// Find the closest match to user's option and return id.

int findBestMatch(char *func)
{
	int	id = 0, best = -1, high = 0, optlen = strlen(func);
	int	i, cmdlen, len;

	while (cmdTable[id].funcName)
	{
		cmdlen = strlen(cmdTable[id].funcName);
		len = min(optlen, cmdlen);

		for (i=0; i<len; i++)
		{
			if (toupper(cmdTable[id].funcName[i]) != toupper(func[i]))
				break;
		}

		if (i > high)
		{
			high = i;
			best = id;

			if ((optlen == cmdlen) && (i == cmdlen))	// if exact match, quit here
				break;

			if ((optlen == (cmdlen + 1)) && (func[optlen - 1] == '?'))	// differ only by '?'
				break;
		}
		else if (i == high)
			best = -1;

		id++;
	}

	if (best >= 0)
	{
		len = strlen(func);
		cmdlen = strlen(cmdTable[best].funcName);

		for (i=0; i<len; i++)
		{
			if (func[i] == '=' || func[i] == '?')
				break;

			if (toupper(func[i]) != toupper(cmdTable[best].funcName[i]))
			{
				best = -1;
				break;
			}
		}
	}
	
	return best;
}

// Get function matched by user option.

int getOption(char *option)
{
	int	id = 0;
	char	*func = option;

	while (*func == '-')
		func++;

	while (cmdTable[id].funcName)
	{
		if (!strcasecmp(func, cmdTable[id].funcName))	// exact match found
			return id;
		id++;
	}

	id = findBestMatch(func);	// exact option not found, find closest command.
	return id;
}

void initCurrentDevice(void)
{
	if (!currentDevice)
		currentDevice = malloc(sizeof(picdevice));

	currentDevice->devid = 0;
	currentDevice->family = 0;
	currentDevice->cmdtbl = 0;
	currentDevice->devname = NULL;
	currentDevice->instlen = 0;
	currentDevice->instwidth = 0;
	currentDevice->writeBurst = 0;
	currentDevice->pgmCommand = 0;
	currentDevice->pgmMode = 0;
	currentDevice->pgmTiming = 0;
	currentDevice->dataTiming = 0;
	currentDevice->eraseMode = 0;
	currentDevice->eelen = 0;
	currentDevice->IDstart = 0;
	currentDevice->IDlen = 0;
	currentDevice->saveOscCal = 0;
	currentDevice->saveBGBits = 0;
	currentDevice->incBits = 0;
	currentDevice->osccal = 0;
	currentDevice->fosccal = 0;
	currentDevice->CPMask = 0;
	currentDevice->BGMask[0] = 0;
	currentDevice->BGMask[1] = 0;
	currentDevice->bandGap[0] = 0;
	currentDevice->bandGap[1] = 0;
	currentDevice->configMask[0] = 0;
	currentDevice->config[0] = 0;
	currentDevice->fconfig[0] = 0;
	currentDevice->ID[0] = 0;
	currentDevice->fID[0] = 0;
	currentDevice->program = NULL;
	currentDevice->eeprom = NULL;
	currentDevice->fprogram = NULL;
	currentDevice->feeprom = NULL;
	currentDevice->next = NULL;
}

// Start here

int main(int argc, char *argv[])
{
	const char *err = NULL;
	int	id, index, pcount;
	const char	*(*func)(pickit_dev *, ...);
	int	cmdCount, help, helpentry;
	picdevice	*dlist, *lastlist;
	unsigned short	endianTest = 0x1234;

#ifdef ALPHA
	printf("\nPK2 version %d.%02d alpha %d - %d/%02d/%02d\n", VERSION, REVISION, ALPHA, YEAR, MONTH, DAY);
#else
#ifdef BETA
	printf("\nPK2 version %d.%02d beta %d - %d/%02d/%02d\n", VERSION, REVISION, BETA, YEAR, MONTH, DAY);
#else
	printf("\nPK2 version %d.%02d - %d/%02d/%02d\n", VERSION, REVISION, YEAR, MONTH, DAY);
#endif
#endif

	if (argc < 2)
	{
		helpMode();
		return 0;
	}

	for (index=0; index<argc; index++)
		printf(" %s", argv[index]);

	printf("\n");
	initCurrentDevice();

#ifndef WIN32
	progress_connect(NULL);
	progress_init(10000);
#endif

	if (((*(unsigned char *) &endianTest) & 0xff) == 0x12)	// determine which type machine
		endian = bigEndian;

	help = 0;
	helpentry = 0;
	cmdCount = 0;
	index = 1;

	while (index < argc)
	{
		if (argv[index][0] == '-')			// if command option
		{
			id = getOption(argv[index]);

			if (id >= 0)
			{
				if (!strcasecmp(cmdTable[id].funcName, "help"))	// after 'help', everything is a parameter
				{
					help = id;
					helpentry = cmdCount;
				}

				cmdList[cmdCount].id = id;
				cmdList[cmdCount].cmd = argv[index];
				pcount = 0;
				index++;

				while (index < argc)		// args following not preceeded by '-' are parameters
				{
					if (help || (argv[index][0] != '-'))
					{
						cmdList[cmdCount].parms[pcount] = argv[index];
						pcount++;
						index++;
					}
					else
						break;
				}

				cmdList[cmdCount].pcount = pcount;
				cmdCount++;
			}
			else
			{
				printf("Invalid command: %s\n", argv[index]);
				index++;
			}
		}
		else
			index++;
	}

	if (!cmdCount)
	{
		helpMode();
	}
	else if (help)		// if -help entered, ignore other commands
	{
		thisCommand = &cmdList[helpentry];
		func = (void *) cmdTable[help].func;
		(func)(NULL);
	}
	else				// process commands in order
	{
		for (index=0; index<cmdCount; index++)
		{
			thisCommand = &cmdList[index];
			id = cmdList[index].id;
			currentCmd = id;
			func = (void *) cmdTable[id].func;

			if (cmdTable[id].openflag && !devicePtr)
				devicePtr = usbPickitOpen();

			err = (func)(devicePtr);

			if (err)
				break;
		}
	}

	if (deviceHandle && pickit_interface)
	{
		usb_release_interface(deviceHandle, pickit_interface);
		deviceHandle = NULL;
		pickit_interface = 0;
	}

	if (devList)
	{
		lastlist = dlist = devList;

		while (dlist)
		{
			dlist = dlist->next;

			if (lastlist->devname)
				free(lastlist->devname);

			free(lastlist);
			lastlist = dlist;
		}
	}

	if (currentDevice)
	{
		if (currentDevice->program)
			free(currentDevice->program);

		if (currentDevice->eeprom)
			free(currentDevice->eeprom);

		if (currentDevice->fprogram)
			free(currentDevice->fprogram);

		if (currentDevice->feeprom)
			free(currentDevice->feeprom);

		free(currentDevice);
	}

	if (err)
	{
		fprintf(stderr, "Fatal error> %s\n\n", err);
		return 1;
	}

	return 0;
}

// end

//
// A USB interface to the Microchip (tm) PICkit 2 (tm) FLASH Starter Kit
// device programmer and breadboard.
// PIC, PICkit2 are registered trademarks of Microchip, Inc.
//
// Maintained by Jeff Post, j_post@pacbell.net
// Last update: 2006/12/17
//
//-----------------------------------------------------------------------------
//
//	This program is free software; you can redistribute it and/or
//	modify it under the terms of the GNU General Public License
//	as published by the Free Software Foundation; either version 2
//	of the License, or (at your option) any later version.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//	GNU General Public License for more details.
//
//	You should have received a copy of the GNU General Public License
//	along with this program; if not, write to the Free Software
//	Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//-----------------------------------------------------------------------------
//

#include	<ctype.h>
#include	<string.h>

#if STDC_HEADERS
#include	<stdlib.h>
#else
#if HAVE_MALLOC_H
#include	<malloc.h>
#endif
#endif

#include "pk2.h"
#ifndef MACOSX_HID
#include	"pk2usb.h"
#endif
#include "pk2hex.h"
#ifndef WIN32
#include	"pk2progress.h"
#endif

// Prototypes

void setDevID(picdevice *list, char *parm);
void setProgSize(picdevice *list, char *parm);
void setProgWidth(picdevice *list, char *parm);
void setDataSize(picdevice *list, char *parm);
void setWriteBurst(picdevice *list, char *parm);
void setSaveOsccal(picdevice *list, char *cptr);
void setSaveBG(picdevice *list, char *cptr);
void setIncBits(picdevice *list, char *cptr);
void setPgmModeEntry(picdevice *list, char *cptr);
void setPgmMode(picdevice *list, char *cptr);
void setProgTiming(picdevice *list, char *cptr);
void setDataTiming(picdevice *list, char *cptr);
void setEraseMode(picdevice *list, char *cptr);
void setBGMask(picdevice *list, char *cptr);
void setConfigMask(picdevice *list, char *cptr);
void setCPMask(picdevice *list, char *cptr);

void	pkEraseBaseline(pickit_dev *d, int eraseall, int option);
void	pkEraseMidrange(pickit_dev *d, int eraseall, int option);
void	pkErase18F1byte(pickit_dev *d);
void	pkErase18F2byte(pickit_dev *d);

// Data

int				pickit2firmware;
picdevice		*currentDevice = NULL;
picdevice		*devList = NULL;
int				devCount = 0;
picdevice		*sortHead = NULL, *sortTail = NULL;

char cmd[reqLen + 1];

struct cfgproc {
	char	*name;
	void	(*func)(int, picdevice *, char *);
};

struct cfgproc cfgParms[] = {
	{"Family", (void *) setProgWidth},
	{"DeviceID", (void *) &setDevID},
	{"ProgSize", (void *) &setProgSize},
	{"DataSize", (void *) &setDataSize},
	{"SaveOsccal", (void *) &setSaveOsccal},
	{"SaveBG", (void *) &setSaveBG},
	{"IncludeUnusedBits", (void *) &setIncBits},
	{"PgmModeEntry", (void *) &setPgmModeEntry},
	{"PgmMode", (void *) &setPgmMode},
	{"WriteBurst", (void *) &setWriteBurst},
	{"ProgTiming", (void *) &setProgTiming},
	{"DataTiming", (void *) &setDataTiming},
	{"EraseMode", (void *) &setEraseMode},
	{"BGMask", (void *) &setBGMask},
	{"ConfigMask", (void *) &setConfigMask},
	{"CPMask", (void *) &setCPMask},
//	{"", (void *) &set},
	{NULL, NULL}		// end of list
};

// Command tables for PIC families
// Entries: 0 = baseline and 16F7x
//              16F7x: ID mask 3F80 = 0600
//              16F72: ID = 00A0
//              16F737 & 747: ID mask 3FA0 = 0BA0
//              16F767: ID mask 3EA0 = 0EA0
//              16F777: ID mask 3DE0 = 0DE0
//          1 = midrange default and PIC18F/PIC18J
//          2 = midrange 16F87xA, 16F818/891, 16F87/88
//              16F87xA:    ID mask 3F90 = 0E00
//              16F818/819: ID mask 3FD0 = 04C0
//              16F87/88:   ID mask 3FB0 = 0720

struct cmdtblentry CommandTable[3] = {
	{{CMDTABLE, 0x00, 0x02, 0x03, 0x04, 0x05, 0x06, 0x08,
		0x08, 0x0e, 0x09, 0x0b, 0xff, 0xff, 0xff, 0xff}},
	{{CMDTABLE, 0x00, 0x02, 0x03, 0x04, 0x05, 0x06, 0x08,
		0x18, 0x0a, 0x09, 0x0b, 0xff, 0xff, 0xff, 0xff}},
	{{CMDTABLE, 0x00, 0x02, 0x03, 0x04, 0x05, 0x06, 0x08,
		0x18, 0x17, 0x1f, 0x1f, 0xff, 0xff, 0xff, 0xff}}
};

static int DryRun = 0;

char *deviceName = NULL;

char	errMsg[128];

// Fatal error

void fatalError(const char *why)
{
	if (why)
		fprintf(stderr, "Fatal error> %s\n", why);

	if (deviceHandle && pickit_interface)
		usb_release_interface(deviceHandle, pickit_interface);

	if (currentDevice)
	{
		if (currentDevice->program)
			free(currentDevice->program);

		if (currentDevice->fprogram)
			free(currentDevice->fprogram);

		if (currentDevice->eeprom)
			free(currentDevice->eeprom);

		if (currentDevice->feeprom)
			free(currentDevice->feeprom);

		free(currentDevice);
	}

	exit(17);
}

void warning(const char *what)
{
	if (what)
		fprintf(stderr, "Warning> %s\n", what);
}

void sendPickitCmd(pickit_dev *d, const char *src, int len)
{
	int	i;

	for (i=0; i<len; i++)
	{
		cmd[i] = *src;
		src++;
	}

	while (i < reqLen)
	{
		cmd[i] = 'Z';
		i++;
	}

	sendUSB(d, cmd, len);
}

void sendCmdTable(pickit_dev *d, int number)
{
	int	i;

	for (i=0; i<CMDTBLSIZE; i++)
		cmd[i] = CommandTable[number].entry[i];

	sendPickitCmd(d, cmd, CMDTBLSIZE);
}

// Read this many words from the device

static void recvWords(pickit_dev *d, unsigned int len, picdev_word *dest)
{
	picdev_word temp, recv[reqLen + 1];
	unsigned int i;

	recvUSB(d, len * 2, (byte *) &recv);

	if (endian == littleEndian)
	{
		for (i=0; i<len; i++)
			dest[i] = recv[i];
	}
	else
	{
		for (i=0; i<len; i++)
		{
			temp = recv[i] << 8;
			temp |= ((recv[i] >> 8) & 0xff);
			dest[i] = temp;
		}
	}
}

// Turn the device on

void pickitOn(pickit_dev *d)
{
	cmd[0] = POWERCTRL;
	cmd[1] = 1;
	sendPickitCmd(d, cmd, 2);
	usleep(100000);
}

// Turn the device off

void pickitOff(pickit_dev *d)
{
	cmd[0] = POWERCTRL;
	cmd[1] = 0;
	sendPickitCmd(d, cmd, 2);
}

// Convert hex ascii string to integer

int ascii2hex(char *str)
{
	int	val = 0;
	int	x;

	if ((str[0] == '0') && ((str[1] == 'x') || (str[1] == 'X')))
		str += 2;

	while (isxdigit(*str))
	{
		x = toupper(*str) - '0';

		if (x > 9)
			x -= 7;

		val <<= 4;
		val |= x;
		str++;
	}

	return val;
}

// Convert ascii number to hex. The number
// must be decimal in the form of 2048 or 2K.

int number2hex(char *str)
{
	int	x, val = 0;

	while (isdigit(*str))
	{
		x = toupper(*str) - '0';
		val *= 10;
		val += x;
		str++;
	}

	if (toupper(*str) == 'K')
		val *= 1024;

	return val;
}

// Skip leading whitespace in string

char *skipspace(char *str)
{
	while ((*str == ' ') || (*str == '\t'))
		str++;

	return str;
}

// Find next data entry in string

char *getNextField(char *str)
{
	while (isgraph(*str))
		str++;

	str = skipspace(str);
	return str;
}

// Eliminate trailing junk (if any) from devicename

char *trimstring(char *str)
{
	int	len;
	char	*s;

	len = strlen(str) - 1;
	s = strstr(str, ";");

	if (s)
		--s;
	else
		s = str + len;

	// check for '\r' is to deal with stupid win/dos files
	while ((*s == ' ') || (*s == '\t') || (*s == '\n') || (*s == '\r'))
	{
		*s = '\0';
		--s;
	}

	if (*str == 'P')	// skip over 'PIC' if present
		str += 3;

	return str;
}

// Find pic device info by ID from list

picdevice *findDevice(int devid)
{
	picdevice	*list = devList;

	while (list)
	{
		if (devid == list->devid)
			break;

		list = list->next;
	}

	return list;
}

/* This may be needed later
// Find next pic device info by ID from list

picdevice *findNextDevice(int devid, picdevice *list)
{
	while (list)
	{
		if (devid == list->devid)
			break;

		list = list->next;
	}

	return list;
}
*/

// Check if device ID is owned by more than one device.
// Return count of devices with the given ID.

int countIDEntries(int devid)
{
	int			count = 0;
	picdevice	*list;

	list = devList;

	while (list)
	{
		if (devid == list->devid)
			count++;

		list = list->next;
	}

	return count;
}

// Find pic device info by name from list

picdevice *findDeviceName(char *name)
{
	picdevice	*list = devList;

	while (list)
	{
		if (!strcasecmp(name, list->devname))
			break;

		list = list->next;
	}

	return list;
}

char *getValuePtr(char *str)
{
	char	*cptr;

	cptr = strchr(str, '=');

	if (cptr)
	{
		cptr++;
		cptr = skipspace(cptr);
	}

	return cptr;
}

int matchParm(char *str)
{
	int	i = 0, len;

	while (cfgParms[i].name)
	{
		len = strlen(cfgParms[i].name);

		if (!strncasecmp(str, cfgParms[i].name, len))
			return i;

		i++;
	}

	return -1;
}

// The 'family' entry will have been set by the time we get here.

void setDevID(picdevice *list, char *cptr)
{
	int	val;

	val = ascii2hex(cptr);
	list->devid = val;

	switch (list->family)
	{
		case BASELINE:
			list->cmdtbl = 0;
			list->IDlen = 4;
			break;

		case MIDRANGE:

// Command tables for PIC families
// Entries: 0 = baseline and 16F7x
//              16F7x: ID mask 3F80 = 0600
//              16F72: ID = 00A0
//              16F737 & 747: ID mask 3FA0 = 0BA0
//              16F767: ID mask 3EA0 = 0EA0
//              16F777: ID mask 3DE0 = 0DE0
//          1 = midrange default and PIC18F/PIC18J
//          2 = midrange 16F87xA, 16F818/891, 16F87/88
//              16F87xA:    ID mask 3F90 = 0E00
//              16F818/819: ID mask 3FD0 = 04C0
//              16F87/88:   ID mask 3FB0 = 0720

			list->IDlen = 4;

			if ((val & 0x3f90) == 0x0e00)
				list->cmdtbl = 2;
			else if ((val & 0x3fd0) == 0x04c0)
				list->cmdtbl = 2;
			else if ((val & 0x3fb0) == 0x0720)
				list->cmdtbl = 2;
			else if (((val & 0x3f80) == 0x600)
				|| ((val & 0x3fa0) == 0x0ba0)
				|| ((val & 0x3ea0) == 0x0ea0)
				|| ((val & 0x3de0) == 0x0de0))
				list->cmdtbl = 0;
			else
				list->cmdtbl = 1;
			break;

		case PIC18F:
			list->IDlen = 4;
			list->cmdtbl = 1;
			break;

		case PIC18J:
			list->IDlen = 0;
			list->cmdtbl = 1;
			break;
	}
}

void setProgSize(picdevice *list, char *cptr)
{
	int	val;

	val = number2hex(cptr);
	list->instlen = val;
}

void setProgWidth(picdevice *list, char *cptr)
{
	int	val;

	val = number2hex(cptr);
	list->family = val;

	switch (val)
	{
		case BASELINE:
			list->instwidth = 0x0fff;
			break;

		case MIDRANGE:
			list->instwidth = 0x3fff;
			break;

		default:
			list->instwidth = 0xffff;
			break;
	}
}

void setDataSize(picdevice *list, char *cptr)
{
	list->eelen = number2hex(cptr);
}

void setWriteBurst(picdevice *list, char *cptr)
{
	list->writeBurst = number2hex(cptr);
}

void setSaveOsccal(picdevice *list, char *cptr)
{
	list->saveOscCal = (bool) (*cptr & 1);
}

void setSaveBG(picdevice *list, char *cptr)
{
	list->saveBGBits = (bool) (*cptr & 1);
}

void setPgmModeEntry(picdevice *list, char *cptr)
{
	if (isprint(*cptr))
		list->pgmCommand = *cptr;
	else
		list->pgmCommand = 0;
}

void setPgmMode(picdevice *list, char *cptr)
{
	if (isprint(*cptr))
		list->pgmMode = *cptr;
	else
		list->pgmMode = 0;
}

void setProgTiming(picdevice *list, char *cptr)
{
	if (isprint(*cptr))
		list->pgmTiming = (int) *cptr;
	else
		list->pgmTiming = 0;
}

void setDataTiming(picdevice *list, char *cptr)
{
	if (isprint(*cptr))
		list->dataTiming = (int) *cptr;
	else
		list->dataTiming = 0;
}

void setEraseMode(picdevice *list, char *cptr)
{
	int	val;

	if (isprint(*cptr))
	{
		val = number2hex(cptr);
		list->eraseMode = val;
	}
	else
		list->eraseMode = 0;
}

void setCPMask(picdevice *list, char *cptr)
{
	list->CPMask = (picdev_word) ascii2hex(cptr);
}

void setIncBits(picdevice *list, char *cptr)
{
	list->incBits = (bool) (*cptr & 1);
}

void setBGMask(picdevice *list, char *cptr)
{
	int	val;

	val = ascii2hex(cptr);
	list->BGMask[0] = val;
	cptr = getNextField(cptr);
	val = ascii2hex(cptr);
	list->BGMask[1] = val;
}

void setConfigMask(picdevice *list, char *cptr)
{
	int	i, val;

	for (i=0; i<7; i++)
	{
		val = ascii2hex(cptr);
		list->configMask[i] = val;
		cptr = getNextField(cptr);
	}
}

// Read config file and return number of entries found.
// The file must already be open for reading.
// Update picdevice list passed as pointer plist.

int readConfigFile(FILE *fp, picdevice **plist)
{
	int	i, count = 0;
	FILE	*fpi;
	char	*cptr, bfr[128], fname[128];
	picdevice	*list = *plist;
	void	*(*setfunc)(picdevice *, char *);

	while (!feof(fp))
	{
		if (fgets(bfr, 127, fp))
		{
			if (!strncasecmp(bfr, "include", 7))		// include file
			{
				cptr = (char *) &bfr[7];
				cptr = skipspace(cptr);
				i = 0;

				while (!isspace(cptr[i]))
					i++;

				cptr[i] = '\0';
				fpi = fopen(cptr, "r");

				if (!fpi)		// if not in local directory, try default directory
				{
#ifdef WIN32
					sprintf(fname, "c:\\Program Files\\pk2\\");
#else
#ifdef _PATH_PK2DATADIR		// autotools
					sprintf(fname, _PATH_PK2DATADIR);
#else
					sprintf(fname, "/usr/local/bin/");
#endif
#endif
					strcat(fname, cptr);
					fpi = fopen(fname, "r");
				}

				if (fpi)
				{
					count += readConfigFile(fpi, &list);
					fclose(fpi);
				}

				fgets(bfr, 127, fp);
			}

			if (!strncasecmp(bfr, "name", 4))		// start of entry
			{
				if (!devList)
				{
					devList = malloc(sizeof(picdevice));

					if (!devList)
						fatalError("Can't allocate memory for device list");

					list = devList;
					list->next = NULL;
				}
				else
				{
					list->next = malloc(sizeof(picdevice));
					list = list->next;

					if (!list)
						fatalError("Can't allocate memory for device list");

					list->next = NULL;
				}

				list->instlen = 0;
				list->eelen = 0;
				count++;
				cptr = getValuePtr(bfr);
				cptr = trimstring(cptr);
				list->devname = malloc(strlen(cptr) + 1);

				if (!list->devname)
					fatalError("Can't allocate memory for device name");

				strcpy(list->devname, cptr);
				fgets(bfr, 127, fp);

				while (strlen(bfr) > 2)  // until we read a blank line
				{
					i = matchParm(bfr);

					if ((i >= 0) && (cfgParms[i].func))
					{
						cptr = getValuePtr(bfr);
						setfunc = (void *) cfgParms[i].func;
						(setfunc)(list, cptr);
					}

					bfr[0] = '\0';
					fgets(bfr, 127, fp);
				}
			}
		}
		else
			break;
	}

	*plist = list;
	return count;
}

// Read pk2.cfg file and build picdevice list.

void readDeviceData(void)
{
	int	count = 0;
	FILE	*fp;
	picdevice	*list = NULL;

	fp = fopen("pk2.cfg", "r");

	if (!fp)
	{
#ifdef WIN32
		fp = fopen("c:\\Program Files\\pk2\\pk2.cfg", "r");
#else
#ifdef _PATH_PK2CFG	// autotools
		fp = fopen(_PATH_PK2CFG, "r");
#else
		fp = fopen("/usr/local/bin/pk2.cfg", "r");
#endif
#endif

		if (!fp)
		{
			printf("\nCan't open config file pk2.dev\n\n");

			if (deviceHandle && pickit_interface)
			{
				usb_release_interface(deviceHandle, pickit_interface);
				deviceHandle = NULL;
				pickit_interface = 0;
			}

			exit(1);
		}
	}

	count = readConfigFile(fp, &list);	// read pk2.cfg and any included files
	fclose(fp);
	devCount = count;
}

// Merge sublists by device name

picdevice *mergeByName(picdevice *a, picdevice *b)
{
	int			i;
	picdevice	*c;

	c = sortTail;

	do
	{
		i = strcasecmp(a->devname, b->devname);

		if (i <= 0)
		{
			c->next = a;
			c = a;
			a = a->next;
		}
		else
		{
			c->next = b;
			c = b;
			b = b->next;
		}
	} while (c != sortTail);

	c = sortTail->next;
	sortTail->next = sortTail;
	return(c);
}

void sortDeviceData(void)
{
	int			i, n;
	picdevice	*a, *b, *todo, *t, *head, *list;

	sortHead = malloc(sizeof(picdevice));
	sortHead->devname = malloc(16);
	strcpy(sortHead->devname, "0");
	sortTail = malloc(sizeof(picdevice));
	sortTail->devname = malloc(16);
	strcpy(sortTail->devname, "xxxxxxxx");
	sortTail->next = NULL;
	sortHead->next = devList;
	head = devList;

	while (head->next)
		head = head->next;

	head->next = sortTail;
	head = sortHead;
	a = sortTail;

	for (n=1; a != head->next; n = n + n)
	{
		todo = head->next;
		list = head;

		while (todo != sortTail)
		{
			t = todo;
			a = t;

			for (i=1; i<n; i++)
				t = t->next;

			b = t->next;
			t->next = sortTail;
			t = b;

			for (i=1; i<n; i++)
				t = t->next;

			todo = t->next;
			t->next = sortTail;
			list->next = mergeByName(a, b);

			for (i=1; i<=n+n; i++)
				list = list->next;
		}
	}

	devList = head->next;
	head = sortHead->next;

	while (head->next != sortTail)
		head = head->next;

	head->next = NULL;
}

// The PICkit2.dvs file will contain a duplicate of the last entry,
// therefore pk2.cfg will also. Just to be really sure, scan the
// entire sorted list and remove all duplicate entries.

void removeDuplicateData(void)
{
	picdevice	*list, *next;

	list = devList;
	next = list->next;

	while (list && next)
	{
		if (!strcasecmp(list->devname, next->devname))	// two entries for the same device
		{
			--devCount;
			list->next = next->next;

			if (next->program)
				free(next->program);

			if (next->fprogram)
				free(next->fprogram);

			if (next->eeprom)
				free(next->eeprom);

			if (next->feeprom)
				free(next->feeprom);

			free(next->devname);
			free(next);
		}

		list = list->next;

		if (list)
			next = list->next;
	}
}

// Initialize currentDevice with parameters from device list p

void initCurrentData(picdevice *p)
{
	int	i;

	currentDevice->devid = p->devid;
	currentDevice->family = p->family;
	currentDevice->cmdtbl = p->cmdtbl;
	currentDevice->devname = p->devname;
	currentDevice->instlen = p->instlen;
	currentDevice->instwidth = p->instwidth;
	currentDevice->writeBurst = p->writeBurst;
	currentDevice->pgmCommand = p->pgmCommand;
	currentDevice->pgmMode = p->pgmMode;
	currentDevice->pgmTiming = p->pgmTiming;
	currentDevice->dataTiming = p->dataTiming;
	currentDevice->eraseMode = p->eraseMode;
	currentDevice->eelen = p->eelen;
	currentDevice->IDstart = p->IDstart;
	currentDevice->IDlen = p->IDlen;
	currentDevice->saveOscCal = p->saveOscCal;
	currentDevice->saveBGBits = p->saveBGBits;
	currentDevice->incBits = p->incBits;
	currentDevice->osccal = p->osccal;
	currentDevice->fosccal = 0;
	currentDevice->CPMask = p->CPMask;
	currentDevice->BGMask[0] = p->BGMask[0];
	currentDevice->BGMask[1] = p->BGMask[1];
	currentDevice->bandGap[0] = p->bandGap[0];
	currentDevice->bandGap[1] = p->bandGap[1];

	for (i=0; i<7; i++)
	{
		currentDevice->configMask[i] = p->configMask[i];
		currentDevice->config[i] = p->config[i];
		currentDevice->fconfig[i] = 0;
	}

	for (i=0; i<4; i++)
	{
		currentDevice->ID[i] = p->ID[i];
		currentDevice->fID[i] = 0;
	}
}

// Check current Vdd, Vpp state in PICkit2.
// Return raw values in vdd, vpp.
// NOTE: firmware 1.20 *always* returns 0 for vdd. Bug in firmware?

int checkVoltageStatus(pickit_dev *d, int *vdd, int *vpp)
{
	byte	status[8];

	cmd[0] = VDDVPPSTATUS;
	sendPickitCmd(d, cmd, 1);
	recvUSB(d, 5, status);
	*vdd = (((int) status[1] & 0xff) | (((int) status[2] & 0xff) << 8));
	*vpp = (((int) status[3] & 0xff) | (((int) status[4] & 0xff) << 8));

//printf("voltage status raw data: 0x%02x, vdd %d (0x%x), vpp %d (0x%x)\n",
//	status[0], *vdd, *vdd, *vpp, *vpp);

	return (int) status[0] & 0xff;
}

// Set PICkit2 voltages for current device

void setVoltages(pickit_dev *d, int family)
{
	int	i, vdd, vpp, vddmin, pvdd, pvpp, vppchkmin, vppchkmax;
	int	status;

	cmd[0] = POWERCTRL;
	cmd[1] = 0;
	sendPickitCmd(d, cmd, 2);
	usleep(50000);		// wait 50 msec
	status = checkVoltageStatus(d, &pvdd, &pvpp);

	if (status & 0x18)	// abort if error ocurred
		return;

	switch (family)
	{
		case BASELINE:
		case MIDRANGE:
		case PIC18F:
			vddmin = 4.3 * 13107;
			vdd = 5.0 * 32.0 + 10.5;
			vpp = 12.0 * 18.61;
			vppchkmin = 11.5 * 4783.58;	// set min/max for range check
			vppchkmax = 12.5 * 4783.58;	// 4783.58 = magic number for scaling Vpp ADC
			break;								// for scaling Vdd ADC, magic number = 13107

		case PIC18J:
			vddmin = 3.0 * 13107;
			vdd = 3.3 * 32.0 + 10.5;
			vpp = 3.3 * 18.61;
			vppchkmin = 3.0 * 4783.58;
			vppchkmax = 3.8 * 4783.58;
			break;

		default:
			return;
	}

	if (pvdd > vddmin)	// self-powered target, adjust output to match target power
	{
		vdd = (pvdd / 410) + 10.5;	// don't ask, do the math

		if (family == PIC18J)		// set vpp to match vdd
			vpp = pvdd / 704;
	}

	vdd <<= 6;		// multipy by 64

	cmd[0] = SETVDDVPP;
	cmd[1] = vdd & 0xc0;
	cmd[2] = vdd >> 8;
	cmd[3] = 0x40;
	cmd[4] = vpp;
	cmd[5] = (vdd >> 8) * 4.5;
	cmd[6] = (vpp / 2) + (vpp / 4);
	sendPickitCmd(d, cmd, 7);

	if (pickit2firmware >= 0x11400)
	{
		i = 32;

		while (--i)			// wait for vpp to stabilize
		{
			status = checkVoltageStatus(d, &pvdd, &pvpp);
			usleep(50000);		// wait 50 msec

			if ((pvpp < vppchkmax) && (pvpp > vppchkmin))	// done if vpp within range
				break;
		}
	}
}

// Get device ID

const char *pickitGetDevice(pickit_dev *d)
{
	int	deviceType = 0;
	char *err = NULL;
	int i, idcount, rev;
	picdevice	*list = NULL, *dlist = NULL;
	picdev_word	id_word;
	picdev_word	buffer[8];

	if (!devList)				// read device list (pk2.cfg)
	{
		readDeviceData();
		sortDeviceData();
		removeDuplicateData();
	}

	if (deviceName)
	{
		list = findDeviceName(deviceName);

		if (!list)
			err = "No PIC or unsupported PIC found";
		else
		{
			if ((!strncasecmp(deviceName, "18J", 3)) && (pickit2firmware < 0x11400))
			{
				fatalError("PICkit2 firmware does not support PIC18J devices\n");
			}

			initCurrentData(list);

			if (!list->instlen)
			{
				if (!strncasecmp(deviceName, "10", 2))	 // 12 bit instructions
					currentDevice->instwidth = 0x0fffu;
				else if (!strncasecmp(deviceName, "18", 2))  // 16 bit instructions
					currentDevice->instwidth = 0xffffu;
				else
					currentDevice->instwidth = 0x3fffu;		// 14 bit instructions
			}

			if (!currentDevice->program)
				currentDevice->program = malloc(list->instlen * sizeof(picdev_word));

			if (!currentDevice->program)
				fatalError("Can't allocate memory for program space");

			if (!currentDevice->eeprom)
				currentDevice->eeprom = malloc(list->eelen * sizeof(picdev_word));

			if (!currentDevice->eeprom)
				fatalError("Can't allocate memory for eeprom space");

			for (i=0; i<currentDevice->instlen; i++)
				currentDevice->program[i] = currentDevice->instwidth;

			if (currentDevice->eelen)
			{
				for (i=0; i<currentDevice->eelen; i++)
					currentDevice->eeprom[i] = 0xff;
			}
		}

		if (pickit2firmware >= 0x11400)
		{
			setVoltages(d, currentDevice->family);
			usleep(100000);
		}

		return err;
	}

// Attempt to automagically determine what device is in the PICkit2

	id_word = 0;

	if (pickit2firmware >= 0x11400)
	{
		setVoltages(d, PIC18J);		// try for PIC18J first
		usleep(100000);				// allow time for voltages to settle

		cmd[0] = PIC18J_ENTERPROG;
		cmd[1] = PIC18FREAD;
		cmd[2] = 2;				// read two bytes
		cmd[3] = 0xfe;			// set address
		cmd[4] = 0xff;
		cmd[5] = 0x3f;
		cmd[6] = PIC18J_EXITPROG;
		sendPickitCmd(d, cmd, 7);	// Read id word
		recvWords(d, 1, buffer);
		id_word = buffer[0];
		rev = id_word & 0x1f;
		id_word &= 0xffe0;

		if (id_word)
			deviceType = PIC18J;
	}

	if (!id_word)		// if no ID word, then try for non-18J device
	{
		if (pickit2firmware >= 0x11400)
		{
			setVoltages(d, BASELINE);
			usleep(100000);
		}

		cmd[0] = ENTERPGM;		// try for midrange device
		cmd[1] = WRITECONFIG;
		cmd[2] = READPGM;
		cmd[3] = EXITPGM;
		sendPickitCmd(d, cmd, 4);	// Read id word
		recvWords(d, 8, buffer);	// read 16 bytes
		id_word = buffer[6];			// id at byte offset 12-13
		rev = id_word & 0x1f;
		id_word &= 0xffe0;

		if (id_word)
			deviceType = MIDRANGE;

		if (!id_word)
		{
			cmd[0] = ENTERPGMVDD1ST;	// try Vdd first command for midrange device
			cmd[1] = WRITECONFIG;
			cmd[2] = READPGM;
			cmd[3] = EXITPGM;
			sendPickitCmd(d, cmd, 4);	// Read id word
			recvWords(d, 8, buffer);
			id_word = buffer[6];		// byte offset 12-13
			rev = id_word & 0x1f;
			id_word &= 0xffe0;

			if (id_word)
				deviceType = MIDRANGE;
		}
	}

	if (!id_word)		// if still no ID word, then check for 18F device
	{
		cmd[0] = ENTERPGM;
		cmd[1] = PIC18FREAD;
		cmd[2] = 2;
		cmd[3] = 0xfe;
		cmd[4] = 0xff;
		cmd[5] = 0x3f;
		cmd[6] = EXITPGM;
		sendPickitCmd(d, cmd, 7);
		recvWords(d, 1, buffer);

		if (buffer[0])
		{
			rev = buffer[0] & 0x1f;
			id_word = buffer[0] & 0xffe0;
		}
		else		// if that didn't work, try again with VDD first
		{
			cmd[0] = ENTERPGMVDD1ST;
			cmd[1] = PIC18FREAD;
			cmd[2] = 2;
			cmd[3] = 0xfe;
			cmd[4] = 0xff;
			cmd[5] = 0x3f;
			cmd[6] = EXITPGM;
			sendPickitCmd(d, cmd, 7);
			recvWords(d, 1, buffer);
			rev = buffer[0] & 0x1f;
			id_word = buffer[0] & 0xffe0;
		}

		if (id_word)
			deviceType = PIC18F;
	}

	if (id_word)
	{
		fprintf(stderr, "Device ID 0x%04x\n", id_word);
		list = findDevice((int) id_word);
		idcount = countIDEntries(id_word);

		if (idcount > 1)
		{
			printf("Ambiguous device ID 0x%04x belongs to more than one device:\n", id_word);
			list = devList;

			while (list)
			{
				if (id_word == list->devid)
				{
					printf("  %s\n", list->devname);

					if (deviceType == list->family)
						dlist = list;
				}

				list = list->next;
			}

			if (dlist)
			{
				printf("Device appears to be %s\n\n", dlist->devname);
				list = dlist;
			}
			else
			{
				currentDevice = NULL;
				return "Use -device=devname option\n";
			}
		}
	}

	if (!list)
		err = "No PIC or unsupported PIC found";
	else
	{
		deviceName = malloc(strlen(list->devname) + 1);

		if (!deviceName)
			fatalError("Can't allocate memory for device name");

		strcpy(deviceName, list->devname);
		initCurrentData(list);

		if (!currentDevice->program)
			currentDevice->program = malloc(list->instlen * sizeof(picdev_word));

		if (!currentDevice->program)
			fatalError("Can't allocate memory for program space");

		if (list->eelen)
		{
			if (!currentDevice->eeprom)
				currentDevice->eeprom = malloc(list->eelen * sizeof(picdev_word));

			if (!currentDevice->eeprom)
				fatalError("Can't allocate memory for eeprom space");

			for (i=0; i<currentDevice->eelen; i++)
				currentDevice->eeprom[i] = 0xff;
		}

		for (i=0; i<currentDevice->instlen; i++)
			currentDevice->program[i] = list->instwidth;
	}

	if (!err)
	{
		fprintf(stderr, "PIC%s Rev %d found\n", deviceName, rev);

		if ((currentDevice->family == PIC18J) && (pickit2firmware < 0x11400))
			fatalError("PICkit2 firmware does not support PIC18J devices\n");

		if (pickit2firmware >= 0x11400)
		{
			setVoltages(d, currentDevice->family);
			usleep(100000);
		}
	}

	return err;
}

void readEepromBaseline(pickit_dev *d)
{
	int	i, nee = 0;
	byte	eeData[reqLen + 1];

	if (!currentDevice->eelen)
		return;

	printf("Reading eeprom...\n");
	cmd[0] = ENTERPGMVDD1ST;
	sendPickitCmd(d, cmd, 1);

	for (i=0; i<8; i++)
		cmd[i] = READDATA;

	while (nee < currentDevice->eelen)
	{
		sendPickitCmd(d, cmd, 8);
		recvUSB(d, reqLen, eeData);

		for (i=0; i<reqLen; i++)
			currentDevice->eeprom[nee++] = eeData[i];

#ifndef WIN32
		progress_update(64);
#endif
	}

	cmd[0] = EXITPGM;
	sendPickitCmd(d, cmd, 1);
}

void readEepromMidrange(pickit_dev *d)
{
	int	i, reads, nee = 0;
	byte	eeData[reqLen + 1];

	if (!currentDevice->eelen)
		return;

	printf("Reading eeprom...\n");
	cmd[0] = currentDevice->pgmCommand;
	sendPickitCmd(d, cmd, 1);
	reads = currentDevice->eelen / 64;

	for (i=0; i<reads; i++)
		cmd[i] = READDATA;

	sendPickitCmd(d, cmd, reads);

	while (nee < currentDevice->eelen)
	{
		recvUSB(d, reqLen, eeData);

		for (i=0; i<reqLen; i++)
			currentDevice->eeprom[nee++] = eeData[i] & 0xff;

#ifndef WIN32
		progress_update(64);
#endif
	}

	cmd[0] = EXITPGM;
	sendPickitCmd(d, cmd, 1);
}

void readEepromPIC18F(pickit_dev *d)
{
	int	i, nee = 0;
	byte	eeData[reqLen + 1];

	if (!currentDevice->eelen)
		return;

	printf("Reading eeprom...\n");
	cmd[0] = ENTERPGMVDD1ST;
	sendPickitCmd(d, cmd, 1);
	cmd[0] = PIC18FEEDATAREAD;
	cmd[1] = 64;

	while (nee < currentDevice->eelen)
	{
		cmd[2] = nee & 0xff;
		cmd[3] = (nee >> 8) & 0xff;
		sendPickitCmd(d, cmd, 4);
		recvUSB(d, reqLen, eeData);

		for (i=0; i<reqLen; i++)
			currentDevice->eeprom[nee++] = eeData[i];

#ifndef WIN32
		progress_update(64);
#endif
	}

	cmd[0] = EXITPGM;
	sendPickitCmd(d, cmd, 1);
}

// Read device eeprom data into currentDevice.

void pickitReadEeprom(pickit_dev *d)
{
	char	errmsg[64];

	if (!currentDevice)
		pickitGetDevice(d);

	if (!currentDevice)
		fatalError("No device selected");

	switch (currentDevice->family)
	{
		case BASELINE:
			readEepromBaseline(d);
			break;

		case MIDRANGE:
			readEepromMidrange(d);
			break;

		case PIC18F:
			readEepromPIC18F(d);
			break;

		case PIC18J:
			fatalError("PIC18J devices have no eeprom");
			break;

		default:
			sprintf(errmsg, "Invalid PIC family: %d", currentDevice->family);
			fatalError(errmsg);
			break;
	}
}

// Read the device.

void pickitRead(pickit_dev *d)
{
	if (!currentDevice)
		pickitGetDevice(d);

	if (!currentDevice)
		fatalError("No device selected");

#ifndef WIN32
	progress_init(currentDevice->eelen + currentDevice->instlen);
#endif

	sendCmdTable(d, currentDevice->cmdtbl);
	pickitReadProgram(d);

	if (currentDevice->family != PIC18J)
	{
		pickitReadEeprom(d);
		pickitReadConfig(d);
	}
}

void readBaselinePgm(pickit_dev *d)
{
	int	i, j, offset;
	picdev_word	data;
	byte	Data[reqLen + 1];

	printf("Reading program...\n");
	cmd[0] = ENTERPGMVDD1ST;
	sendPickitCmd(d, cmd, 1);

	for (i=0; i<currentDevice->instlen + 32; i+=32)
	{
		cmd[0] = READPGM;
		sendPickitCmd(d, cmd, 1);
		recvUSB(d, reqLen, Data);

		for (j=0; j<32; j++)
		{
			data = Data[j * 2] + (Data[j * 2 + 1] << 8);

			if (!(i + j))			// first word returned is config word
				currentDevice->config[0] = data;
			else if ((i + j) <= currentDevice->instlen)	// really is program memory
				currentDevice->program[i + j - 1] = data;
			else			// might be User ID
			{
				offset = i + j - currentDevice->instlen - 1;

				if ((offset >= 0) && (offset < 4))
					currentDevice->ID[offset] = data;
			}
		}

#ifndef WIN32
		progress_update(16);
#endif
	}

	cmd[0] = EXITPGM;
	sendPickitCmd(d, cmd, 1);
}

void readMidrangePgm(pickit_dev *d)
{
	int	i, j;
	picdev_word	data;
	byte	Data[reqLen + 1];

	printf("Reading program...\n");
	cmd[0] = currentDevice->pgmCommand;
	sendPickitCmd(d, cmd, 1);

	for (i=0; i<currentDevice->instlen; i+=32)
	{
		cmd[0] = READPGM;
		sendPickitCmd(d, cmd, 1);
		recvUSB(d, reqLen, Data);

		for (j=0; j<32; j++)
		{
			data = Data[j * 2] + (Data[j * 2 + 1] << 8);
			currentDevice->program[i + j] = data;
		}

#ifndef WIN32
		progress_update(16);
#endif
	}

	cmd[0] = WRITECONFIG;		// read user ID and config words
	cmd[1] = READPGM;
	sendPickitCmd(d, cmd, 2);
	recvUSB(d, 16, Data);

	for (i=0; i<4; i++)			// save user ID
	{
		data = Data[i * 2] + (Data[i * 2 + 1] << 8);
		currentDevice->ID[i] = data;
	}

	currentDevice->config[0] = Data[14] + (Data[15] << 8);
	currentDevice->config[1] = Data[16] + (Data[17] << 8);

	cmd[0] = EXITPGM;
	sendPickitCmd(d, cmd, 1);
}

void readPIC18FPgm(pickit_dev *d)
{
	int	i, j;
	picdev_word	data;
	byte	Data[reqLen + 1];

	printf("Reading program...\n");
	cmd[0] = ENTERPGMVDD1ST;
	sendPickitCmd(d, cmd, 1);

	for (i=0; i<currentDevice->instlen; i+=32)
	{
		cmd[0] = PIC18FREAD;
		cmd[1] = 64;			// 64 bytes = 32 words
		cmd[2] = (i << 1) & 0xff;	// set address of read
		cmd[3] = (i >> 7) & 0xff;
		cmd[4] = (i >> 15) & 0xff;
		sendPickitCmd(d, cmd, 5);
		recvUSB(d, reqLen, Data);

		for (j=0; j<32; j++)
		{
			data = (Data[j * 2] & 0xff) + (Data[j * 2 + 1] << 8);
			currentDevice->program[i + j] = data;
		}

#ifndef WIN32
		progress_update(16);
#endif
	}

	cmd[0] = PIC18FREAD;		// read user ID
	cmd[1] = 8;
	cmd[2] = 0;
	cmd[3] = 0;
	cmd[4] = 0x20;
	sendPickitCmd(d, cmd, 5);
	recvUSB(d, 16, Data);

	for (i=0; i<4; i++)
		currentDevice->ID[i] = Data[i * 2] + (Data[i * 2 + 1] << 8);

	cmd[0] = PIC18FREAD;		// read config words
	cmd[1] = 14;
	cmd[2] = 0;
	cmd[3] = 0;
	cmd[4] = 0x30;
	sendPickitCmd(d, cmd, 5);
	recvUSB(d, 16, Data);

	for (i=0; i<7; i++)
		currentDevice->config[i] = Data[i * 2] + (Data[i * 2 + 1] << 8);

	cmd[0] = EXITPGM;
	sendPickitCmd(d, cmd, 1);
}

void readPIC18JPgm(pickit_dev *d)
{
	int	i, j, adrs;
	picdev_word	bfr[32];

	cmd[0] = PIC18J_ENTERPROG;
	sendPickitCmd(d, cmd, 1);

	for (adrs = 0; adrs < currentDevice->instlen; adrs += 256)
	{
		for (i=0; i<8; i++)		// 512 bytes, 256 words
		{
			cmd[0 + i * 5] = PIC18FREAD;
			cmd[1 + i * 5] = 64;		// read 64 bytes at a time
			cmd[2 + i * 5] = ((adrs + i * 32) << 1) & 0xff;
			cmd[3 + i * 5] = ((adrs + i * 32) >> 7) & 0xff;
			cmd[4 + i * 5] = ((adrs + i * 32) >> 15) & 0xff;
		}

		sendPickitCmd(d, cmd, 40);

		for (i=0; i<256; i += 32)		// loop 8 times
		{
			recvWords(d, 32, bfr);		// read 32 words

			for (j=0; j<32; j++)
				currentDevice->program[adrs + i + j] = bfr[j];
		}

#ifndef WIN32
		progress_update(256);
#endif
	}

	for (i=0; i<4; i++)
		currentDevice->config[i] = currentDevice->program[currentDevice->instlen - 4 + i];

	for (i=0; i<4; i++)
		currentDevice->ID[i] = 0;		// no User ID

	cmd[0] = PIC18J_EXITPROG;
	sendPickitCmd(d, cmd, 1);
}

// Read program data from the device.

void pickitReadProgram(pickit_dev *d)
{
	char	errmsg[64];

	if (!currentDevice)
		pickitGetDevice(d);

	if (!currentDevice)
		fatalError("No device selected");

#ifndef WIN32
	progress_init(currentDevice->eelen + currentDevice->instlen);
#endif

	switch (currentDevice->family)
	{
		case BASELINE:
			readBaselinePgm(d);
			break;

		case MIDRANGE:
			readMidrangePgm(d);
			break;

		case PIC18F:
			readPIC18FPgm(d);
			break;

		case PIC18J:
			readPIC18JPgm(d);
			break;

		default:
			sprintf(errmsg, "Invalid PIC family: %d", currentDevice->family);
			fatalError(errmsg);
			break;
	}
}

// Read config words from the device.

void pickitReadConfig(pickit_dev *d)
{
	picdev_word id[16];
	picdev_word	osccal;
	int i, pgmlen;

	if (!currentDevice)
	{
		printf("Warning: No device selected\n");
		return;
	}

	for (i=0; i<16; i++)
		id[i] = 0;

	pgmlen = currentDevice->instlen;

	if (currentDevice->family == BASELINE)
	{
		cmd[0] = ENTERPGMVDD1ST;	// get config word
		cmd[1] = READPGM;
		cmd[2] = EXITPGM;
		sendPickitCmd(d, cmd, 3);
		recvWords(d, 1, id);
		currentDevice->config[0] = id[0];

		cmd[0] = ENTERPGMVDD1ST;	// get osccal and user IDs for baseline device
		cmd[1] = INCADDRESS;			// osccal is last word of program memory
		cmd[2] = pgmlen & 0xff;
		cmd[3] = (pgmlen >> 8) & 0xff;
		cmd[4] = READPGM;
		cmd[5] = EXITPGM;
		sendPickitCmd(d, cmd, 6);
		recvWords(d, 16, id);
		currentDevice->osccal = id[0];
		currentDevice->bosccal = id[5];	// save backup osccal word

		for (i=0; i<4; i++)			// save ID words
			currentDevice->ID[i] = id[i + 1];
	}

	if (currentDevice->family == MIDRANGE)
	{
		cmd[0] = currentDevice->pgmCommand;
		cmd[1] = WRITECONFIG;		// go to config mem, read ID and config words
		cmd[2] = READPGM;				// must read config/ID before reading osccal!
		cmd[3] = EXITPGM;
		sendPickitCmd(d, cmd, 4);
		recvWords(d, 16, id);

		for (i=0; i<4; i++)
			currentDevice->ID[i] = id[i];

		currentDevice->config[0] = id[7];
		currentDevice->config[1] = id[8];

		--pgmlen;
		cmd[0] = currentDevice->pgmCommand;
		cmd[1] = INCADDRESS;			// osccal is last word of program memory
		cmd[2] = pgmlen & 0xff;
		cmd[3] = (pgmlen >> 8) & 0xff;
		cmd[4] = READPGM;
		cmd[5] = EXITPGM;
		sendPickitCmd(d, cmd, 6);
		recvWords(d, 1, &osccal);
		currentDevice->osccal = osccal;
	}

	if (currentDevice->family == PIC18F)
	{
		cmd[0] = ENTERPGMVDD1ST;
		cmd[1] = PIC18FREAD;		// read user ID
		cmd[2] = 8;
		cmd[3] = 0;
		cmd[4] = 0;
		cmd[5] = 0x20;
		cmd[6] = EXITPGM;
		sendPickitCmd(d, cmd, 7);
		recvWords(d, 16, id);

		for (i=0; i<4; i++)
			currentDevice->ID[i] = id[i];

		cmd[0] = ENTERPGMVDD1ST;
		cmd[1] = PIC18FREAD;		// read config words
		cmd[2] = 14;
		cmd[3] = 0;
		cmd[4] = 0;
		cmd[5] = 0x30;
		cmd[6] = EXITPGM;
		sendPickitCmd(d, cmd, 7);
		recvWords(d, 16, id);

		for (i=0; i<7; i++)
			currentDevice->config[i] = id[i];
	}

	if (currentDevice->family == PIC18J)
	{
		currentDevice->IDlen = 0;
		currentDevice->osccal = 0;

		cmd[0] = PIC18J_ENTERPROG;		// read 4 words at end of program memory
		cmd[1] = PIC18FREAD;
		cmd[2] = 8;
		cmd[3] = ((currentDevice->instlen - 4) << 1) & 0xff;
		cmd[4] = ((currentDevice->instlen - 4) >> 7) & 0xff;
		cmd[5] = ((currentDevice->instlen - 4) >> 15) & 0xff;
		sendPickitCmd(d, cmd, 6);
		recvWords(d, 4, id);
		cmd[0] = PIC18J_EXITPROG;
		sendPickitCmd(d, cmd, 1);

		for (i=0; i<4; i++)
			currentDevice->config[i] = id[i];
	}
}

// Write the configuration word(s) to the device.
// Applies to baseline, 18f and a few midrange devices.

void pickitWriteConfigWords(pickit_dev *d, int count, int cfg[])
{
	int	i;

	if (!count)
		return;

	switch (currentDevice->family)
	{
		case BASELINE:
			cmd[0] = POWERCTRL;
			cmd[1] = 1;
			cmd[2] = ENTERPGMVDD1ST;
			cmd[3] = WRITEPGMEXT;
			cmd[4] = cfg[0] & 0xff;
			cmd[5] = (cfg[0] >> 8) & 0xff;
			cmd[6] = POWERCTRL;
			cmd[7] = 0;
			sendPickitCmd(d, cmd, 8);
			break;

		case MIDRANGE:
			cmd[0] = POWERCTRL;
			cmd[1] = 1;
			cmd[2] = currentDevice->pgmCommand;
			cmd[3] = WRITECONFIG;
			cmd[4] = INCADDRESS;
			cmd[5] = 7;
			cmd[6] = 0;

			for (i=0; i<count; i++)
			{
				cmd[i * 3 + 7] = WRITEPGM;
				cmd[i * 3 + 8] = cfg[i] & 0xff;
				cmd[i * 3 + 9] = (cfg[i] >> 8) & 0xff;
			}

			cmd[count * 3 + 7] = EXITPGM;
			cmd[count * 3 + 8] = POWERCTRL;
			cmd[count * 3 + 9] = 0;
			sendPickitCmd(d, cmd, count * 3 + 10);
			break;

		case PIC18F:
			cmd[0] = POWERCTRL;
			cmd[1] = 1;
			cmd[2] = currentDevice->pgmCommand;

			for (i=0; i<count; i++)
			{
				cmd[i * 4 + 3] = PIC18FWRITECONFIG;

				if ((i == 5) && (count > 6))		// must write config7 before config6
				{
					cmd[i * 4 + 4] = 12;
					cmd[i * 4 + 5] = cfg[6] & 0xff;
					cmd[i * 4 + 6] = (cfg[6] >> 8) & 0xff;
				}
				else if ((i == 6) && (count > 6))
				{
					cmd[i * 4 + 4] = 10;
					cmd[i * 4 + 5] = cfg[5] & 0xff;
					cmd[i * 4 + 6] = (cfg[5] >> 8) & 0xff;
				}
				else
				{
					cmd[i * 4 + 4] = (byte) (i * 2);
					cmd[i * 4 + 5] = cfg[i] & 0xff;
					cmd[i * 4 + 6] = (cfg[i] >> 8) & 0xff;
				}
			}

			cmd[count * 4 + 3] = EXITPGM;
			cmd[count * 4 + 4] = POWERCTRL;
			cmd[count * 4 + 5] = 0;
			sendPickitCmd(d, cmd, count * 4 + 6);
			break;

			// Can't write just config words to PIC18J since memory must be
			// written in 64 byte blocks
		case PIC18J:
			fatalError("Can't write only config words to PIC18J devices, you must program from a hex file.");
			break;
	}
}

// Write the ID word(s) to the device.

void pickitWriteIDWords(pickit_dev *d, int count, int ID[])
{
	int	i, pgmlen;

	if (!count)
	{
		warning("No ID words specified");
		return;
	}

	if (currentDevice->family == PIC18J)
		fatalError("PIC18J devices have no User IDs.");

	if (count > 4)
	{
		warning("Device has only 4 ID words, extra ignored.");
		count = 4;
	}
		
	printf("Writing ID words:");

	for (i=0; i<count; i++)
		printf(" %04x", ID[i]);

	printf("\n\n");

	switch (currentDevice->family)
	{
		case BASELINE:
			pgmlen = currentDevice->instlen;
			pgmlen++;		// osccal is last word of program memory, ID is after pgm mem
			cmd[0] = ENTERPGMVDD1ST;
			cmd[1] = INCADDRESS;
			cmd[2] = pgmlen & 0xff;
			cmd[3] = (pgmlen >> 8) & 0xff;

			for (i=0; i<count; i++)
			{
				cmd[i * 3 + 4] = WRITEPGMEXT;
				cmd[i * 3 + 5] = ID[i] & 0xff;
				cmd[i * 3 + 6] = (ID[i] >> 8) & 0xff;
			}

			cmd[count * 3 + 4] = EXITPGM;
			sendPickitCmd(d, cmd, count * 3 + 5);
			break;

		case MIDRANGE:
			if ((currentDevice->pgmMode != '1') &&
					(currentDevice->pgmMode != '4') &&
					(currentDevice->pgmTiming == WRITEBYnINT))	// 16F87xA
			{
				cmd[0] = currentDevice->pgmCommand;
				cmd[1] = WRITECONFIG;
				cmd[2] = WRITEBYFOUR;

				for (i=0; i<count; i++)
				{
					cmd[i * 2 + 3] = ID[i] & 0xff;
					cmd[i * 2 + 4] = (ID[i] >> 8) & 0xff;
				}

				for ( ; i<4; i++)
				{
					cmd[i * 2 + count * 2 + 3] = 0xff;
					cmd[i * 2 + count * 2 + 4] = 0xff;
				}

				cmd[11] = EXITPGM;
				sendPickitCmd(d, cmd, 12);
			}
			else
			{
				cmd[0] = currentDevice->pgmCommand;
				cmd[1] = WRITECONFIG;

				for (i=0; i<count; i++)
				{
					cmd[i * 3 + 2] = WRITEPGM;
					cmd[i * 3 + 3] = ID[i] & 0xff;
					cmd[i * 3 + 4] = (ID[i] >> 8) & 0xff;
				}

				cmd[count * 3 + 2] = EXITPGM;
				sendPickitCmd(d, cmd, count * 3 + 3);
			}
			break;

		case PIC18F:
			cmd[0] = currentDevice->pgmCommand;
			cmd[1] = PIC18FWRITE_1;
			cmd[2] = (byte) count;
			cmd[3] = 0;
			cmd[4] = 0;
			cmd[5] = 0x20;

			for (i=0; i<count; i++)
			{
				cmd[i * 2 + 6] = ID[i] & 0xff;
				cmd[i * 2 + 7] = (ID[i] >> 8) & 0xff;
			}

			cmd[count * 2 + 6] = EXITPGM;
			sendPickitCmd(d, cmd, count * 2 + 7);
			break;
	}
}

// Write osccal to the device.
// For baseline devices:
//  option 0 = write osccal and backup,
//  option 1 = write only primary osccal,
//  option 2 = write only backup osccal.
// Option is ignored for non-baseline devices.

void pickitWriteOsccal(pickit_dev *d, int osccal, int option)
{
	int	offset;

	if (!currentDevice)
		fatalError("No device selected");

	if (!currentDevice->saveOscCal)
		fatalError("Device has no osccal");

	switch (currentDevice->family)
	{
		case BASELINE:
			if (option != 2)		// write primary osccal word
			{
				offset = currentDevice->instlen;	// skip over config word and pgm mem
				cmd[0] = POWERCTRL;
				cmd[1] = 1;
				cmd[2] = ENTERPGMVDD1ST;
				cmd[3] = INCADDRESS;
				cmd[4] = offset & 0xff;
				cmd[5] = (offset >> 8) & 0xff;
				cmd[6] = WRITEPGMEXT;
				cmd[7] = osccal & 0xff;
				cmd[8] = (osccal >> 8) & 0xff;
				cmd[9] = EXITPGM;
				cmd[10] = POWERCTRL;
				cmd[11] = 0;
				sendPickitCmd(d, cmd, 12);
			}

			if (option != 1)		// write backup osccal word
			{			// skip over config, pgm mem and 4 words user ID to backup osccal
				offset = currentDevice->instlen + 5;
				cmd[0] = POWERCTRL;
				cmd[1] = 1;
				cmd[2] = ENTERPGMVDD1ST;
				cmd[3] = INCADDRESS;
				cmd[4] = offset & 0xff;
				cmd[5] = (offset >> 8) & 0xff;
				cmd[6] = WRITEPGMEXT;
				cmd[7] = osccal & 0xff;
				cmd[8] = (osccal >> 8) & 0xff;
				cmd[9] = EXITPGM;
				cmd[10] = POWERCTRL;
				cmd[11] = 0;
				sendPickitCmd(d, cmd, 12);
			}
			break;

		case MIDRANGE:
			offset = currentDevice->instlen - 1;
			cmd[0] = POWERCTRL;
			cmd[1] = 1;
			cmd[2] = ENTERPGM;
			cmd[3] = INCADDRESS;
			cmd[4] = offset & 0xff;
			cmd[5] = (offset >> 8) & 0xff;
			cmd[6] = WRITEPGM;
			cmd[7] = osccal & 0xff;
			cmd[8] = (osccal >> 8) & 0xff;
			cmd[9] = EXITPGM;
			cmd[10] = POWERCTRL;
			cmd[11] = 0;
			sendPickitCmd(d, cmd, 12);
			break;

		default:
			fatalError("Invalid family");
			break;
	}
}

// Read from device and compare to file data.
// Return 1 if ok, 0 if failure.

bool verifyProgramming(pickit_dev *d, int options)
{
	int	i;
	bool	ok = TRUE;

	printf("Verifying...\n");
	pickitReadProgram(d);

	if (currentDevice->family != PIC18J)
		pickitReadEeprom(d);

	if (!options || (options & PROG_PGM))	// compare program data
	{
		for (i=0; i<currentDevice->instlen - 1; i++)	// don't compare osccal
		{
			if (currentDevice->program[i] != currentDevice->fprogram[i])
			{
				ok = FALSE;
				break;
			}
		}
	}

	if (!options || (options & PROG_DATA))	// compare eeprom data
	{
		for (i=0; i<currentDevice->eelen; i++)
		{
			if ((currentDevice->eeprom[i] & 0xff) != (currentDevice->feeprom[i] & 0xff))
			{
				ok = FALSE;
				break;
			}
		}
	}

	return ok;
}

// Target device programming routines
// Program Mode options (bit flags). If option is 0, then program entire device
// PROG_DRY			1	// dry run, don't acutually program anything
// PROG_PGM			2	// write program memory only
// PROG_DATA		4	// write eeprom only
// PROG_NOVERIFY	8	// do not verify before writing config word
//   PROG_PGM and PROG_DATA cannot both be true.

void pickitWriteBaseline(pickit_dev *d, int options)
{
	int	i, j, configOK;
	picdev_word	cfg;

	if (!(options & PROG_DRY))
	{
		if (!options)
			pkEraseBaseline(d, 0, PROG_PGM | PROG_DATA);		// erase everything
		else
			pkEraseBaseline(d, 0, options);
	}

	if (!(options & (PROG_DATA | PROG_DRY)))	// write program memory
	{
		printf("Writing program...\n");
		cmd[0] = ENTERPGMVDD1ST;
		cmd[1] = INCADDRESS;
		cmd[2] = 1;
		cmd[3] = 0;
		sendPickitCmd(d, cmd, 4);

		for (i=0; i<currentDevice->instlen; i+=16)
		{
			for (j=0; j<16; j++)
			{
				cmd[j * 3] = WRITEPGMEXT;
				cmd[j * 3 + 1] = currentDevice->program[i + j] & 0xff;
				cmd[j * 3 + 2] = (currentDevice->program[i + j] >> 8) & 0xff;
			}

			sendPickitCmd(d, cmd, 48);

#ifndef WIN32
			progress_update(16);
#endif
		}

		for (i=0; i<4; i++)		// write user ID
		{
			cmd[i * 3] = WRITEPGMEXT;
			cmd[i * 3 + 1] = currentDevice->ID[i] & 0xff;
			cmd[i * 3 + 2] = (currentDevice->ID[i] >> 8) & 0xff;
		}

		if (currentDevice->saveOscCal && (currentDevice->osccal != 0xfff))
		{
			cmd[12] = WRITEPGMEXT;
			cmd[13] = currentDevice->osccal & 0xff;
			cmd[14] = (currentDevice->osccal >> 8) & 0xff;
			cmd[15] = EXITPGM;
			sendPickitCmd(d, cmd, 16);
		}
		else
		{
			cmd[12] = EXITPGM;
			sendPickitCmd(d, cmd, 13);
		}
	}

	if (!(options & (PROG_PGM | PROG_DRY)) && currentDevice->eelen)	// write EEPROM data
	{
		printf("Writing eeprom...\n");
		cmd[0] = ENTERPGMVDD1ST;
		sendPickitCmd(d, cmd, 1);

		for (i=0; i<currentDevice->eelen; i+=4)
		{
			cmd[0] = WRITEDATA;
			cmd[1] = (byte) currentDevice->eeprom[i];
			cmd[2] = WRITEDATA;
			cmd[3] = (byte) currentDevice->eeprom[i + 1];
			cmd[4] = WRITEDATA;
			cmd[5] = (byte) currentDevice->eeprom[i + 2];
			cmd[6] = WRITEDATA;
			cmd[7] = (byte) currentDevice->eeprom[i + 3];
			sendPickitCmd(d, cmd, 8);

#ifndef WIN32
			progress_update(4);
#endif
		}

		cmd[0] = EXITPGM;
		sendPickitCmd(d, cmd, 1);
	}

	cfg = currentDevice->config[0];	// save config data since verifyProgramming will overwrite it
	configOK = 1;	// if no verify requested, just write config word

	if (!(options & PROG_NOVERIFY) && !(options & PROG_DRY))	// verify before writing config word
	{
		configOK = verifyProgramming(d, options);	// if failed to verify, don't write config word

		if (!configOK)
			warning("Verify failed! Config word not written.");
	}

	if (!(options & PROG_DRY) && configOK)		// write config word
	{
		currentDevice->config[0] = cfg;			// restore config word
		cmd[0] = ENTERPGMVDD1ST;
		cmd[1] = WRITEPGMEXT;
		cmd[2] = currentDevice->config[0] & 0xff;
		cmd[3] = (currentDevice->config[0] >> 8) & 0xff;
		cmd[4] = EXITPGM;
		sendPickitCmd(d, cmd, 5);
	}
}

// Write midrange program memory using by 1 algorithm

void pkwriteMidrangePgm1(pickit_dev *d)
{
	int	i, j;
	picdev_word	*pdata;

	printf("Writing program...\n");
	cmd[0] = currentDevice->pgmCommand;
	sendPickitCmd(d, cmd, 1);
	pdata = currentDevice->program;

	for (i=0; i<currentDevice->instlen; i+= 8)
	{
		for (j=0; j<8; j++)
		{
			cmd[j * 3] = WRITEPGM;
			cmd[j * 3 + 1] = *pdata & 0xff;
			cmd[j * 3 + 2] = ((*pdata) >> 8) & 0xff;
			pdata++;
		}

		sendPickitCmd(d, cmd, 24);

#ifndef WIN32
		progress_update(8);
#endif
	}
	
	cmd[0] = EXITPGM;
	sendPickitCmd(d, cmd, 1);
}

// Write midrange program memory using by 4 algorithm

void pkwriteMidrangePgm4(pickit_dev *d)
{
	int	i, j;
	picdev_word	*pdata;

	printf("Writing program...\n");
	cmd[0] = currentDevice->pgmCommand;
	sendPickitCmd(d, cmd, 1);
	pdata = currentDevice->program;

	for (i=0; i<currentDevice->instlen; i+= 16)
	{
		for (j=0; j<4; j++)
		{
			cmd[j * 9] = WRITEBYFOUR;
			cmd[j * 9 + 1] = *pdata & 0xff;
			cmd[j * 9 + 2] = ((*pdata) >> 8) & 0xff;
			pdata++;
			cmd[j * 9 + 3] = *pdata & 0xff;
			cmd[j * 9 + 4] = ((*pdata) >> 8) & 0xff;
			pdata++;
			cmd[j * 9 + 5] = *pdata & 0xff;
			cmd[j * 9 + 6] = ((*pdata) >> 8) & 0xff;
			pdata++;
			cmd[j * 9 + 7] = *pdata & 0xff;
			cmd[j * 9 + 8] = ((*pdata) >> 8) & 0xff;
			pdata++;
		}

		sendPickitCmd(d, cmd, 36);

#ifndef WIN32
		progress_update(16);
#endif
	}
	
	cmd[0] = EXITPGM;
	sendPickitCmd(d, cmd, 1);
}

// Write midrange program memory using by n algorithm

void pkwriteMidrangePgmN(pickit_dev *d)
{
	int	i, j, words;
	picdev_word	*pdata;

	printf("Writing program...\n");
	cmd[0] = currentDevice->pgmCommand;
	sendPickitCmd(d, cmd, 1);
	pdata = currentDevice->program;
	words = currentDevice->writeBurst;	// 1, 2, 4, or 8 words per write command

	for (i=0; i<currentDevice->instlen; i += words)
	{
		cmd[0] = currentDevice->pgmTiming;
		cmd[1] = (byte) words;

		for (j=0; j<words; j++)
		{
			cmd[2 * j + 2] = currentDevice->program[i + j] & 0xff;
			cmd[2 * j + 3] = currentDevice->program[i + j] >> 8;
		}

		sendPickitCmd(d, cmd, words * 2 + 2);

#ifndef WIN32
		progress_update(words);
#endif
	}
	
	cmd[0] = EXITPGM;
	sendPickitCmd(d, cmd, 1);
}

// Target device programming routines
// Program Mode options (bit flags). If option is 0, then program entire device
// PROG_DRY			1	// dry run, don't acutually program anything
// PROG_PGM			2	// write program memory only
// PROG_DATA		4	// write eeprom only
// PROG_NOVERIFY	8	// do not verify before writing config word
//   PROG_PGM and PROG_DATA cannot both be true.

void pickitWriteMidrange(pickit_dev *d, int options)
{
	int	i, configOK;
	byte	eecmd = 0, mode = 0;
	picdev_word	cfg0, cfg1;

	if (!(options & PROG_DRY))
	{
		if (!options)
			pkEraseMidrange(d, 0, PROG_PGM | PROG_DATA);		// erase everything
		else
			pkEraseMidrange(d, 0, options);
	}

	if (!(options & (PROG_DATA | PROG_DRY)))	// write program memory
	{
		if (currentDevice->saveOscCal)		// set up osccal word
			currentDevice->program[currentDevice->instlen - 1] = currentDevice->osccal;

		switch (currentDevice->pgmMode)
		{
			case '1':
				pkwriteMidrangePgm1(d);
				break;

			case '4':
				pkwriteMidrangePgm4(d);
				break;

			default:
				pkwriteMidrangePgmN(d);
				break;
		}
	}

	if (!(options & (PROG_PGM | PROG_DRY)) && currentDevice->eelen)	// write EEPROM data
	{
		printf("Writing eeprom...\n");
		cmd[0] = currentDevice->pgmCommand;
		sendPickitCmd(d, cmd, 1);

		switch (currentDevice->pgmMode)
		{
			case '1':
			case '2':
				eecmd = WRITEDATA;
				break;

			default:
				eecmd = currentDevice->dataTiming;
				break;
		}

		cmd[0] = eecmd;
		cmd[2] = eecmd;
		cmd[4] = eecmd;
		cmd[6] = eecmd;

		for (i=0; i<currentDevice->eelen; i += 4)
		{
			cmd[1] = (byte) currentDevice->eeprom[i];
			cmd[3] = (byte) currentDevice->eeprom[i + 1];
			cmd[5] = (byte) currentDevice->eeprom[i + 2];
			cmd[7] = (byte) currentDevice->eeprom[i + 3];
			sendPickitCmd(d, cmd, 8);

#ifndef WIN32
			progress_update(4);
#endif
		}

		cmd[0] = EXITPGM;
		sendPickitCmd(d, cmd, 1);
	}

// write User ID and config word

	cfg0 = currentDevice->config[0];
	cfg0 &= currentDevice->configMask[0];
	cfg1 = currentDevice->config[1];
	cfg1 &= currentDevice->configMask[1];

	// if verify required, do not enable code protection yet

	if (!(options & PROG_DRY) && !(options & PROG_NOVERIFY))
		cfg0 |= currentDevice->CPMask;

	cmd[0] = currentDevice->pgmCommand;
	cmd[1] = WRITECONFIG;

	if (currentDevice->pgmMode == '1' || currentDevice->pgmMode == '2')
	{
		cmd[2] = WRITEPGM;
		cmd[3] = (byte) currentDevice->ID[0] & 0xff;
		cmd[4] = (byte) (currentDevice->ID[0] >> 8) & 0xff;
		cmd[5] = WRITEPGM;
		cmd[6] = (byte) currentDevice->ID[1] & 0xff;
		cmd[7] = (byte) (currentDevice->ID[1] >> 8) & 0xff;
		cmd[8] = WRITEPGM;
		cmd[9] = (byte) currentDevice->ID[2] & 0xff;
		cmd[10] = (byte) (currentDevice->ID[2] >> 8) & 0xff;
		cmd[11] = WRITEPGM;
		cmd[12] = (byte) currentDevice->ID[3] & 0xff;
		cmd[13] = (byte) (currentDevice->ID[3] >> 8) & 0xff;
		cmd[14] = INCADDRESS;
		cmd[15] = 3;
		cmd[16] = 0;
		cmd[17] = WRITEPGM;
		cmd[18] = (byte) cfg0 & 0xff;
		cmd[19] = (byte) (cfg0 >> 8) & 0xff;
		cmd[20] = EXITPGM;
		sendPickitCmd(d, cmd, 21);
	}
	else
	{
		if (currentDevice->pgmTiming == WRITEBYnINT)
		{
			mode = WRITEPGM;
			cmd[2] = WRITEBYFOUR;
			cmd[3] = (byte) currentDevice->ID[0] & 0xff;
			cmd[4] = (byte) (currentDevice->ID[0] >> 8) & 0xff;
			cmd[5] = (byte) currentDevice->ID[1] & 0xff;
			cmd[6] = (byte) (currentDevice->ID[1] >> 8) & 0xff;
			cmd[7] = (byte) currentDevice->ID[2] & 0xff;
			cmd[8] = (byte) (currentDevice->ID[2] >> 8) & 0xff;
			cmd[9] = (byte) currentDevice->ID[3] & 0xff;
			cmd[10] = (byte) (currentDevice->ID[3] >> 8) & 0xff;
			sendPickitCmd(d, cmd, 11);
		}
		else
		{
			mode = WRITEPGMEXT;
			cmd[2] = WRITEPGMEXT;
			cmd[3] = (byte) currentDevice->ID[0] & 0xff;
			cmd[4] = (byte) (currentDevice->ID[0] >> 8) & 0xff;
			cmd[5] = WRITEPGMEXT;
			cmd[6] = (byte) currentDevice->ID[1] & 0xff;
			cmd[7] = (byte) (currentDevice->ID[1] >> 8) & 0xff;
			cmd[8] = WRITEPGMEXT;
			cmd[9] = (byte) currentDevice->ID[2] & 0xff;
			cmd[10] = (byte) (currentDevice->ID[2] >> 8) & 0xff;
			cmd[11] = WRITEPGMEXT;
			cmd[12] = (byte) currentDevice->ID[3] & 0xff;
			cmd[13] = (byte) (currentDevice->ID[3] >> 8) & 0xff;
			sendPickitCmd(d, cmd, 14);
		}

		cmd[0] = INCADDRESS;
		cmd[1] = 3;
		cmd[2] = 0;
		cmd[3] = mode;
		cmd[4] = cfg0 & 0xff;
		cmd[5] = (cfg0 >> 8) & 0xff;

		if (currentDevice->configMask[1])
		{
			cmd[6] = mode;
			cmd[7] = cfg1 & 0xff;
			cmd[8] = (cfg1 >> 8) & 0xff;
			cmd[9] = EXITPGM;
			sendPickitCmd(d, cmd, 10);
		}
		else
		{
			cmd[6] = EXITPGM;
			sendPickitCmd(d, cmd, 7);
		}
	}

	cfg0 = currentDevice->config[0];	// save config word since verifyProgramming will overwrite them
	cfg1 = currentDevice->config[1];
	configOK = 1;	// if no verify requested, just write config word

	if (!(options & PROG_NOVERIFY) && !(options & PROG_DRY))	// verify before writing config word
	{
		configOK = verifyProgramming(d, options);	// if failed to verify, don't write config word

		if (!configOK)
			warning("Verify failed! Config word not written.");
	}

	currentDevice->config[0] = cfg0;	// restore config words
	currentDevice->config[1] = cfg1;

// Rewrite config word(s). If config[1] exists, both config
// words must be written even though config1 hasn't changed.

	if (!(options & PROG_DRY) && !(options & PROG_NOVERIFY) && configOK)
	{
		cfg0 = currentDevice->config[0];
		cfg0 &= currentDevice->configMask[0];
		cfg1 = currentDevice->config[1];
		cfg1 &= currentDevice->configMask[1];

		cmd[0] = currentDevice->pgmCommand;
		cmd[1] = WRITECONFIG;
		cmd[2] = INCADDRESS;
		cmd[3] = 7;
		cmd[4] = 0;

		if (currentDevice->pgmMode == '1' || currentDevice->pgmMode == '2')
		{
			cmd[5] = WRITEPGM;
			cmd[6] = (byte) cfg0 & 0xff;
			cmd[7] = (byte) (cfg0 >> 8) & 0xff;
			cmd[8] = EXITPGM;
			sendPickitCmd(d, cmd, 9);
		}
		else		// write by n
		{
			cmd[5] = mode;
			cmd[6] = (byte) cfg0 & 0xff;
			cmd[7] = (byte) (cfg0 >> 8) & 0xff;

			if (currentDevice->configMask[1])
			{
				cmd[8] = mode;
				cmd[9] = cfg1 & 0xff;
				cmd[10] = (cfg1 >> 8) & 0xff;
				cmd[11] = EXITPGM;
				sendPickitCmd(d, cmd, 12);
			}
			else
			{
				cmd[8] = EXITPGM;
				sendPickitCmd(d, cmd, 9);
			}
		}
	}
}

// Target device programming routines
// Program Mode options (bit flags). If option is 0, then program entire device
// PROG_DRY			1	// dry run, don't acutually program anything
// PROG_PGM			2	// write program memory only
// PROG_DATA		4	// write eeprom only
// PROG_NOVERIFY	8	// do not verify before writing config word
//   PROG_PGM and PROG_DATA cannot both be true.

void pickitWrite18F(pickit_dev *d, int options)
{
	int	i, j, configOK;
	picdev_word	cfg[8];		// for saving config data
	char	errmsg[64];

	if (!(options & PROG_DRY))
	{
		switch (currentDevice->eraseMode)
		{
			case 1:
				pkErase18F1byte(d);
				break;

			case 2:
				pkErase18F2byte(d);
				break;

			default:
				sprintf(errmsg, "Invalid PIC18 erase mode: %d", currentDevice->eraseMode);
				fatalError(errmsg);
				break;
		}
	}

	if (!(options & (PROG_DATA | PROG_DRY)))	// write program memory
	{
		printf("Writing program...\n");
		cmd[0] = currentDevice->pgmCommand;
		sendPickitCmd(d, cmd, 1);
		cmd[0] = PIC18FWRITE_1;
		cmd[1] = currentDevice->writeBurst;

		for (i=0; i<currentDevice->instlen; i += currentDevice->writeBurst)
		{
			cmd[2] = (i << 1) & 0xff;		// low address
			cmd[3] = (i >> 7) & 0xff;		// high address
			cmd[4] = (i >> 15) & 0xff;		// segment

			for (j=0; j<currentDevice->writeBurst; j++)
			{
				cmd[j * 2 + 5] = currentDevice->program[i + j] & 0xff;
				cmd[j * 2 + 6] = (currentDevice->program[i + j] >> 8) & 0xff;
			}

			sendPickitCmd(d, cmd, currentDevice->writeBurst * 2 + 5);

#ifndef WIN32
			progress_update(currentDevice->writeBurst);
#endif
		}
	}

	if (!(options & (PROG_PGM | PROG_DRY)) && currentDevice->eelen)	// write EEPROM data
	{
		printf("Writing eeprom...\n");
		cmd[0] = PIC18FEEDATAWRITE;
		cmd[1] = 32;

		for (i=0; i<currentDevice->eelen; i+=32)
		{
			cmd[2] = (byte) i;
			cmd[3] = (i >> 8) & 0xff;

			for (j=0; j<32; j++)
				cmd[j + 4] = (byte) currentDevice->eeprom[i + j];

			sendPickitCmd(d, cmd, 36);

#ifndef WIN32
			progress_update(32);
#endif
		}
	}

	if (!(options & PROG_DRY))
	{
		cmd[0] = PIC18FWRITE_1;		// write User IDs
		cmd[1] = 4;						// number of words
		cmd[2] = 0;						// address
		cmd[3] = 0;
		cmd[4] = 0x20;
		cmd[5] = currentDevice->ID[0] & 0xff;
		cmd[6] = (currentDevice->ID[0] >> 8) & 0xff;
		cmd[7] = currentDevice->ID[1] & 0xff;
		cmd[8] = (currentDevice->ID[1] >> 8) & 0xff;
		cmd[9] = currentDevice->ID[2] & 0xff;
		cmd[10] = (currentDevice->ID[2] >> 8) & 0xff;
		cmd[11] = currentDevice->ID[3] & 0xff;
		cmd[12] = (currentDevice->ID[3] >> 8) & 0xff;
		sendPickitCmd(d, cmd, 13);

		configOK = 1;

		for (i=0; i<7; i++)		// save config data since verifyProgramming will overwrite it
			cfg[i] = currentDevice->config[i];

		if (!(options & PROG_NOVERIFY))
		{
			configOK = verifyProgramming(d, options);	// if failed to verify, don't write config word

			if (!configOK)
				warning("Verify failed! Config words not written.");
		}

		if (configOK)
		{
			for (i=0; i<7; i++)		// restore config data
				currentDevice->config[i] = cfg[i];

			if (!(options & PROG_NOVERIFY))		// verifyProgramming exited program mode
			{
				cmd[0] = currentDevice->pgmCommand;
				sendPickitCmd(d, cmd, 1);
			}

			cmd[0] = PIC18FWRITECONFIG;	// write config words
			cmd[1] = 0;
			cmd[2] = currentDevice->config[0] & 0xff;
			cmd[3] = (currentDevice->config[0] >> 8) & 0xff;
			cmd[4] = PIC18FWRITECONFIG;
			cmd[5] = 2;
			cmd[6] = currentDevice->config[1] & 0xff;
			cmd[7] = (currentDevice->config[1] >> 8) & 0xff;
			cmd[8] = PIC18FWRITECONFIG;
			cmd[9] = 4;
			cmd[10] = currentDevice->config[2] & 0xff;
			cmd[11] = (currentDevice->config[2] >> 8) & 0xff;
			cmd[12] = PIC18FWRITECONFIG;
			cmd[13] = 6;
			cmd[14] = currentDevice->config[3] & 0xff;
			cmd[15] = (currentDevice->config[3] >> 8) & 0xff;
			cmd[16] = PIC18FWRITECONFIG;
			cmd[17] = 8;
			cmd[18] = currentDevice->config[4] & 0xff;
			cmd[19] = (currentDevice->config[4] >> 8) & 0xff;
// Write config6 before config5
			cmd[20] = PIC18FWRITECONFIG;
			cmd[21] = 12;
			cmd[22] = currentDevice->config[6] & 0xff;
			cmd[23] = (currentDevice->config[6] >> 8) & 0xff;
			cmd[24] = PIC18FWRITECONFIG;
			cmd[25] = 10;
			cmd[26] = currentDevice->config[5] & 0xff;
			cmd[27] = (currentDevice->config[5] >> 8) & 0xff;
			cmd[28] = EXITPGM;
			sendPickitCmd(d, cmd, 29);
		}
	}
}

// Target device programming routines
// Program Mode options (bit flags). If option is 0, then program entire device
// PROG_DRY			1	// dry run, don't acutually program anything
// PROG_PGM			2	// write program memory only
// PROG_DATA		4	// write eeprom only
// PROG_NOVERIFY	8	// do not verify before writing config word
//   PROG_PGM and PROG_DATA cannot both be true.

void pickitWrite18J(pickit_dev *d, int options)
{
	int	i, j, adrs, verifyOK;
	picdev_word	bfr[32];

	cmd[0] = PIC18J_ENTERPROG;
	sendPickitCmd(d, cmd, 1);

	for (i=0; i<currentDevice->instlen; i+=32)
	{
		cmd[0] = PIC18J_BUFFER32;

		for (j=0; j<16; j++)
		{
			cmd[j * 2 + 1] = currentDevice->program[i + j] & 0xff;
			cmd[j * 2 + 2] = (currentDevice->program[i + j] >> 8) & 0xff;
		}

		sendPickitCmd(d, cmd, 33);

		cmd[0] = PIC18J_WRITE64;
		cmd[1] = (i << 1) & 0xff;
		cmd[2] = (i >> 7) & 0xff;
		cmd[3] = (i >> 15) & 0xff;

		for (j=0; j<16; j++)
		{
			cmd[j * 2 + 4] = currentDevice->program[i + j + 16] & 0xff;
			cmd[j * 2 + 5] = (currentDevice->program[i + j + 16] >> 8) & 0xff;
		}

		sendPickitCmd(d, cmd, 36);
	}

	verifyOK = TRUE;

	if (!options || (options & PROG_PGM))	// compare program data
	{
		for (adrs = 0; verifyOK && (adrs < currentDevice->instlen); adrs += 256)
		{
			for (i=0; i<8; i++)		// 512 bytes, 256 words
			{
				cmd[0 + i * 5] = PIC18FREAD;
				cmd[1 + i * 5] = 64;		// read 64 bytes at a time
				cmd[2 + i * 5] = ((adrs + i * 32) << 1) & 0xff;
				cmd[3 + i * 5] = ((adrs + i * 32) >> 7) & 0xff;
				cmd[4 + i * 5] = ((adrs + i * 32) >> 15) & 0xff;
			}

			sendPickitCmd(d, cmd, 40);

			for (i=0; i<256; i += 32)		// loop 8 times
			{
				recvWords(d, 32, bfr);		// read 32 words

				for (j=0; j<32; j++)
				{
					if (currentDevice->program[adrs + i + j] != bfr[j])
					{
						verifyOK = FALSE;
						break;
					}
				}
			}

#ifndef WIN32
			progress_update(256);
#endif
		}
	}

	cmd[0] = PIC18J_EXITPROG;
	sendPickitCmd(d, cmd, 1);

	if (!verifyOK)
		warning("Verify failed!.");
}

// Program target device.

void pickitWrite(pickit_dev *d, int options)
{
	if (options & PROG_DRY)
		DryRun = 1;		// if dry run, don't actually write anything to the PIC chip
	else
	{
		DryRun = 0;
		sendCmdTable(d, currentDevice->cmdtbl);
	}

	switch (currentDevice->family)
	{
		case BASELINE:
			pickitWriteBaseline(d, options);
			break;

		case MIDRANGE:
			pickitWriteMidrange(d, options);
			break;

		case PIC18F:
			pickitWrite18F(d, options);
			break;

		case PIC18J:
			pickitWrite18J(d, options);
			break;

		default:
			break;
	}
}

// Erase routines
// option may be 0, PROG_PGM, PROG_DATA, or both

void pkEraseBaseline(pickit_dev *d, int eraseall, int option)
{
	int	i;
	byte	osccall = 0, osccalh = 0;
	picdev_word	osccal;
	byte	buffer[8];

	printf("Erasing device...\n");
	cmd[0] = ENTERPGMVDD1ST;
	cmd[1] = INCADDRESS;
	cmd[2] = currentDevice->instlen & 0xff;
	cmd[3] = (currentDevice->instlen >> 8) & 0xff;
	sendPickitCmd(d, cmd, 4);

	if (currentDevice->saveOscCal && !eraseall)
	{
		cmd[0] = READPGM;
		sendPickitCmd(d, cmd, 1);
		recvUSB(d, 2, buffer);
		osccall = buffer[0];
		osccalh = buffer[1];
		osccal = (osccalh << 8) + (osccall & 0xff);
		currentDevice->osccal = osccal;
	}
	else
	{
		cmd[0] = INCADDRESS;
		cmd[1] = 1;
		cmd[2] = 0;
		sendPickitCmd(d, cmd, 3);
	}

	i = 0;

	if (option & PROG_PGM)
	{
		cmd[0] = ERASEPGM;
		i++;
	}

	if (option & PROG_DATA)
	{
		cmd[i] = ERASEDATA;
		i++;
	}

	cmd[i] = EXITPGM;
	sendPickitCmd(d, cmd, i + 1);

	if (currentDevice->saveOscCal && (osccall != 0xff) && (osccalh != 0x3f) && !eraseall)
	{
		cmd[0] = ENTERPGMVDD1ST;
		cmd[1] = INCADDRESS;
		cmd[2] = currentDevice->instlen & 0xff;
		cmd[3] = (currentDevice->instlen >> 8) & 0xff;
		cmd[4] = WRITEPGMEXT;
		cmd[5] = osccall;
		cmd[6] = osccalh;
		cmd[7] = EXITPGM;
		sendPickitCmd(d, cmd, 8);
	}
}

// option may be 0, PROG_PGM, PROG_DATA, or both

void pkEraseMidrange(pickit_dev *d, int eraseall, int option)
{
	picdev_word	bandgap = 0;
	byte	osccall = 0, osccalh = 0;
	picdev_word	osccal;
	byte	buffer[16];

	printf("Erasing device...\n");
	cmd[0] = POWERCTRL;
	cmd[1] = 1;
	sendPickitCmd(d, cmd, 2);

	if (currentDevice->saveOscCal && !eraseall)
	{
		cmd[0] = currentDevice->pgmCommand;
		cmd[1] = INCADDRESS;
		cmd[2] = (currentDevice->instlen - 1) & 0xff;
		cmd[3] = ((currentDevice->instlen - 1) >> 8) & 0xff;
		cmd[4] = READPGM;
		cmd[5] = EXITPGM;
		sendPickitCmd(d, cmd, 6);
		recvUSB(d, 2, buffer);
		osccall = buffer[0];
		osccalh = buffer[1];
		osccal = (osccalh << 8) + (osccall & 0xff);
		currentDevice->osccal = osccal;
	}

	if (currentDevice->saveBGBits)
	{
		cmd[0] = currentDevice->pgmCommand;
		cmd[1] = WRITECONFIG;
		cmd[2] = READPGM;
		cmd[3] = EXITPGM;
		sendPickitCmd(d, cmd, 4);
		recvUSB(d, 16, buffer);
		bandgap = (buffer[15] << 8) + (buffer[14] & 0xff);
		bandgap &= currentDevice->BGMask[0];
		currentDevice->bandGap[0] = bandgap;
	}

	cmd[0] = currentDevice->pgmCommand;
	cmd[1] = WRITECONFIG;
	cmd[2] = WRITEPGM;
	cmd[3] = 0xff;
	cmd[4] = 0x3f;

	if (option & PROG_PGM)
		cmd[5] = ERASEPGM;
	else
		cmd[5] = 'Z';

	if (option & PROG_DATA)
		cmd[6] = ERASEDATA;
	else
		cmd[6] = 'Z';

	cmd[7] = EXITPGM;
	sendPickitCmd(d, cmd, 8);

	if (currentDevice->saveOscCal && (osccall != 0xff) && (osccalh != 0x3f) && !eraseall)
	{
		cmd[0] = currentDevice->pgmCommand;
		cmd[1] = INCADDRESS;
		cmd[2] = (currentDevice->instlen - 1) & 0xff;
		cmd[3] = ((currentDevice->instlen - 1) >> 8) & 0xff;
		cmd[4] = WRITEPGM;
		cmd[5] = osccall;
		cmd[6] = osccalh;
		cmd[7] = EXITPGM;
		sendPickitCmd(d, cmd, 8);
	}

	if (currentDevice->saveBGBits)
	{
		cmd[0] = currentDevice->pgmCommand;
		cmd[1] = WRITECONFIG;
		cmd[2] = INCADDRESS;
		cmd[3] = 7;
		cmd[4] = 0;
		cmd[5] = WRITEPGM;
		cmd[6] = 0xff;
		cmd[7] = (bandgap >> 8) | 0x0f;
		cmd[8] = EXITPGM;
		sendPickitCmd(d, cmd, 9);
	}

	cmd[0] = POWERCTRL;
	cmd[1] = 0;
	sendPickitCmd(d, cmd, 2);
}

void pkErase18F1byte(pickit_dev *d)
{
	printf("Erasing device...\n");
	cmd[0] = ENTERPGMVDD1ST;
	cmd[1] = PIC18FERASE1;
	cmd[2] = 0x80;		// bulk erase low byte
	cmd[3] = EXITPGM;
	sendPickitCmd(d, cmd, 4);
}

void pkErase18F2byte(pickit_dev *d)
{
	printf("Erasing device...\n");
	cmd[0] = ENTERPGMVDD1ST;
	cmd[1] = PIC18FERASE;
	cmd[2] = 0x87;		// bulk erase low byte

	if (((currentDevice->devid & 0x1f00) == 0x1300) || ((currentDevice->devid & 0x1f00) == 0x1400))
		cmd[3] = 0xff;
	else
		cmd[3] = 0x0f;		// bulk erase high byte

	cmd[4] = EXITPGM;
	sendPickitCmd(d, cmd, 5);
}

// Erase the chip.

void pickitErase(pickit_dev *d, int eraseall)
{
	char	errmsg[64];

	if (!DryRun)
	{
		if (!currentDevice)
			fatalError("No device selected");

		sendCmdTable(d, currentDevice->cmdtbl);

		switch (currentDevice->family)
		{
			case BASELINE:
				pkEraseBaseline(d, eraseall, PROG_PGM | PROG_DATA);
				break;

			case MIDRANGE:
				pkEraseMidrange(d, eraseall, PROG_PGM | PROG_DATA);
				break;

			case PIC18F:
				if (eraseall)
					warning("Eraseall is not necessary with PIC18F");

				switch (currentDevice->eraseMode)
				{
					case 1:
						pkErase18F1byte(d);
						break;

					case 2:
						pkErase18F2byte(d);
						break;

					default:
						sprintf(errmsg, "Invalid PIC18 erase mode: %d", currentDevice->eraseMode);
						fatalError(errmsg);
						break;
				}
				break;

			case PIC18J:
				if (eraseall)
					warning("Eraseall is not necessary with PIC18J");

				cmd[0] = PIC18J_ENTERPROG;
				cmd[1] = PIC18J_ERASE;
				cmd[2] = PIC18J_EXITPROG;
				sendPickitCmd(d, cmd, 3);
				break;

			default:
				sprintf(errmsg, "Invalid PIC family: %d", currentDevice->family);
				fatalError(errmsg);
				break;
		}
	}
}

// Print the whole configuration set (osccal, id, and config word).

void pickitPrintConfig(pickit_dev *d)
{
	int i, size = 0;

	if (!currentDevice)
	{
		printf("Warning: No device selected\n");
		return;
	}

	pickitReadConfig(d);

	if (currentDevice->saveOscCal)
	{
		if (currentDevice->family == BASELINE)
		{
			printf("\nOscCal = 0x%04x, backup = 0x%04x\n",
				currentDevice->osccal, currentDevice->bosccal);
		}
		else
			printf("\nOscCal = 0x%04x\n", currentDevice->osccal);
	}

	if (currentDevice->IDlen)
	{
		printf("\nUser ID:");

		for (i=0; i<currentDevice->IDlen; i++)
			printf(" 0x%04x", currentDevice->ID[i]);
	}

	switch (currentDevice->family)
	{
		case BASELINE:
			size = 1;
			break;

		case MIDRANGE:
			size = 2;
			break;

		case PIC18F:
			size = 7;
			break;

		case PIC18J:
			size = 4;
			break;
	}

	printf("\n\nConfiguration data:");

	for (i=0; i<size; i++)
		printf(" 0x%04x", currentDevice->config[i]);

	printf("\n\n");
}

// end

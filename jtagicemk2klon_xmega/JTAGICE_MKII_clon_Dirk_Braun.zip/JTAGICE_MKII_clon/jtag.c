#include <avr/io.h>
#include <avr/pgmspace.h>

#include "global.h"
#include "jtag.h"

#define TCK_0()	(JTAG_PORT &= ~_BV(JTAG_TCK))
#define TCK_1()	(JTAG_PORT |= _BV(JTAG_TCK))

#define TMS_0()	(JTAG_PORT &= ~_BV(JTAG_TMS))
#define TMS_1()	(JTAG_PORT |= _BV(JTAG_TMS))

#define TDO_0()	(JTAG_PORT &= ~_BV(JTAG_TDO))
#define TDO_1()	(JTAG_PORT |= _BV(JTAG_TDO))

#define NOP()	{ asm volatile("nop\r\n\t"::); }

static prog_uint8_t DATA_RESET[]       = { 0x01 };
static prog_uint8_t DATA_NOTRESET[]    = { 0x00 };
static prog_uint8_t DATA_PROGENABLE[]  = { 0x70, 0xA3 };
static prog_uint8_t DATA_PROGDISABLE[] = { 0x00, 0x00 };

static unsigned char readBuffer[16];
static unsigned char dataBuffer[4];

#define COPY_DATA(dest, src) \
	memcpy_P(dest, src, sizeof(src))

static void clockTCK(int num)
{
	while(num--)
	{
		TCK_1();
	    NOP();
		TCK_0();
		NOP();
	}
}

static void goTestLogicReset(void)
{
	TCK_0();
	TMS_1();
	NOP();

	clockTCK(5);
}

static void goRunTestIdle(void)
{
	goTestLogicReset();

	TMS_0();
	NOP();

	clockTCK(1);
}

static void selectIR(void)
{
	TMS_1();
    NOP();

	clockTCK(2);

	TMS_0();
    NOP();

	clockTCK(2);
}

static void selectDR(void)
{
	TMS_1();
    NOP();

	clockTCK(1);

	TMS_0();
    NOP();

	clockTCK(2);
}

static int accessIR(unsigned char cmd)
{
	int ret = 0;
	int n;

	selectIR();

	for (n=0; n<4; n++)
	{
		if (JTAG_PIN & _BV(JTAG_TDI))
		{
			ret |= (1 << n);
		}

		if (cmd & 0x01)
		{
			TDO_1();
		}
		else
		{
			TDO_0();
		}

		if (n == 3)
		{
			TMS_1();
		}
	    NOP();

		clockTCK(1);

		cmd >>= 1;
	}

	clockTCK(1);

	TMS_0();
    NOP();

	clockTCK(1);

	return ret;
}

static void accessDR(unsigned char *pCommand,
                    unsigned char *pResult,
					unsigned short bits)
{
	unsigned char cmd;
	unsigned char ret;
	int n;


	selectDR();

	while(bits)
	{
		cmd = *pCommand++;
		ret = 0;

		for (n=0; ((n<8) && (bits)); n++, bits--)
		{
			if (JTAG_PIN & _BV(JTAG_TDI))
			{
				ret |= (1 << n);
			}

			if (cmd & 0x01)
			{
				TDO_1();
			}
			else
			{
				TDO_0();
			}

			if (bits == 1)
			{
				TMS_1();
			}
		    NOP();

			clockTCK(1);

			cmd >>= 1;
		}
		
		if (pResult)
		{
			*pResult++ = ret;
		}
	}

	clockTCK(1);

	TMS_0();
    NOP();

	clockTCK(1);
}

static unsigned char accessDR_ReadByte(void)
{
	unsigned char ret;
	int n;

	selectDR();

	ret = 0;

	for (n=0; n<8; n++)
	{
		ret >>= 1;

		if (JTAG_PIN & _BV(JTAG_TDI))
		{
			ret |= 0x80;
		}

		if (n == 7)
		{
			TMS_1();
		}
	    NOP();

		clockTCK(1);

	}

	clockTCK(1);

	TMS_0();
    NOP();

	clockTCK(1);

	return ret;
}

static void accessDR_writeByte(unsigned char dat)
{
	int n;

	selectDR();

	for (n=0; n<8; n++)
	{
		if (dat & 0x01)
		{
			TDO_1();
		}
		else
		{
			TDO_0();
		}

		if (n == 7)
		{
			TMS_1();
		}
	    NOP();

		clockTCK(1);

		dat >>= 1;
	}


	clockTCK(1);

	TMS_0();
    NOP();

	clockTCK(1);
}

unsigned short accessProgCommand(unsigned short cmd)
{
	unsigned short ret;

	int n;

	selectDR();

	ret = 0;

	for (n=0; n<15; n++)
	{
		if (JTAG_PIN & _BV(JTAG_TDI))
		{
			ret |= (1 << n);
		}

		if (cmd & 0x01)
		{
			TDO_1();
		}
		else
		{
			TDO_0();
		}

		if (n == 14)
		{
			TMS_1();
		}
	    NOP();

		clockTCK(1);

		cmd >>= 1;
	}
	
	clockTCK(1);

	TMS_0();
    NOP();

	clockTCK(1);

	return ret;
}

static void setFlashAddress(void)
{
	unsigned short cmd;

	if (deviceDescriptor.ucAllowFullPageBitstream == 0)
	{
		// Load extended address byte
		cmd = 0x0B00 | ((MemAddress >> 16) & 0xFF);
		accessProgCommand(cmd);
	}

	// Load high address byte
	cmd = 0x0700 | ((MemAddress >> 8) & 0xFF);
	accessProgCommand(cmd);

	// Load low address byte
	cmd = 0x0300 | (MemAddress & 0xFF);
	accessProgCommand(cmd);
}

void vInitJTAG()
{
	// Set outputs
	JTAG_DDR  |= _BV(JTAG_TCK) | _BV(JTAG_TDO) | _BV(JTAG_TMS);
	JTAG_PORT |= _BV(JTAG_TDI); // Enable pullaup

	goTestLogicReset();
}

void vEnterProgMode()
{
	goRunTestIdle();
	accessIR(0x0C);	// AVR_RESET
	COPY_DATA(dataBuffer, DATA_RESET);
	accessDR(dataBuffer,  readBuffer, 1);

	accessIR(0x04);	// PROG_ENABLE
	COPY_DATA(dataBuffer, DATA_PROGENABLE);
	accessDR(dataBuffer,  readBuffer, 16);
}

void vLeaveProgMode()
{
	accessIR(0x04);	// PROG_ENABLE
	COPY_DATA(dataBuffer, DATA_PROGDISABLE);
	accessDR(dataBuffer,  readBuffer, 16);

	accessIR(0x0C);	// AVR_RESET
	COPY_DATA(dataBuffer, DATA_NOTRESET);
	accessDR(dataBuffer,  readBuffer, 1);

	goTestLogicReset();
}

void vReadSignature(unsigned char *pDest)
{
	accessIR(0x05);	// PROG_COMMANDS
	
	accessProgCommand(0x2308);
	accessProgCommand(0x0300);
	accessProgCommand(0x3200);
	*pDest++ = accessProgCommand(0x3300) & 0xFF;

	accessProgCommand(0x2308);
	accessProgCommand(0x0301);
	accessProgCommand(0x3200);
	*pDest++ = accessProgCommand(0x3300) & 0xFF;

	accessProgCommand(0x2308);
	accessProgCommand(0x0302);
	accessProgCommand(0x3200);
	*pDest++ = accessProgCommand(0x3300) & 0xFF;
}

void vReadFusesAndLockBits(unsigned char *pDest)
{
	accessIR(0x05);	// PROG_COMMANDS
	
	accessProgCommand(0x2304);
	accessProgCommand(0x3A00);
	*pDest++ = accessProgCommand(0x3E00) & 0xFF;  // fuse ext byte
	*pDest++ = accessProgCommand(0x3200) & 0xFF;  // fuse high byte
	*pDest++ = accessProgCommand(0x3600) & 0xFF;  // fuse low byte
	*pDest++ = accessProgCommand(0x3700) & 0xFF;  // lock bits
}

unsigned char ucReadCalibrationByte(void)
{
	accessIR(0x05);	// PROG_COMMANDS
	
	accessProgCommand(0x2308);
	accessProgCommand(0x0300);
	accessProgCommand(0x3600);
	return (accessProgCommand(0x3700) & 0xFF);  // return calibration byte
}

void vReadIdcode(unsigned char *pDest)
{
	goRunTestIdle();

	dataBuffer[0] = 0;	
	dataBuffer[1] = 0;	
	dataBuffer[2] = 0;	
	dataBuffer[3] = 0;	
	accessDR(dataBuffer, pDest, 32);
}

void vChipErase()
{
	accessIR(0x05);	// PROG_COMMANDS
	accessProgCommand(0x2380);
	accessProgCommand(0x3180);
	accessProgCommand(0x3380);
	accessProgCommand(0x3380);
	
	while (0 == (accessProgCommand(0x3380) & 0x0200)) NOP();
}

void vReadSPM(unsigned char *pDest)
{
	accessIR(0x05);	// PROG_COMMANDS
	
	accessProgCommand(0x2302);

	setFlashAddress();

	accessProgCommand(0x3200);
	*pDest++ = accessProgCommand(0x3600) & 0xFF;  // Low byte
	*pDest++ = accessProgCommand(0x3700) & 0xFF;  // high byte
}

void vWriteSPM(unsigned char *pSrc)
{
}

void vReadFlashPage(unsigned char *pDest)
{
	accessIR(0x05);	// PROG_COMMANDS

	accessProgCommand(0x2302);

	MemAddress >>= 1;
	setFlashAddress();
	
	accessIR(0x07);	// PROG_PAGEREAD

	if (deviceDescriptor.ucAllowFullPageBitstream != 0)
	{
		unsigned short bits = ((unsigned short)MemCount + 1) << 3;
		unsigned char saved = *(pDest-1);

		accessDR(0, pDest - 1, bits);

		*(pDest-1) = saved;
	}
	else
	{
		while(MemCount)
		{
			*pDest++ = accessDR_ReadByte();
			MemCount--;
		}
	}
}

void vWriteFlashPage(unsigned char *pSrc)
{
	accessIR(0x05);	// PROG_COMMANDS
	
	accessProgCommand(0x2310);

	MemAddress >>= 1;
	setFlashAddress();

	accessIR(0x06);	// PROG_PAGELOAD

	if (deviceDescriptor.ucAllowFullPageBitstream != 0)
	{
		unsigned short bits = (unsigned short)MemCount << 3;
		accessDR(pSrc, 0, bits);
	}
	else
	{
		while(MemCount)
		{
			accessDR_writeByte(*pSrc++);
			MemCount--;
		}
		clockTCK(11);
	}

	accessIR(0x05);	// PROG_COMMANDS

	accessProgCommand(0x3700);
	accessProgCommand(0x3500);
	accessProgCommand(0x3700);
	accessProgCommand(0x3700);

	while (0 == (accessProgCommand(0x3700) & 0x0200)) NOP();
}

void vReadEEPROM(unsigned char *pDest)
{
}

void vWriteEEPROM(unsigned char *pSrc)
{
}

void vReadEEPROMPage(unsigned char *pDest)
{
}

void vWriteEEPROMPage(unsigned char *pSrc)
{
}

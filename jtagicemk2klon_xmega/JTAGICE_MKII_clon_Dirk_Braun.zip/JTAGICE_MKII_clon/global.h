#ifndef __CONFIG_H__
#define __CONFIG_H__

//#define P_SCK   PB5
//#define P_MISO  PB4
//#define P_MOSI  PB3
//#define P_RESET PB2
//#define P_PROG  PB1

#define JTAG_PORT	PORTB
#define JTAG_DDR	DDRB
#define JTAG_PIN	PINB

#define JTAG_TCK	PB7
#define JTAG_TDO	PB5
#define JTAG_TDI	PB6
#define JTAG_TMS	PB3
#define JTAG_RST	PB2

typedef struct
{
	unsigned char  ucReadIO[8];				// LSB = IOloc  0, MSB = IOloc63 
	unsigned char  ucReadIOShadow[8];		// LSB = IOloc  0, MSB = IOloc63 
	unsigned char  ucWriteIO[8];			// LSB = IOloc  0, MSB = IOloc63 
	unsigned char  ucWriteIOShadow[8];		// LSB = IOloc  0, MSB = IOloc63 
	unsigned char  ucReadExtIO[52];			// LSB = IOloc  96, MSB = IOloc511 
	unsigned char  ucReadIOExtShadow[52];	// LSB = IOloc  96, MSB = IOloc511 
	unsigned char  ucWriteExtIO[52];		// LSB = IOloc  96, MSB = IOloc511 
	unsigned char  ucWriteIOExtShadow[52];	// LSB = IOloc  96, MSB = IOloc511 
	unsigned char  ucIDRAddress;			// IDR address 
	unsigned char  ucSPMCRAddress;			// SPMCR Register address and dW BasePC 
	unsigned long  ulBootAddress;			// Device Boot Loader Start Address 
	unsigned char  ucRAMPZAddress;			// RAMPZ Register address in SRAM I/O 
											// space 
	unsigned short uiFlashPageSize;			// Device Flash Page Size,
	 										// Size = 2 exp ucFlashPageSize 
	unsigned char  ucEepromPageSize;		// Device Eeprom Page Size in bytes 
	unsigned short uiUpperExtIOLoc;			// Topmost (last) extended I/O  
											// location, 0 if no external I/O 
	unsigned long  ulFlashSize;				// Device Flash Size 
	unsigned char  ucEepromInst[20];		// Instructions for W/R EEPROM 
	unsigned char  ucFlashInst[3];			// Instructions for W/R FLASH   
	unsigned char  ucSPHaddr;				// Stack pointer high 
	unsigned char  ucSPLaddr;				// Stack pointer low 
	unsigned short uiFlashpages;			// number of pages in flash 
	unsigned char  ucDWDRAddress;			// DWDR register address 
	unsigned char  ucDWBasePC;				// Base/mask value of the PC 
	unsigned char  ucAllowFullPageBitstream;// FALSE on ALL new  
											// parts 
	unsigned short uiStartSmallestBootLoaderSection; //  
	unsigned char  EnablePageProgramming;	// For JTAG parts only,  
											// default TRUE 
	unsigned char  ucCacheType;				// CacheType_Normal 0x00,  
											// CacheType_CAN 0x01,   
											// CacheType_HEIMDALL 0x02 
	unsigned short uiSramStartAddr; 		// Start of SRAM 
	unsigned char  ucResetType;				// Selects reset type. ResetNormal = 0x00 
											// ResetAT76CXXX = 0x01 
	unsigned char  ucPCMaskExtended;		// For parts with extended PC  
	unsigned char  ucPCMaskHigh;			// PC high mask 
	unsigned char  ucEindAddress;			// Selects reset type. 
	unsigned short EECRAddress;				// EECR IO address 
} TDEVICE_DESCRIPTOR;

extern unsigned char uartBuffer[320];
extern TDEVICE_DESCRIPTOR deviceDescriptor;

extern void usart_putchar(unsigned char c);
extern unsigned char usart_getchar(void);

extern unsigned char MemType;
extern unsigned long MemAddress;
extern unsigned long MemCount;

#endif

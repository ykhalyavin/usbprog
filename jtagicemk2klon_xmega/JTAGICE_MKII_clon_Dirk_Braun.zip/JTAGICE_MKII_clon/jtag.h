#ifndef __JTAG_H__
#define __JTAG_H__

extern void vInitJTAG();
extern void vEnterProgMode();
extern void vLeaveProgMode();

extern void vReadIdcode(unsigned char *pDest);
extern void vReadSignature(unsigned char *pDest);
extern void vReadFusesAndLockBits(unsigned char *pDest);
extern unsigned char ucReadCalibrationByte(void);

extern void vChipErase();

extern void vReadSPM(unsigned char *pDest);
extern void vWriteSPM(unsigned char *pSrc);
extern void vReadFlashPage(unsigned char *pDest);
extern void vWriteFlashPage(unsigned char *pSrc);

extern void vReadEEPROM(unsigned char *pDest);
extern void vWriteEEPROM(unsigned char *pSrc);
extern void vReadEEPROMPage(unsigned char *pDest);
extern void vWriteEEPROMPage(unsigned char *pSrc);

#endif

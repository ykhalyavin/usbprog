#ifndef __CRC16_H__
#define __CRC16_H__

extern unsigned short calculateCRC16(unsigned char *pData, unsigned short size);

#endif

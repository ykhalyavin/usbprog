#include <avr/io.h>
#include <string.h>

#include "global.h"
#include "crc16.h"
#include "jtag.h"


unsigned char uartBuffer[320];

static unsigned char uartState = 0;

#define RX_START			0
#define RX_GET_SEQ_0		1
#define RX_GET_SEQ_1		2
#define RX_GET_MSG_SIZE_0	3
#define RX_GET_MSG_SIZE_1	4
#define RX_GET_MSG_SIZE_2	5
#define RX_GET_MSG_SIZE_3	6
#define RX_GET_TOKEN		7
#define RX_GET_DATA			8
#define RX_GET_CRC_0		9
#define RX_GET_CRC_1		10

static void processMessage(void);

static unsigned short msgBodySize;
static unsigned short usTemp;


unsigned char MemType;
unsigned long MemAddress;
unsigned long MemCount;

TDEVICE_DESCRIPTOR deviceDescriptor;

static unsigned char rxChar;
static unsigned short rxCount;


void usart_putchar(unsigned char c)
{
	loop_until_bit_is_set(UCSRA, UDRE);
	UDR = c;
	/* Clear Transmit Complete Flag */
	UCSRA = _BV(TXC);
}

unsigned char usart_getchar(void)
{
	/* Wait for data to be received */
	loop_until_bit_is_set(UCSRA, RXC);
	/* Get and return received data from buffer */
	return (unsigned char) UDR;
}

int main(void)
{
	/* Initialize USART */
	UBRRH = 0;
	UBRRL = 35; /*  19200 Baud @ fcpu = 11059200 Hz */
//	UBRRL = 5;  /* 115200 Baud @ fcpu = 11059200 Hz */
	UCSRB = (1<<RXEN) | (1<<TXEN);    /* enable receiver and transmitter */
	UCSRC = (1<<URSEL) | (3<<UCSZ0);  /* params: 8n1 */

	vInitJTAG();

	rxCount = 0;

	while(1)
	{
		rxChar = usart_getchar();
		uartBuffer[rxCount++] = rxChar;

		switch(uartState)
		{
			case RX_START:
				if (rxChar == 0x1b)
				{
					uartState++;
				}
				else
				{
					uartState = RX_START;
					rxCount = 0;
				}
				break;

			case RX_GET_SEQ_0:
				uartState++;
				break;

			case RX_GET_SEQ_1:
				uartState++;
				break;

			case RX_GET_MSG_SIZE_0:
				msgBodySize = rxChar;
				uartState++;
				break;

			case RX_GET_MSG_SIZE_1:
				msgBodySize += rxChar << 8;
				uartState++;
				break;

			case RX_GET_MSG_SIZE_2:
				if (rxChar)
				{
					uartState = RX_START;
					rxCount = 0;
				}
				else
				{
					uartState++;
				}
				break;

			case RX_GET_MSG_SIZE_3:
				if (rxChar)
				{
					uartState = RX_START;
					rxCount = 0;
				}
				else
				{
					uartState++;
				}
				break;

			case RX_GET_TOKEN:
				if (rxChar != 0x0E)
				{
					uartState = RX_START;
					rxCount = 0;
				}
				else
				{
					uartState++;
					usTemp = 0;
				}
				break;

			case RX_GET_DATA:
				usTemp++;
				if (usTemp >= msgBodySize)
				{
					uartState++;
				}
				break;

			case RX_GET_CRC_0:
				usTemp = rxChar;
				uartState++;
				break;

			case RX_GET_CRC_1:
				usTemp += rxChar << 8;
				if (usTemp == calculateCRC16(uartBuffer, rxCount-2))
				{
					processMessage();
				}
				uartState = RX_START;
				rxCount = 0;
				break;

			default:
				uartState = RX_START;
				rxCount = 0;
				break;
		}
	}

	return 0;
}

static void processMessage(void)
{
	unsigned short outBodySize = 0;
	unsigned short newUBRR = 0;


	switch(uartBuffer[8])
	{
		case 0x00:  // CMND_GET_SIGN_OFF
			/* set default baudrate */
			newUBRR = 35;

			outBodySize = 0x01;
			uartBuffer[8] = 0x80;
			break;

		case 0x01:  // CMND_GET_SIGN_ON
			outBodySize = 29;
			uartBuffer[ 8] = 0x86;
			uartBuffer[ 9] = 0x01;
			uartBuffer[10] = 0xFF;
			uartBuffer[11] = 0x07;
			uartBuffer[12] = 0x04;
			uartBuffer[13] = 0x00;
			uartBuffer[14] = 0xFF;
			uartBuffer[15] = 0x14;
			uartBuffer[16] = 0x04;
			uartBuffer[17] = 0x00;
			uartBuffer[18] = 0x00;
			uartBuffer[19] = 0xA0;
			uartBuffer[20] = 0x00;
			uartBuffer[21] = 0x00;
			uartBuffer[22] = 0x0D;
			uartBuffer[23] = 0x3F;
			uartBuffer[24] = 'J';
			uartBuffer[25] = 'T';
			uartBuffer[26] = 'A';
			uartBuffer[27] = 'G';
			uartBuffer[28] = 'I';
			uartBuffer[29] = 'C';
			uartBuffer[30] = 'E';
			uartBuffer[31] = ' ';
			uartBuffer[32] = 'm';
			uartBuffer[33] = 'k';
			uartBuffer[34] = 'I';
			uartBuffer[35] = 'I';
			uartBuffer[36] = 0;
			break;

		case 0x02:  // CMND_SET_PARAMETER
			outBodySize = 0x01;
			uartBuffer[8] = 0x80;

			switch(uartBuffer[9])
			{
				case 0x05:	// Baudrate
					switch(uartBuffer[10])
					{
						case 1:  // 2400 Baud
							newUBRR = 287;
							break;

						case 2:  // 4800 Baud
							newUBRR = 143;
							break;

						case 3:  // 9600 Baud
							newUBRR = 71;
							break;

						default:
						case 4:  // 19200 Baud
							newUBRR = 35;
							break;

						case 5:  // 38400 Baud
							newUBRR = 17;
							break;

						case 6:  // 57600 Baud
							newUBRR = 11;
							break;

						case 7:  // 115200 Baud
							newUBRR = 5;
							break;

						case 8:  // 14400 Baud
							newUBRR = 47;
							break;
					}
					break;
					
				default:
					break;
			}
			break;

		case 0x03: // CMND_GET_PARAMETER
			switch(uartBuffer[9])
			{
				case 0x06:	// VTarget
					outBodySize = 3;
					uartBuffer[8]  = 0x81;
					uartBuffer[9]  = 0xE4;
					uartBuffer[10] = 0x0C;
					break;

				case 0x0E:	// JTAGID string
					outBodySize = 5;
					uartBuffer[8]  = 0x81;
					vReadIdcode(&uartBuffer[9]);
					break;
			}
			break;

		case 0x04:  // CMND_WRITE_MEMORY
			MemType = uartBuffer[9];
			MemCount   = uartBuffer[10] + 
			             ((unsigned long)uartBuffer[11] << 8) +
						 ((unsigned long)uartBuffer[12] << 16) +
						 ((unsigned long)uartBuffer[13] << 24);
			MemAddress = uartBuffer[14] + 
			             ((unsigned long)uartBuffer[15] << 8) +
						 ((unsigned long)uartBuffer[16] << 16) +
						 ((unsigned long)uartBuffer[17] << 24);

			outBodySize = 0x01;
			uartBuffer[8] = 0x80;

			switch (MemType)
			{
				case 0x22: // EEPROM
					outBodySize = 0x01;
					uartBuffer[8] = 0xA0;
					break;

				case 0xA0: // Single program word
					outBodySize = 0x01;
					uartBuffer[8] = 0xA0;
					break;

				case 0xB0: // Flash page
					vWriteFlashPage(&uartBuffer[18]);
					break;

				case 0xB1: // EEPROM page
					outBodySize = 0x01;
					uartBuffer[8] = 0xA0;
					break;

				case 0xB2: // Fuse bits
					outBodySize = 0x01;
					uartBuffer[8] = 0xA0;
					break;

				case 0xB3: // Lock bits
					outBodySize = 0x01;
					uartBuffer[8] = 0xA0;
					break;

				case 0xB4: // Signature
					outBodySize = 0x01;
					uartBuffer[8] = 0xA0;
					break;

				case 0xB5: // OSCCAL byte
					outBodySize = 0x01;
					uartBuffer[8] = 0xA0;
					break;

				default:
					outBodySize = 0x01;
					uartBuffer[8] = 0xA0;
					break;
			}
			break;

		case 0x05:  // CMND_READ_MEMORY
			MemType = uartBuffer[9];
			MemCount   = uartBuffer[10] + 
			             ((unsigned long)uartBuffer[11] << 8) +
						 ((unsigned long)uartBuffer[12] << 16) +
						 ((unsigned long)uartBuffer[13] << 24);
			MemAddress = uartBuffer[14] + 
			             ((unsigned long)uartBuffer[15] << 8) +
						 ((unsigned long)uartBuffer[16] << 16) +
						 ((unsigned long)uartBuffer[17] << 24);

			switch (MemType)
			{
				case 0x22: // EEPROM
					outBodySize = 0x01;
					uartBuffer[8] = 0xA0;
					break;

				case 0xA0: // Single program word
					outBodySize = 0x01;
					uartBuffer[8] = 0xA0;
					break;

				case 0xB0: // Flash page
					outBodySize = (MemCount & 0xFFFF) + 1;
					uartBuffer[8]  = 0x82;

					vReadFlashPage(&uartBuffer[9]);
					break;

				case 0xB1: // EEPROM page
					outBodySize = 0x01;
					uartBuffer[8] = 0xA0;
					break;

				case 0xB2: // Fuse bits
					outBodySize = 0x04;
					uartBuffer[8]  = 0x82;

					vReadFusesAndLockBits(&uartBuffer[9]);
					break;

				case 0xB3: // Lock bits
					outBodySize = 0x02;
					uartBuffer[8]  = 0x82;

					vReadFusesAndLockBits(&uartBuffer[9]);
					uartBuffer[9] = uartBuffer[12];
					break;

				case 0xB4: // Signature
					outBodySize = 0x04;
					uartBuffer[8]  = 0x82;
					
					vReadSignature(&uartBuffer[9]);
					break;

				case 0xB5: // OSCCAL byte
					outBodySize = 0x02;
					uartBuffer[8]  = 0x82;

					uartBuffer[9] = ucReadCalibrationByte();
					break;

				default:
					outBodySize = 0x01;
					uartBuffer[8] = 0xA0;
					break;
			}
			break;

		case 0x0C:  // CMND_SET_DEVICE_DESCRIPTOR
			memcpy(&deviceDescriptor, &uartBuffer[9], sizeof(deviceDescriptor));
			outBodySize = 0x01;
			uartBuffer[8] = 0x80;
			break;

		case 0x13:  // CMND_CHIP_ERASE
			vChipErase();

			outBodySize = 0x01;
			uartBuffer[8] = 0x80;
			break;

		case 0x14:  // CMND_ENTER_PROGMODE
			outBodySize = 0x01;
			uartBuffer[8] = 0x80;

			vEnterProgMode();
			break;

		case 0x15:  // CMND_LEAVE_PROGMODE
			outBodySize = 0x01;
			uartBuffer[8] = 0x80;

			vLeaveProgMode();
			break;

		case 0x2f:
			outBodySize = 0x01;
			uartBuffer[8] = 0xA0;
			break;

		default:
			outBodySize = 0x01;
			uartBuffer[8] = 0xA0;
			break;
	}

	if (outBodySize)
	{
		unsigned short count = outBodySize + 10;
		unsigned char *pBuffer = uartBuffer;

		uartBuffer[3] = outBodySize & 0xFF;
		uartBuffer[4] = outBodySize >> 8;
		uartBuffer[5] = 0;
		uartBuffer[6] = 0;

		outBodySize = calculateCRC16(uartBuffer, count-2);
		uartBuffer[count-2] = outBodySize & 0xFF;
		uartBuffer[count-1] = outBodySize >> 8;

		while(count)
		{
			usart_putchar(*pBuffer++);
			count--;
		}
	}

	if (newUBRR)
	{
		/* Wait until transmit complete */
		loop_until_bit_is_set(UCSRA, TXC);

		/* disable receiver and transmitter */
		UCSRB = 0;

		/* Set new baudrate */
		UBRRH = newUBRR >> 8;
		UBRRL = newUBRR & 0xFF;
		
		/* enable receiver and transmitter */
		UCSRB = (1<<RXEN) | (1<<TXEN);
	}
}

static void waitms(unsigned char n)
{
	while (n > 0)
	{
	  unsigned short tmp;
	  
	  for(tmp = 0; tmp < 380; tmp++)
	  {
	    asm volatile("nop\r\n\t"::);
        asm volatile("nop\r\n\t"::);
	    asm volatile("nop\r\n\t"::);
        asm volatile("nop\r\n\t"::);
	    asm volatile("nop\r\n\t"::);
        asm volatile("nop\r\n\t"::);
	    asm volatile("nop\r\n\t"::);
        asm volatile("nop\r\n\t"::);
	    asm volatile("nop\r\n\t"::);
        asm volatile("nop\r\n\t"::);
	  }
		
	  n--;
	}
};

static void waitus(unsigned char n)
{
	while (n > 0)
	{
		asm volatile("nop\r\n\t"::);
		asm volatile("nop\r\n\t"::);
		
		n--;
	}
};


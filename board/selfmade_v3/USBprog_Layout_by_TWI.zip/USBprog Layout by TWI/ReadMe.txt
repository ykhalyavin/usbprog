...noch ein Layout...


Moin!

Anbei ein weiteres Layout zum selber �tzen. Dabei wurde der Schaltplan 
des originalen USBprog (Version 3.1) 1:1 �bernommen und lediglich 
wenige Bauteilgr��en aus Routinggr�nden ge�ndert. Das Layout ist 
komplett einseitig mit nur f�nf L�tbr�cken. Drei der L�tbr�cken k�nnen 
theoretisch durch 0Ohm-Widerst�nde mit 1206er Baugr��e ersetzt werden.
Hierauf habe ich allerdings verzichtet, da es sich bei den Br�cken um 
die Versorgungsspannung handelt.
Die Abmessung der Platine ist mit 80mm x 37mm handlich geblieben.

Die abge�nderten Bauteilgr��en sind:
Name        Wert     �nderung
-----------+--------+-------------------------------
J1          -        Mini-USB-B statt Standard-USB-B
LED1,LED2   rt, gn   3mm-DIL statt 0603SMD
R8-15       100      1206 statt 0603
R7          10k      1206 statt 0603

Viel Spass beim Nachbauen!

MfG,
Thomas
<etechnik@gmx.info>


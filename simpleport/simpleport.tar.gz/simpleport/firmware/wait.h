#define F_CPU 16000000
#include <util/delay.h>

void wait_ms(int ms);

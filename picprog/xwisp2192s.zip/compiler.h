
// -------------------------------------------------------------
// General purpose C-compiler handling
//
// Author:  R. Hamerling
// (c) Copyright 2002,2006, R.Hamerling. All rights reserved.
//
// -------------------------------------------------------------
// Purpose:  handle compiler-specific
//           and (related) platform specific
//           differences and peculiarities
//           and obtain some generic information (name, version)
//
// Compiler dependent constant definitions:
// - name
// - version
// - minor-version
// -------------------------------------------------------------

#if defined(__WATCOMC__)
  #if __WATCOMC__ < 1200
    #define compiler_name     "Watcom C"
    #define compiler_version  (__WATCOMC__ / 100)
    #define compiler_minor    (__WATCOMC__ % 100)
  #else
    #define compiler_name     "Open Watcom C"
    #define compiler_version  ((__WATCOMC__ - 1100) / 100)
    #define compiler_minor    ((__WATCOMC__ - 1100) % 100)
  #endif
  #if defined(__NT__)
    #define __W32__
  #elif defined(__UNIX__)
    #define __LINUX__
  #endif

#elif defined(__IBMC__)
  #if __IBMC__ < 300
    #define compiler_name     "IBM C/C++"
  #else
    #define compiler_name     "IBM VAC"
  #endif
  #define compiler_version  (__IBMC__ / 100)
  #define compiler_minor    (__IBMC__ % 100)

#elif defined(__GNUC__) && defined(__OS2__)             // GCC + EMX (OS/2)
  #define compiler_name     "GCC"
  #define compiler_version  (__GNUC__)
  #define compiler_minor    (__GNUC_MINOR__)
  #define max(x,y) (((x) > (y)) ? (x) : (y))            // missing ..
  #define min(x,y) (((x) < (y)) ? (x) : (y))            // .. functions

#elif defined(__gnu_linux__) || defined(__linux) || \
      defined(__APPLE__) || defined(__FreeBSD__)
  #define compiler_name     "GCC"
  #if defined(__GNUC__)
    #define compiler_version  (__GNUC__)
  #elif defined(__VERSION__)
    #define compiler_version  (__VERSION__[0] - '0')    // first char -> num
  #else
    #define compiler_version  (0)                       // unknown
  #endif
  #if defined(__GNUC_MINOR__)
    #define compiler_minor    (__GNUC_MINOR__)
  #elif defined(__VERSION__)
    #define compiler_minor    (__VERSION__[2] - '0')    // third char -> num
  #else
    #define compiler_minor    (0)                       // unknown
  #endif
  #define max(x,y) (((x) > (y)) ? (x) : (y))            // missing ..
  #define min(x,y) (((x) < (y)) ? (x) : (y))            // .. functions ..
  #define strnicmp strncasecmp                          // alias
  #define stricmp  strcasecmp                           // alias
  #if defined(__FreeBSD__)
    #define __FREEBSD__                                 // alias
  #endif
  #define __LINUX__                                     // generic

#elif defined(__GNUC__) && defined(__WIN32__)           // GCC (W32/MinGW)
  #define compiler_name     "GCC"
  #define compiler_version  (__GNUC__)
  #define compiler_minor    (__GNUC_MINOR__)
  #define max(x,y) (((x) > (y)) ? (x) : (y))            // missing ..
  #define min(x,y) (((x) < (y)) ? (x) : (y))            // .. functions
  #define strnicmp strncasecmp                          // alias
  #define stricmp  strcasecmp                           // alias
  #define __W32__                                       // W95 and up

#elif defined(__LCC__)
  #define compiler_name     "LCC"
  #define compiler_version  (4)                         // no version?
  #define compiler_minor    (0)                         // no subversion?
  #define __W32__                                       // W95 and up

#elif defined(__DMC__)                                  // Digital Marc C
  #define compiler_name     "DigitalMars C"
  #define compiler_version  (8)
  #define compiler_minor    (45)
  #define max(x,y) ((x > y) ? (x) : (y))                // missing ..
  #define min(x,y) ((x < y) ? (x) : (y))                // .. functions
  #define __W32__

#elif defined(__BORLANDC__)                             // BCC
  #define compiler_name     "Borland C"
  #define compiler_version  (5)
  #define compiler_minor    (5)
  #define __W32__                                       // W95 and up

#elif defined(_MSC_VER)
  #define compiler_name     "MS-C"
  #define compiler_version  (_MSC_VER / 100)
  #define compiler_minor    (_MSC_VER % 100)
  #define __DOS__                                       // 16-bits DOS

#elif defined(__DJGPP__)
  #define compiler_name     "DJGPP"
  #define compiler_version  (__DJGPP__)
  #define compiler_minor    (__DJGPP_MINOR__)
  #include <dir.h>
  #include <errno.h>                                    // not in <stdlib.h>
  #define __DOS__                                       // DOS

#else                                                   // default
  #define compiler_name     "Unidentified compiler"
  #define compiler_version  (0)
  #define compiler_minor    (0)

#endif


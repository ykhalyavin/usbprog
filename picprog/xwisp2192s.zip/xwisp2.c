
// ===================================================================
//
// XWisp2.c  - In-Circuit Serial Programming with
//             - WISP628 PIC programmer
//             - WISP
//             - WLoader
//
// Author:  R. Hamerling
// (c) Copyright 2002,2006, R.Hamerling. All rights reserved.
//
// Version: Actual version in XWisp2.h, reported at startup!
//
// ===================================================================
//
// Compilation tested with:
// - Open Watcom C compiler version 1.4 for eComStation, Linux and Windows
//   executables
// - GNU C Compiler (GCC) and EMX package for eComStation executables
// - GNU C Compiler (GCC) under Linux for Linux executables
// For each of these: see the corresponding make file.
// Succesfull reports received from others for:
// - GNU C Compiler (GCC) under MacOS
// - GNU C Compiler (GCC) under FreeBSD
//
// Was also compilable, but not tested anymore with:
// - IBM C/C++ 2.0 for OS/2 Warp + OS/2 Warp toolkit 4.5 under OS/2
// - LCC compiler (3.8) under W32
// - Borland BCC 5.5 compiler under W32
//
// (c) Copyright 2002,2006, R.Hamerling. All rights reserved.
//
// ===================================================================
//
//   xwisp2 is composed of the following modules:
//
//   xwisp2.c     - The main module
//   xwisp2bus.c  - WBus command formatting
//   xwisp2cfg.c  - PIC properties interpretor and service routines
//   xwisp2cmd.c  - Commandline argument handling
//   xwisp2com.c  - Communication with the PIC programmer
//   xwisp2dat.c  - Global variables
//   xwisp2hex.c  - Hex file handling functions (read and write)
//   xwisp2mis.c  - Miscellaneous functions
//   xwisp2os.c   - Elementary Operating System dependent functions
//   xwisp2tgt.c  - Target handling functions (the actual PIC programming)
//
// ===================================================================

// #define __DEBUG__

#include "xwisp2.h"                             // all includes


// =========================================
//
//  M A I N L I N E   of   X W I S P 2
//
//  - welcome user
//  - process file with PIC properties
//  - adept defaults to environment
//  - handle commandline arguments
//  - shutdown
//
// =========================================
extern int  main(int argc, char **argv) {

  int    rc = 0;                                        // returncode
  ULONG  ulProgramStartTime = OS_Time();                // program start
  char   ucBuffer[8];                                   // user I/O

  szArgv = argv;

  printf(" %s version %d.%d.%d for %s (%s, %s %d.%d)\n",
         szProgName, VMAJOR, VMINOR, VSUFFIX, runtime_platform,
         __DATE__, compiler_name, compiler_version, compiler_minor);

  rc = ReadPICSpecs(argv[0]);                           // read PIC properties
  if (rc) {                                             // problem
    BeepError();
    printf(szPressEnter);
    fflush(stdout);
    fgets(ucBuffer, sizeof(ucBuffer), stdin);           // wait for 'Enter'
    return rc;
    }

  signal(SIGINT,   Abort);                              // controlled abort
  signal(SIGTERM,  Abort);                              //

  EnvironmentHandling();                                // handle 'XWISP2'

  /* ------ the real work ------------- */

  rc = CommandHandling(argc, argv);

  /* ---------------------------------- */

  ProgrammerDeactivate();                               // stop comm.

  LogStop();                                            // (when active)

  ReleasePICSpecs();                                    // free allocated mem

  signal(SIGINT, SIG_DFL);                              // reset to default
  signal(SIGTERM, SIG_DFL);                             //

  ReportResult(szProgName, rc, ulProgramStartTime);     // result + exec time
  if (rc) {                                             // not successful
    printf(szPressEnter);
    fflush(stdout);
    fgets(ucBuffer, sizeof(ucBuffer), stdin);           // wait for 'Enter'
    }

#ifdef __DEBUG__
  printf("Leaving XWisp628 in state %u\n", ulWisp628State);
#endif

  return rc;                                            // result last cmd

  }



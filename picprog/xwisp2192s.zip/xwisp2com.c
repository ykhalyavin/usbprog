
// ============================================================
// XWisp2Com.c - Wisp628 Programmer support library
//
//             - basic communications I/O functions
//
// Author:  R. Hamerling
// (c) Copyright 2002,2006, R.Hamerling. All rights reserved.
//
// Version: Actual version in XWisp2.h, reported at startup!
//
// ============================================================

// #define __DEBUG__

#include "xwisp2.h"                             // all common includes

//  locally used constants

static const ULONG  aulWisp628Speed[5] = {9600, 19200, 38400, 57600, 115200};
static const char  *aszProgrammer[]    = {"WISP", "WLdr", "Wisp628"};

//  locally used common variables

static  HSERIALPORT  hSerialPort  = INVALIDSERIALHANDLE;   // port not open
static  ULONG        ulBpsOrg = 0;                         // speed at open

//  local function prototypes

static  int     CheckInputData(char *, char *);
static  int     CheckOutputData(char *);
static  void    PortClose(void);
static  BOOLEAN PortSetup(char *);
static  int     SendBreak(void);
static  int     SendReceiveFast(char *, char *);
static  int     SetBps(ULONG);
static  int     SetMode(void);
static  int     SetReadTimeout(ULONG);


// ------------------------------------------------------
//
// Check received data for valid characters
//
// remarks: - strips hit bit and check for command error
//
// ------------------------------------------------------
static  int    CheckInputData(char *szOutput,          // sent data
                              char * szInput) {        // received data

  int  i;                                               // counter

  for (i=0; i<strlen(szInput); i++) {                   // scan response
    szInput[i] &= ~0x80;                                // strip high bit
    if (szOutput[i] >= 'g' && szOutput[i] <= 'z' &&     // command byte
        szInput[i] == '?') {                            // command failure
      printf("Wbus command failure\n");
      return  XW_IOERROR;                               // programmer problem
      }
    }
  return 0;
  }


// ---------------------------------------------------
//
// Check outgoing data for valid characters
//
// ---------------------------------------------------
static  int    CheckOutputData(char *szOutput) {

  int    i;

  for (i=0; i<strlen(szOutput); i++) {
    if ( !( (szOutput[i] >= '0'  &&  szOutput[i] <= '9') ||
            (szOutput[i] >= 'a'  &&  szOutput[i] <= 'z') ) ) {
      printf("String '%s' contains invalid characters\n", szOutput);
      return  XW_IOERROR;                               // invalid data
      }
    }
  return XW_NOERROR;                                    // OK
  }


// ---------------------------------------------------
//
// Close COM port
//
// Remarks - state of programmer not changed
//
// ---------------------------------------------------
static void  PortClose(void) {

  if (hSerialPort != INVALIDSERIALHANDLE) {             // currently open
    if (ulBpsOrg != 0   &&                              // got original
      ulWisp628State != WISP628PASSTHROUGH)             // not in passthrough
      SetBps(ulBpsOrg);                                 // restore original
    SetModemOutputStatus(FALSE,FALSE);                  // DTR and RTS off
    OS_SerialClose(hSerialPort);                        // terminate comm.
    hSerialPort = INVALIDSERIALHANDLE;                  // reset handle
    }
  return;
  }


// ---------------------------------------------------
//
// Open and initialise port
//
// Input   - Name of device to open
//
// Output  - nothing
//           (handle of open port stored in local variable)
//
// Returns TRUE when port opened successfully, otherwise FALSE.
//
// Remarks: - if port is open it will be closed first
//          - DTR and RTS will be set false
//
// ---------------------------------------------------
static  BOOLEAN  PortSetup(char *szDeviceName) {

  int  rc;                                              // reeturncode

  if (hSerialPort != INVALIDSERIALHANDLE)               // currently open
    PortClose();                                        // close it

  hSerialPort = OS_SerialOpen(szDeviceName);            // open device
  if (hSerialPort == INVALIDSERIALHANDLE) {             // failure
    printf("Failure opening serial port '%s', errno = %d\n",
            szDeviceName, errno);
    return FALSE;
    }

  if (bVerbose)
    printf("Initializing serial port: %s\n", szPortName);

//if (isatty(hSerialPort) == 0) {                       // not a char device
//  printf("'%s' seems not to be a serial port!\n", szDeviceName);
//  return FALSE;
//  }

                                                        // save original bps
  rc = OS_SerialGetBaudrate(hSerialPort, &ulBpsOrg, NULL, NULL);
  if (rc != XW_NOERROR) {
    printf("Error querying baud rate, rc %d, errno %d\n", rc, errno);
    return rc;
    }

  rc = SetBps(ulWbusBaudrateDefault);                   // default for Wbus
  if (rc) {                                             // problem
    printf("Setting initial serial port speed failed, rc %d\n", rc);
    return FALSE;
    }

  rc = SetMode();                                       // set 8,n,1, etc
  if (rc) {                                             // problem
    printf("Error setting serial port mode, rc %d\n", rc);
    return FALSE;
    }

  rc = SetReadTimeout(300);                             // set timeout
  if (rc) {                                             // problem
    printf("Error setting serial port intial read timeout, rc %d\n", rc);
    return FALSE;
    }

  rc = SetDTR(TRUE);                                    // rise DTR for Wloader
  if (rc)                                               // problem
    return FALSE;
  OS_Sleep(200);                                        // period DTR on
  rc = SetDTR(FALSE);                                   // drop DTR
  if (rc)                                               // problem
    return FALSE;

  return TRUE;                                          // OK
  }


// --------------------------------------------------
//
//  ProgrammerActivate - prepare for programming
//
//  Remarks: - only programmer activated
//           - some operational programming variables adapted to
//             properties of programmer type and firmware version
//
// --------------------------------------------------
extern  int    ProgrammerActivate(void) {

  int     rc;
  ULONG   ulPassSpeedCode;
  ULONG   ulVersion;
  ULONG   ulBpsCur, ulBpsMin, ulBpsMax;                 // baudrates

  if (ulWisp628State != WISP628ACTIVE) {                // not already active

    if (hSerialPort == INVALIDSERIALHANDLE) {           // port not open
      if (PortSetup(szPortName) == FALSE)               // open and init port
        return XW_NOENT;                                // open failed
      }
                                                // assume state is 'attention'
    rc = WbusHello();                                   // attention -> active

    if (rc != XW_NOERROR  ||  ulWisp628State != WISP628ACTIVE)  {
                                                        // failed, try break
      if (bVerbose)
        printf("Programmer not active, trying to activate\n");

      rc = SendBreak();                                 // sleep -> attention
      if (rc)
        return rc;                                      // break failed

      if (ulWisp628State != WISP628ATTENTION)  {
        printf("Failed to contact Programmer."
               " Check connection to target and %s.\n",
                szPortName);
        return XW_NOENT;
        }

      rc = WbusHello();                                 // attention -> active
      if (rc != XW_NOERROR  ||  ulWisp628State != WISP628ACTIVE)  {
        printf("Failed to activate Programmer."
               " Check connection to target and %s.\n",
                szPortName);
        return XW_NOENT;
        }

      }

    szWbusDevice = WbusType();                          // programmer type
    if (szWbusDevice != NULL) {                         // name obtained
      if (stricmp(szWbusDevice, aszProgrammer[2])  &&   // expected "Wisp628"
          stricmp(szWbusDevice, aszProgrammer[1])  &&   // or "WLdr"
          stricmp(szWbusDevice, aszProgrammer[0])) {    // or "WISP"
        printf("Unsupported programmer '%s', %s supports only %s, %s and %s\n",
                        szWbusDevice, szProgName,
                        aszProgrammer[2], aszProgrammer[1], aszProgrammer[0]);
        return XW_NOENT;                                // invalid device
        }
      }
    else                                                // no name obtained
      return XW_NOENT;                                  // invalid device

    ulVersion = WbusVersion();                          // Wbus device firmware
    printf("Detected programmer: %s, firmware version %lu.%02lu\n",
                     szWbusDevice,
                     ulVersion / 100, ulVersion % 100);

    if (!stricmp(szWbusDevice, aszProgrammer[2]))       // device is Wisp628
      ulWisp628Level = ulVersion;                       // level dependencies

    if (ulWisp628Level < 109  &&                        // low level firmware
        stricmp(szWbusDevice, aszProgrammer[2]) == 0) { // for Wisp628
      OS_Beep(1000, 50);                                // warning
      printf("Recommendation: Upgrade your Wisp628 firmware"
             " to at least version 1.09\n");
      }

    // adjust Wisp628 firmware version dependent defaults

    if (ulWisp628Level >= 90)
      fBurstWrite |= BURSTWRITE_SUPP;                   // supported!

    if (ulWisp628Level >= 103)                          // Wbusjump for 16F's
      SetReadTimeout(2000);                             // for 'far' jumps
                                                        // (before 1.8.3 = 1000)
                                                        // tested: 16F877A
    if (ulWisp628Level >= 106)                          // interm. speed change
      ulWbusBaudrateActual = aulWisp628Speed[4];        // max speed

    if (ulWbusBaudrateUser != 0)                        // user override
      ulWbusBaudrateActual = ulWbusBaudrateUser;        // use user speed

    rc = OS_SerialGetBaudrate(hSerialPort, &ulBpsCur, &ulBpsMin, &ulBpsMax);
    if (rc != XW_NOERROR) {
      printf("Error querying baud rate, rc %d, errno %d\n", rc, errno);
      return rc;
      }
    if (ulWbusBaudrateActual > ulBpsMax) {              // too high for port
      if (bVerbose)
        printf("WNG: Maximum serial port speed %lu bps\n", ulBpsMax);
      ulWbusBaudrateActual = ulBpsMax;                  // port upper limit
      }

    if (ulWbusBaudrateActual != ulWbusBaudrateDefault) {   // change req'd
      if (ulWisp628Level >= 106) {                      // spd chg supported
        ulPassSpeedCode = SpeedIndex(ulWbusBaudrateActual);
        if (ulPassSpeedCode != MINUS1) {                // OK
          if (bVerbose)
            printf("Switching communications speed from %lu to %lu bps\n",
                            ulWbusBaudrateDefault, ulWbusBaudrateActual);
          WbusPassThrough((ulPassSpeedCode<<4) + 4);    // speed change cmd
          OS_Sleep(20);                                 // delay in XWisp628
          OS_SerialFlush(hSerialPort);                  // flush I/O buffers
          rc = SetBps(aulWisp628Speed[ulPassSpeedCode]);   // to new speed
          if (rc)
            return rc;
          }
        else
          printf("Speed %lu not supported, using %lu\n",
                 ulWbusBaudrateActual, ulWbusBaudrateDefault);
        }
      else                                              // back level
        printf("%s V %lu.%02lu does not support requested speed (%lu),"
               " using %lu\n",
               szWbusDevice,
               ulVersion / 100 , ulVersion % 100,
               ulWbusBaudrateActual,
               ulWbusBaudrateDefault);
      }
    }

  return  XW_NOERROR;                                   // all OK
  }


// -------------------------------------------------------------
//
//  ProgrammerDeactivate - terminate programming
//
//  Remarks - Before closing the COM-port:
//            - When the programmer is in passthrough mode it will
//              remain in that state.
//            - Otherwise it is set back to attention-state and
//              then to sleep-state before closing the port.
//
// -------------------------------------------------------------
extern  void  ProgrammerDeactivate(void) {

  if (hSerialPort != INVALIDSERIALHANDLE) {             // currently open
    if (ulWisp628State != WISP628PASSTHROUGH) {         // NOT in Passthrough
      if (szWbusDevice != NULL) {                       // devicetype known
        if (stricmp(szWbusDevice, aszProgrammer[2]))    // not "Wisp628"
          SendBreak();                                  // back to Attention
        }
      }
    PortClose();                                        // close port
    }
  return;
  }


// ------------------------------------------------------
//
// Send RS232 break signal of Wisp628 required duration
//
// remarks: port must be opened before.
//
// ------------------------------------------------------
static  int  SendBreak(void) {

  int  rc;                                              // returncode

  rc = OS_SerialBreak(hSerialPort, 200);                // 200 ms RS232 break
  if (rc) {
    printf("Failure sending serial 'break' signal, rc=%d\n", rc);
    return rc;
    }
  LogMsg("{break}");

  ulWisp628State = WISP628ATTENTION;                    // Wisp628 state

  rc = SetBps(ulWbusBaudrateDefault);                   // back to default

  return rc;
  }


// ---------------------------------------------------
//
// SendByte  - send a single byte, unchecked
//           - discard the echo
//
// Remarks: only used by WbusPassThrough command
//
// ---------------------------------------------------
extern  int    SendByte(char  ucChar) {

  LONG   slBytesWritten;

  slBytesWritten = OS_SerialWrite(hSerialPort, &ucChar, 1);   // write byte
  if (slBytesWritten == -1) {                           // error
    printf("SendByte write error, errno = %d\n", errno);
    return errno;                                       // write error
    }
  if (slBytesWritten != 1) {                            // nothing written
    printf("SendByte write failed, bytes written: %lu\n", slBytesWritten);
    return XW_IOERROR;
    }
  OS_Sleep(5);                                          // quiesce input
  OS_SerialFlush(hSerialPort);                          // flush input/output

  return XW_NOERROR;
  }


// ---------------------------------------------------
//
// SendReceive - send a string of data
//             - return result code
//
//
// When fBurstWrite supported and not half duplex requested the fast
// write will be used, otherwise slow write (true byte-by-byte Wbus
// protocol) will be used.
//
// ---------------------------------------------------
extern  int    SendReceive(char *szOutput,
                           char *szInput) {

  *szInput = '\0';                                      // nul return string

  if (fBurstWrite == (BURSTWRITE_FDX | BURSTWRITE_SUPP))  // burst writes OK
    return SendReceiveFast(szOutput, szInput);          // burst-write
  else
    return SendReceiveSlow(szOutput, szInput);          // byte-by-byte write

  }


// --------------------------------------------------------------------
//
// SendReceiceFast - send a string of data in one burst
//                   return the echo
//
// --------------------------------------------------------------------
static  int    SendReceiveFast(char *szOutput,
                               char *szInput) {

  int    rc;
  LONG   slBytesReceived, slBytesWritten, slBytesBuffered;
  ULONG  slEchoLength;
  int    i;                                             // counter
  char   ucBuffer[132];                                 // local rcv buffer

  szInput[0] = '\0';                                    // null reply
  rc = CheckOutputData(szOutput);                       // check command data
  if (rc != XW_NOERROR)
    return rc;

  slBytesWritten = OS_SerialWrite(hSerialPort,
                                  szOutput,
                                  strlen(szOutput));
  if (slBytesWritten == -1) {                           // error
    printf("SendReceiveFast write error, errno = %d\n", errno);
    return errno;                                       // write error
    }
  if (slBytesWritten < strlen(szOutput)) {              // partial write
    printf("SendReceiveFast write error, bytes written: %ld of %u\n",
                    slBytesWritten, strlen(szOutput));
    return XW_IOERROR;                                  // problem
    }

  slBytesBuffered = 0;                                  // nothing received yet
  slEchoLength = strlen(szOutput) * ((bDoubleEcho) ? 2 : 1);
  while (slBytesBuffered < slEchoLength  &&  rc == XW_NOERROR) {  // echo ..
    slBytesReceived = OS_SerialRead(hSerialPort,
                                    ucBuffer + slBytesBuffered,
                                    sizeof(ucBuffer) - slBytesBuffered - 1);
    if (slBytesReceived == -1) {                        // error
      printf("SendReceiveFast read error, errno = %d\n", errno);
      rc = errno;                                       // read error
      }
    else if (slBytesReceived == 0) {                    // no more data
      printf("SendReceiveFast read timeout, received %ld of %ld bytes\n",
                      slBytesBuffered, slEchoLength);
      rc = XW_IOERROR;                                  // no problem
      }
    else                                                // data received
      slBytesBuffered += slBytesReceived;
    }
  ucBuffer[slBytesBuffered] = '\0';                     // end of string

  if (rc == XW_NOERROR) {                               // something received
    if (bDoubleEcho) {                                  // all double
      for (i=0; i<strlen(ucBuffer); ++i)                // filter first echo
        ucBuffer[i] = ucBuffer[2*i];
      }
    rc = CheckInputData(szOutput, ucBuffer);            // check response data
    if (rc == XW_NOERROR)                               // OK
      strcpy(szInput, ucBuffer);                        // copy to caller
    }

  return rc;                                            // result
  }


// ---------------------------------------------------
//
// SendReceive - send a string of data byte-by-byte
//             - return the echo
//
// ---------------------------------------------------
extern  int    SendReceiveSlow(char *szOutput,
                               char *szInput) {

  int    rc;                                            // result
  LONG   slBytesWritten, slBytesReceived;
  int    i;                                             // counter(s)
  char   ucBuffer[132];                                 // local rcv buffer

  *szInput = '\0';                                      // null reply
  rc = CheckOutputData(szOutput);                       // check data
  if (rc != XW_NOERROR)
    return rc;

  for (i=0; i<strlen(szOutput) && rc==XW_NOERROR; i++) {
    slBytesWritten = OS_SerialWrite(hSerialPort,
                                    szOutput + i,
                                    1);
    if (slBytesWritten == -1) {                         // error
      printf("SendReceiveSlow write error, errno = %d\n", errno);
      rc = errno;
      break;
      }
    if (slBytesWritten != 1) {                          // error
      printf("SendReceiveSlow write error, bytes written: %ld of 1\n",
                       slBytesWritten);
      rc = XW_IOERROR;
      break;
      }

#ifdef __DEBUG__
    printf("Awaiting reply .... ");
    fflush(stdout);
#endif
    slBytesReceived = OS_SerialRead(hSerialPort,
                                    ucBuffer + i,
                                    sizeof(ucBuffer) - i - 1);
#ifdef __DEBUG__
    printf("received: %d bytes\n", slBytesReceived);
#endif
    if (slBytesReceived == -1) {                        // error
      printf("SendReceiveSlow read error, errno = %d\n", errno);
      rc = errno;                                       // read error
      break;
      }
    else if (slBytesReceived == 0) {                    // no data arrived
      printf("SendReceiveSlow read timeout, 0 bytes received\n");
      rc = XW_IOERROR;                                  // no problem
      }
    else if (!bDoubleEcho  && (slBytesReceived == 1))   // 1 byte expected
      rc = XW_NOERROR;                                  // OK
    else if ( bDoubleEcho  && (slBytesReceived == 2))   // 2 bytes expected
      ucBuffer[i] = ucBuffer[i+1];                      // filter 1st echo
    else {                                              // more than expected
      printf("More bytes received (%ld) than expected!\n", slBytesReceived);
      rc = XW_NOERROR;                                  // no problem
      }
    }
  ucBuffer[i] = '\0';                                   // end of string

  if (rc == XW_NOERROR) {                               // something received
    rc = CheckInputData(szOutput, ucBuffer);            // check input
    if (rc == XW_NOERROR)                               // OK
      strcpy(szInput, ucBuffer);                        // return to caller
    }

  return rc;
  }


// ---------------------------------------------------
//
// Set port speed
//
// Input   - New baudrate
//
// Output  - nothing
//
// Returns - zero if OK
//         - not zero: failure, see generated message
//
// ---------------------------------------------------
static  int    SetBps(ULONG ulBpsNew) {

  static  ULONG  ulPortSpeed[] = {1200, 2400, 4800, 9600, 16457, 19200,
                                        28800, 38400, 57600, 115200};

  ULONG   i;
  int     rc;
  ULONG   ulBpsCur, ulBpsMin, ulBpsMax;                 // baudrates

  for (i=0; i<sizeof(ulPortSpeed)/sizeof(ulPortSpeed[0]); i++) {
    if (ulBpsNew == ulPortSpeed[i])
      break;
    }

  if (i >= sizeof(ulPortSpeed)/sizeof(ulPortSpeed[0])) {
   printf("Speed %lu not supported\n", ulBpsNew);
   return XW_INVAL;
   }

  rc = OS_SerialGetBaudrate(hSerialPort, &ulBpsCur, &ulBpsMin, &ulBpsMax);
  if (rc != XW_NOERROR) {
    printf("Error querying baud rate, rc %d, errno %d\n", rc, errno);
    return rc;
    }

  if (bVerbose)
    printf("Portspeed min: %lu, max: %lu, cur: %lu\n",
            ulBpsMin, ulBpsMax, ulBpsCur);

  if (ulBpsNew > ulBpsMax) {
    printf("Requested speed (%lu) exceeds maximum for port, using %lu bps\n",
           ulBpsNew, ulBpsMax);
    ulBpsNew = ulBpsMax;                                // replace by max
    }

  if (ulBpsNew != ulBpsCur) {                           // change needed
    rc = OS_SerialSetBaudrate(hSerialPort, ulBpsNew);
    if (rc) {
      printf("SetBaudrate() error, rc %d\n", rc);
      return rc;
      }

#ifdef __DEBUG__
    OS_SerialGetBaudrate(hSerialPort, &ulBpsCur, NULL, NULL);
    if (ulBpsCur != ulBpsNew)
      printf("Failed to set baudrate to %lu, actual baudrate %lu\n",
              ulBpsNew, ulBpsCur);
#endif

    if (bVerbose)
      printf("Portspeed new: %lu\n", ulBpsNew);

    }

  return rc;
  }


// ---------------------------------------------------
//
//  SetMode():
//
//  Input   - nothing, communications parameters fixed
//
//  Output  - nothing
//
//  Returns - result of OS_SerialSetMode()
//
//  Remarks: - See function OS_SetMode() in Xwisp2OS.c for details
//
// ---------------------------------------------------
static  int   SetMode(void) {

  int   rc;                                             // return code

  rc = OS_SerialSetMode(hSerialPort);                   // set characteristics
  if (rc != 0)
    printf("Error setting communications mode"
           " (Data-, Parity-, Stop-bits), rc %d\n",
            rc);
  return  rc;
  }


// ---------------------------------------------------
//
//  SetReadTimeout():
//
//  Input   - desired read timeout value in milliseconds
//
//  Output  - nothing
//
//  Returns - result of OS_SerialSetReadTimeout()
//
//  Remarks: - See function OS_SetReadTimeout() in Xwisp2OS.c for details
//
// ---------------------------------------------------
static  int   SetReadTimeout(ULONG  ulReadTimeout) {

  int   rc;                                             // return code

  rc = OS_SerialSetReadTimeout(hSerialPort, ulReadTimeout);
  if (rc != 0)
    printf("Error setting read timeout value, rc %d\n",
            rc);
  return  rc;
  }


// ---------------------------------------------------
//
// Set modem output status - set new DTR and RTS setting
//
// input: bitpattern for 'ON' signal(s):  bit 0 for DTR, bit 1 for RTS
//
// output: result of IOCTL set modem output status.
//
// remarks: - assumes the COMport is open!
//          - when a bit in the bitpattern is not 'ON'
//            corresponding signal will be put OFF!
//
// ---------------------------------------------------
extern  int   SetModemOutputStatus(BOOLEAN bDTR, BOOLEAN bRTS) {

  int     rc;

  if (hSerialPort == INVALIDSERIALHANDLE) {             // port not open
    if (PortSetup(szPortName) == FALSE)                 // open and init port
      return  XW_NOENT;
    }

  bDTRstate = bDTR;                                     // remember
  bRTSstate = bRTS;

  rc = OS_SerialSetModemOutputStatus(hSerialPort, bDTRstate, bRTSstate);
  if (rc != 0)
    printf("SetModemOutputStatus failed, rc %d\n", rc);

  if (bVerbose)
    printf("DTR %s, RTS %s\n",
            (bDTRstate) ? "On" : "Off",
            (bRTSstate) ? "On" : "Off");
  return rc;
  }


// ------------------------------------------------
//  Convert bps value to index for passthrough command
//  (value of 'x' in '00x4p')
//
//  Input   - speed in bps
//
//  Output  - nothing
//
//  Returns - index in table of supported speeds (should be in range 0..4)
//          - MINUS1 if speed not supported
//
// ------------------------------------------------
extern  int  SpeedIndex(ULONG ulBps) {

  int  i;                                               // counter(s)

  for (i=0; i<sizeof(aulWisp628Speed)/sizeof(ULONG); i++) {
    if (ulBps == aulWisp628Speed[i])
      return i;
    }
  return  MINUS1;
  }



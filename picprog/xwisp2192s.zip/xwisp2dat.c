
// ===================================================================
// XWisp2Dat.C - Wisp628 Programmer support library
//
//             - global Constants and variables
//
// Author:  R. Hamerling
// (c) Copyright 2002,2006, R.Hamerling. All rights reserved.
//
// Version: Actual version in XWisp2.h, reported at startup!
//
// ===================================================================
//
// Note: This file contains the defining declarations of global
//       constants and variables (for xwisp2 and xwlist).
//       The storage class 'extern' is omitted.
//       The file xwisp2.h constants the referencing declarations
//       with the storage class 'extern'.
//       This seems to be the method with which most compilers are happy.
//       (at least Open Watcom C/C++, IBM Visual Age C/C++, GCC).
//
// ===================================================================

#include "xwisp2.h"                             // all includes


// constants

const  char   *szAuthorName     = "R. Hamerling",
              *szProgName       = "xwisp2",
              *szCopyRight      = "(c) Copyright 2002,2006,"
                                  " R. Hamerling."
                                  " All rights reserved.";

const  char  *szAlgorithmName[] =
                   {"PIC16", "PIC16A", "PIC16B", "PIC18" ,
                    "PIC16C", "<Rsv1>", "<Rsv2>", "PIC16D",
                    "PIC16E", "PIC18A", "PIC10", "PIC16F", "",
                    };                  // must match enum in Xwisp2.h!!
const  char  *szPressEnter = ">>> Press 'Enter' to continue: ";


const  ULONG  ulWbusBaudrateMinimum = 10;               // default min
const  ULONG  ulWbusBaudrateMaximum = 115200;           // default max
const  ULONG  ulWbusBaudrateDefault = 19200;            // default wisp628

// global variables

char  **szArgv              = NULL;                     // commandline args
char   *szEnv               = NULL;                     // environment string

char   *szWbusDevice        = NULL;                     // Wbus device name
char   *ProgRegion          = NULL;                     // common progmem
char   *DataRegion          = NULL;                     // datamem 18F
char   *IDRegion            = NULL;                     // IDmem 18F
char   *FusesRegion         = NULL;                     // Fusesmem 18F
char   *DataRegionMidrange  = NULL;                     // ) mapped and stored
char   *IDRegionMidrange    = NULL;                     // ) in progmem!
char   *FusesRegionMidrange = NULL;                     // ) for midrange

FILE   *pLogFile            = NULL;

ULONG   ulProgSize          = 0;                        // prog memory
ULONG   ulDataSize          = 0;                        // data memory
ULONG   ulIDSize            = 8;                        // ID memory
ULONG   ulFusesSize         = 14;                       // fuses memory

ULONG   fBurstWrite         = BURSTWRITE_FDX;           // full duplex default
ULONG   fProtection         = PROT_HEX;                 // hex file contents
ULONG   fRegions            = REGION_ALL;               // all regions involved
ULONG   ulWisp628Level      = 0;                        // firmware 100*Maj+Min
ULONG   ulLBA               = 0;                        // base addr
ULONG   ulLastAddress       = MINUS1;                   // invalid
ULONG   ulWbusBaudrateActual = 19200;                   // initial
ULONG   ulWbusBaudrateUser  = 0;                        // user specified
ULONG   ulWisp628State      = WISP628SLEEP;             // default state

BOOLEAN bBeepEnable         = FALSE;                    // no beeps
BOOLEAN bDoubleEcho         = FALSE;                    // double echo (WLdr)
BOOLEAN bDTRstate           = FALSE;                    // state of DTR
BOOLEAN bFullVerify         = FALSE;                    // non blank memory
BOOLEAN bLazyWrite          = FALSE;                    // no lazy writes
BOOLEAN bBurstReading       = FALSE;                    // burst reading
BOOLEAN bRTSstate           = FALSE;                    // state of RTS
BOOLEAN bVerbose            = FALSE;                    // brief user info

USHORT  usFusesOverride     = 0x0000;                   // no override
USHORT  usDelay             = 0;                        // default pgmg delay

PTARGETINFO pTSpec          = NULL;                     // Specified target
PTARGETINFO pTUsed          = NULL;                     // Used target



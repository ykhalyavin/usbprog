void At89SPIOut(char data);
void At89WriteCode(int addr, char data);
void At89FlashWrite(char *buf);
void At89FlashErase();
